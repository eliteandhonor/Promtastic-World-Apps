from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent
from PyQt5.QtCore import QUrl

class Player:
    def __init__(self):
        self.player = QMediaPlayer()
        self.music_file = ""

    def set_music(self, file_path):
        self.music_file = file_path

    def play(self):
        if self.music_file:
            media = QMediaContent(QUrl.fromLocalFile(self.music_file))
            self.player.setMedia(media)
            self.player.play()

    def pause(self):
        self.player.pause()

    def stop(self):
        self.player.stop()

    def set_volume(self, volume):
        self.player.setVolume(volume)

    def is_playing(self):
        return self.player.state() == QMediaPlayer.PlayingState