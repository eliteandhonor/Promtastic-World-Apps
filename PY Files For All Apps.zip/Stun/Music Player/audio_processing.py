import librosa
import soundfile as sf

class AudioProcessor:
    def __init__(self):
        pass

    def load_audio(self, file_path):
        audio, sample_rate = librosa.load(file_path)
        return audio, sample_rate

    def apply_effect(self, audio, sample_rate, effect):
        if effect == "pitch_shift":
            pitch_shift = librosa.effects.pitch_shift(audio, sr=sample_rate, n_steps=4)
            audio = librosa.util.fix_length(pitch_shift, size=len(audio))
        # Add more audio effects as needed
        return audio

    def save_audio(self, audio, sample_rate, file_path):
        sf.write(file_path, audio, sample_rate)