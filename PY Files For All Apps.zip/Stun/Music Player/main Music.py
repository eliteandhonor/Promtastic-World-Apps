from PyQt5.QtWidgets import QApplication
from user_interface import MatrixWindow
import sys

def main():
    app = QApplication(sys.argv)
    window = MatrixWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()