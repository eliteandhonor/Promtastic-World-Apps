class Settings:
    def __init__(self):
        self.theme = "default"
        self.shortcuts = {}
        self.output_device = "default"

    def set_theme(self, theme):
        self.theme = theme

    def set_shortcut(self, action, shortcut):
        self.shortcuts[action] = shortcut

    def set_output_device(self, device):
        self.output_device = device

    def save_settings(self):
        # Save settings to a file or database
        pass

    def load_settings(self):
        # Load settings from a file or database
        pass