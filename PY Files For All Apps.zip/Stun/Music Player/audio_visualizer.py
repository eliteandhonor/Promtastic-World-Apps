import numpy as np
from PyQt5.QtWidgets import QWidget
from PyQt5.QtGui import QPainter, QColor, QPen
from PyQt5.QtCore import QTimer
import librosa

class AudioVisualizer(QWidget):
    def __init__(self):
        super().__init__()
        self.audio_data = None
        self.sample_rate = None
        self.timer = QTimer()
        self.timer.timeout.connect(self.update)
        self.current_frame = 0
        self.frame_stride = 512

    def create_visualization_widget(self):
        visualization_widget = QWidget()
        visualization_widget.setFixedSize(600, 200)
        visualization_widget.setStyleSheet("background-color: black;")
        return visualization_widget

    def start_visualization(self, music_file):
        self.audio_data, self.sample_rate = librosa.load(music_file, duration=60)
        self.current_frame = 0
        self.timer.start(100)

    def pause_visualization(self):
        self.timer.stop()

    def stop_visualization(self):
        self.timer.stop()
        self.current_frame = 0
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(0, 0, 0))
        
        if self.audio_data is not None:
            start_frame = self.current_frame * self.frame_stride
            end_frame = start_frame + self.frame_stride
            if end_frame < len(self.audio_data):
                frame_data = self.audio_data[start_frame:end_frame]
                frame_data = np.abs(frame_data)
                frame_data = frame_data / np.max(frame_data)
                
                bar_width = self.width() // len(frame_data)
                bar_height = frame_data * self.height()
                
                pen = QPen(QColor(0, 255, 0))
                painter.setPen(pen)
                
                for i, height in enumerate(bar_height):
                    painter.drawRect(i * bar_width, self.height() - height, bar_width, height)
                
                self.current_frame += 1
        
        painter.end()