from PyQt5.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QPushButton, QSlider, QLabel, QFileDialog
from PyQt5.QtGui import QColor, QPalette
from PyQt5.QtCore import Qt
from player import Player
from audio_processing import AudioProcessor
from audio_visualizer import AudioVisualizer

class MatrixWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Matrix Music Player")
        self.setGeometry(100, 100, 800, 600)

        self.player = Player()
        self.audio_processor = AudioProcessor()
        self.audio_visualizer = AudioVisualizer()

        self.music_file = ""

        self.init_ui()

    def init_ui(self):
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout()
        central_widget.setLayout(layout)

        title_label = self.create_title_label()
        layout.addWidget(title_label)

        select_button = self.create_button("Select Music", self.select_music)
        layout.addWidget(select_button)

        play_button = self.create_button("Play", self.play_music)
        layout.addWidget(play_button)

        pause_button = self.create_button("Pause", self.pause_music)
        layout.addWidget(pause_button)

        stop_button = self.create_button("Stop", self.stop_music)
        layout.addWidget(stop_button)

        process_button = self.create_button("Process Audio", self.process_audio)
        layout.addWidget(process_button)

        volume_slider = self.create_volume_slider()
        layout.addWidget(volume_slider)

        self.music_label = QLabel("No music selected")
        self.music_label.setAlignment(Qt.AlignCenter)
        self.music_label.setStyleSheet("color: #00FF00; font-size: 18px;")
        layout.addWidget(self.music_label)

        self.visualization_widget = self.audio_visualizer.create_visualization_widget()
        layout.addWidget(self.visualization_widget)

        self.set_matrix_style()

    def create_title_label(self):
        title_label = QLabel("Matrix Music Player", self)
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("""
            QLabel {
                font-size: 32px;
                color: #00FF00;
                background-color: black;
                padding: 10px;
            }
        """)
        return title_label

    def create_button(self, text, slot):
        button = QPushButton(text, self)
        button.clicked.connect(slot)
        button.setStyleSheet("""
            QPushButton {
                font-size: 24px;
                color: #00FF00;
                background-color: black;
                border: 2px solid #00FF00;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #00FF00;
                color: black;
            }
        """)
        return button

    def create_volume_slider(self):
        volume_slider = QSlider(self)
        volume_slider.setOrientation(Qt.Horizontal)
        volume_slider.setRange(0, 100)
        volume_slider.setValue(50)
        volume_slider.valueChanged.connect(self.set_volume)
        volume_slider.setStyleSheet("""
            QSlider::groove:horizontal {
                border: 1px solid #00FF00;
                background: black;
                height: 10px;
                border-radius: 5px;
            }
            QSlider::handle:horizontal {
                background: #00FF00;
                border: 1px solid #00FF00;
                width: 20px;
                margin: -5px 0;
                border-radius: 10px;
            }
        """)
        return volume_slider

    def set_matrix_style(self):
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(0, 0, 0))
        palette.setColor(QPalette.WindowText, QColor(0, 255, 0))
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, QColor(0, 0, 0))
        palette.setColor(QPalette.ToolTipText, QColor(0, 255, 0))
        palette.setColor(QPalette.Text, QColor(0, 255, 0))
        palette.setColor(QPalette.Button, QColor(0, 0, 0))
        palette.setColor(QPalette.ButtonText, QColor(0, 255, 0))
        palette.setColor(QPalette.BrightText, QColor(0, 255, 0))
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, QColor(0, 0, 0))
        self.setPalette(palette)

    def select_music(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Music File", "", "Music Files (*.mp3 *.wav *.ogg)")
        if file_path:
            self.music_file = file_path
            self.music_label.setText(file_path)

    def play_music(self):
        if self.music_file:
            self.player.set_music(self.music_file)
            self.player.play()
            self.audio_visualizer.start_visualization(self.music_file)

    def pause_music(self):
        self.player.pause()
        self.audio_visualizer.pause_visualization()

    def stop_music(self):
        self.player.stop()
        self.audio_visualizer.stop_visualization()

    def process_audio(self):
        if self.music_file:
            audio, sample_rate = self.audio_processor.load_audio(self.music_file)
            processed_audio = self.audio_processor.apply_effect(audio, sample_rate, "pitch_shift")
            output_file = "processed_audio.wav"
            self.audio_processor.save_audio(processed_audio, sample_rate, output_file)
            self.music_file = output_file
            self.music_label.setText(output_file)

    def set_volume(self, value):
        self.player.set_volume(value)