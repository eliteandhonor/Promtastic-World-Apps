import os
from database import Database

class MusicLibrary:
    def __init__(self, library_path, db_path):
        self.library_path = library_path
        self.database = Database(db_path)

    def scan_library(self):
        for root, dirs, files in os.walk(self.library_path):
            for file in files:
                if file.endswith((".mp3", ".wav", ".ogg")):
                    file_path = os.path.join(root, file)
                    # Extract metadata from the music file
                    title = "Song Title"
                    artist = "Artist Name"
                    album = "Album Name"
                    self.database.add_track(title, artist, album, file_path)

    def get_tracks(self):
        return self.database.get_all_tracks()