from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Track(Base):
    __tablename__ = 'tracks'
    id = Column(Integer, primary_key=True)
    title = Column(String)
    artist = Column(String)
    album = Column(String)
    file_path = Column(String)

class Database:
    def __init__(self, db_path):
        self.engine = create_engine(f'sqlite:///{db_path}')
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def add_track(self, title, artist, album, file_path):
        session = self.Session()
        track = Track(title=title, artist=artist, album=album, file_path=file_path)
        session.add(track)
        session.commit()
        session.close()

    def get_all_tracks(self):
        session = self.Session()
        tracks = session.query(Track).all()
        session.close()
        return tracks