from PyQt6.QtWidgets import QTextEdit
from PyQt6.QtGui import QFontDatabase

class Editor(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_editor()

    def setup_editor(self):
        self.setFontPointSize(16)  # Increase the font size for better readability
        self.setStyleSheet("QTextEdit { padding: 10px; font-size: 16pt; }")  # Increase the font size for better readability
        QFontDatabase.addApplicationFont(":/resources/icons/EmojiOne.ttf")  # Add an emoji font
