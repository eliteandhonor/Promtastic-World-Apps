from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from PyQt6.QtWidgets import QFileDialog

def export_to_pdf(editor):
    file_path, _ = QFileDialog.getSaveFileName(editor, "Save File", "", "PDF Files (*.pdf)")
    if file_path:
        c = canvas.Canvas(file_path, pagesize=letter)
        text = editor.toPlainText()
        lines = text.split('\n')
        y = 750
        for line in lines:
            c.drawString(30, y, line)
            y -= 15
        c.save()

def export_to_docx(editor):
    from docx import Document
    doc = Document()
    doc.add_paragraph(editor.toPlainText())
    file_path, _ = QFileDialog.getSaveFileName(editor, "Save File", "", "Word Document (*.docx)")
    if file_path:
        doc.save(file_path)

def export_to_html(editor):
    file_path, _ = QFileDialog.getSaveFileName(editor, "Save File", "", "HTML Files (*.html)")
    if file_path:
        with open(file_path, 'w') as file:
            file.write(editor.toHtml())
