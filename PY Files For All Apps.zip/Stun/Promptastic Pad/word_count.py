from PyQt6.QtWidgets import QMessageBox, QTextEdit

def show_word_count(editor: QTextEdit):
    text = editor.toPlainText()
    word_count = len(text.split())
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Icon.Information)
    msg.setText(f"Word Count: {word_count}")
    msg.setWindowTitle("Word Count")
    msg.exec()
