from PyQt6.QtWidgets import QFileDialog

class Templates:
    def __init__(self):
        self.templates_dir = './templates/'

    def load_template(self, editor):
        file_path, _ = QFileDialog.getOpenFileName(editor, "Open Template", self.templates_dir, "HTML Files (*.html);;Text Files (*.txt)")
        if file_path:
            with open(file_path, 'r') as file:
                content = file.read()
                editor.setHtml(content)

    def save_template(self, editor):
        file_path, _ = QFileDialog.getSaveFileName(editor, "Save Template", self.templates_dir, "HTML Files (*.html);;Text Files (*.txt)")
        if file_path:
            with open(file_path, 'w') as file:
                file.write(editor.toHtml())
