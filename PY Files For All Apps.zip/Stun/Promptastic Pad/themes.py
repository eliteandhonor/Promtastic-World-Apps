def apply_theme(window, theme):
    if theme == 'light':
        window.setStyleSheet("""
            background-color: white;
            color: black;
            QMenuBar {
                background-color: white;
                color: black;
            }
            QMenu {
                background-color: white;
                color: black;
            }
            QMenu::item:selected {
                background-color: lightgray;
                color: black;
            }
            QToolBar {
                background-color: white;
                color: black;
            }
        """)
    elif theme == 'dark':
        window.setStyleSheet("""
            background-color: black;
            color: white;
            QMenuBar {
                background-color: black;
                color: white;
            }
            QMenu {
                background-color: black;
                color: white;
            }
            QMenu::item:selected {
                background-color: gray;
                color: white;
            }
            QToolBar {
                background-color: black;
                color: white;
            }
        """)
    elif theme == 'matrix':
        window.setStyleSheet("""
            background-color: black;
            color: #00FF00;
            QMenuBar {
                background-color: black;
                color: #00FF00;
            }
            QMenu {
                background-color: black;
                color: #00FF00;
            }
            QMenu::item:selected {
                background-color: #004400;
                color: #00FF00;
            }
            QToolBar {
                background-color: black;
                color: #00FF00;
            }
        """)
