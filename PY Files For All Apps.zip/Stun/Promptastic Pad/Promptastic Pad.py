import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QFileDialog, QVBoxLayout, QWidget, QHBoxLayout, QSpacerItem, QSizePolicy
from PyQt6.QtGui import QAction
from editor import Editor
from toolbar import create_toolbar
from themes import apply_theme
from export import export_to_pdf, export_to_docx, export_to_html
from spellcheck import SpellCheck
from templates import Templates
from toc_generator import generate_toc  # Import TOC generation feature
from word_count import show_word_count  # Import word count feature
from find_replace import find_and_replace  # Import find and replace feature

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Promptasiic Editor - The Matrix")
        self.setGeometry(100, 100, 1200, 800)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout(self.central_widget)
        
        self.editor = Editor(self)
        self.layout.addWidget(self.editor)

        self.toolbar_layout = QHBoxLayout()
        self.add_toolbar_to_layout()
        self.layout.addLayout(self.toolbar_layout)

        apply_theme(self, 'matrix')

        self.spellcheck = SpellCheck()
        self.templates = Templates()

        self.init_menu()

    def add_toolbar_to_layout(self):
        spacer_left = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self.toolbar_layout.addItem(spacer_left)

        self.toolbar = create_toolbar(self)
        self.toolbar_layout.addWidget(self.toolbar)

        spacer_right = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self.toolbar_layout.addItem(spacer_right)

    def init_menu(self):
        menu = self.menuBar()
        
        # File menu
        file_menu = menu.addMenu('File')
        
        save_action = QAction('💾 Save', self)
        save_action.triggered.connect(self.save_file)
        file_menu.addAction(save_action)

        open_action = QAction('📂 Open', self)
        open_action.triggered.connect(self.open_file)
        file_menu.addAction(open_action)

        export_pdf_action = QAction('📄 Export to PDF', self)
        export_pdf_action.triggered.connect(lambda: export_to_pdf(self.editor))
        file_menu.addAction(export_pdf_action)

        export_docx_action = QAction('📝 Export to DOCX', self)
        export_docx_action.triggered.connect(lambda: export_to_docx(self.editor))
        file_menu.addAction(export_docx_action)

        export_html_action = QAction('🌐 Export to HTML', self)
        export_html_action.triggered.connect(lambda: export_to_html(self.editor))
        file_menu.addAction(export_html_action)

        # Edit menu
        edit_menu = menu.addMenu('Edit')

        spellcheck_action = QAction('🔍 Spell Check', self)
        spellcheck_action.triggered.connect(self.run_spellcheck)
        edit_menu.addAction(spellcheck_action)

        # View menu
        view_menu = menu.addMenu('View')

        light_theme_action = QAction('☀️ Light Theme', self)
        light_theme_action.triggered.connect(lambda: apply_theme(self, 'light'))
        view_menu.addAction(light_theme_action)

        dark_theme_action = QAction('🌙 Dark Theme', self)
        dark_theme_action.triggered.connect(lambda: apply_theme(self, 'dark'))
        view_menu.addAction(dark_theme_action)

        matrix_theme_action = QAction('🟩 Matrix Theme', self)
        matrix_theme_action.triggered.connect(lambda: apply_theme(self, 'matrix'))
        view_menu.addAction(matrix_theme_action)

        # New feature menu
        toc_action = QAction('📜 Generate TOC', self)
        toc_action.triggered.connect(lambda: generate_toc(self.editor))
        view_menu.addAction(toc_action)

        word_count_action = QAction('📝 Word Count', self)
        word_count_action.triggered.connect(lambda: show_word_count(self.editor))
        view_menu.addAction(word_count_action)

        find_replace_action = QAction('🔍 Find and Replace', self)
        find_replace_action.triggered.connect(lambda: find_and_replace(self.editor))
        view_menu.addAction(find_replace_action)

    def save_file(self):
        options = QFileDialog.Option.ShowDirsOnly
        file_path, _ = QFileDialog.getSaveFileName(self, "Save File", "", "All Files (*);;Text Files (*.txt)", options=options)
        if file_path:
            with open(file_path, 'w') as file:
                file.write(self.editor.toPlainText())

    def open_file(self):
        options = QFileDialog.Option.ShowDirsOnly
        file_path, _ = QFileDialog.getOpenFileName(self, "Open File", "", "All Files (*);;Text Files (*.txt)", options=options)
        if file_path:
            with open(file_path, 'r') as file:
                self.editor.setPlainText(file.read())

    def run_spellcheck(self):
        text = self.editor.toPlainText()
        misspelled = self.spellcheck.check(text)
        if misspelled:
            misspelled_words = ', '.join(misspelled)
            self.editor.append(f"\nMisspelled words: {misspelled_words}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
