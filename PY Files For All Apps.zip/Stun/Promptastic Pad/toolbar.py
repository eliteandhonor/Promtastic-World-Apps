from PyQt6.QtWidgets import QToolBar, QColorDialog, QFontDialog, QComboBox, QTextEdit
from PyQt6.QtGui import QAction, QFont, QColor, QTextCharFormat, QTextCursor
from PyQt6.QtCore import Qt

def create_toolbar(parent):
    toolbar = QToolBar("Toolbar", parent)
    toolbar.setStyleSheet("QToolBar { font-size: 16pt; }")  # Increase the font size for better readability

    bold_action = QAction('🅱️ Bold', parent)
    bold_action.setCheckable(True)
    bold_action.triggered.connect(lambda: toggle_format(parent.editor, 'bold', bold_action.isChecked()))
    toolbar.addAction(bold_action)

    italic_action = QAction('👁 Italic', parent)
    italic_action.setCheckable(True)
    italic_action.triggered.connect(lambda: toggle_format(parent.editor, 'italic', italic_action.isChecked()))
    toolbar.addAction(italic_action)

    underline_action = QAction('🔠 Underline', parent)
    underline_action.setCheckable(True)
    underline_action.triggered.connect(lambda: toggle_format(parent.editor, 'underline', underline_action.isChecked()))
    toolbar.addAction(underline_action)

    strike_action = QAction('❌ Strike', parent)
    strike_action.setCheckable(True)
    strike_action.triggered.connect(lambda: toggle_format(parent.editor, 'strike', strike_action.isChecked()))
    toolbar.addAction(strike_action)

    align_left_action = QAction('⬅️ Left', parent)
    align_left_action.triggered.connect(lambda: parent.editor.setAlignment(Qt.AlignmentFlag.AlignLeft))
    toolbar.addAction(align_left_action)

    align_center_action = QAction('🔄 Center', parent)
    align_center_action.triggered.connect(lambda: parent.editor.setAlignment(Qt.AlignmentFlag.AlignCenter))
    toolbar.addAction(align_center_action)

    align_right_action = QAction('➡️ Right', parent)
    align_right_action.triggered.connect(lambda: parent.editor.setAlignment(Qt.AlignmentFlag.AlignRight))
    toolbar.addAction(align_right_action)

    font_action = QAction('🔤 Font', parent)
    font_action.triggered.connect(lambda: change_font(parent.editor))
    toolbar.addAction(font_action)

    color_action = QAction('🎨 Color', parent)
    color_action.triggered.connect(lambda: change_color(parent.editor))
    toolbar.addAction(color_action)

    font_size_box = QComboBox(parent)
    font_size_box.addItems([str(i) for i in range(8, 30)])
    font_size_box.setStyleSheet("QComboBox { font-size: 16pt; }")  # Increase the font size for better readability
    font_size_box.currentTextChanged.connect(lambda size: parent.editor.setFontPointSize(int(size)))
    toolbar.addWidget(font_size_box)

    # Header section using emojis
    header1_action = QAction('🔴 H1', parent)
    header1_action.triggered.connect(lambda: insert_header(parent.editor, 'h1'))
    toolbar.addAction(header1_action)

    header2_action = QAction('🟠 H2', parent)
    header2_action.triggered.connect(lambda: insert_header(parent.editor, 'h2'))
    toolbar.addAction(header2_action)

    header3_action = QAction('🟡 H3', parent)
    header3_action.triggered.connect(lambda: insert_header(parent.editor, 'h3'))
    toolbar.addAction(header3_action)
    
    return toolbar

def toggle_format(editor, format_type, state):
    cursor = editor.textCursor()
    if not cursor.hasSelection():
        cursor.select(QTextCursor.SelectionType.WordUnderCursor)

    format = cursor.charFormat()

    if format_type == 'bold':
        format.setFontWeight(QFont.Weight.Bold if state else QFont.Weight.Normal)
    elif format_type == 'italic':
        format.setFontItalic(state)
    elif format_type == 'underline':
        format.setFontUnderline(state)
    elif format_type == 'strike':
        format.setFontStrikeOut(state)

    cursor.setCharFormat(format)

def change_font(editor):
    font, ok = QFontDialog.getFont()
    if ok:
        editor.setCurrentFont(font)

def change_color(editor):
    color = QColorDialog.getColor()
    if color.isValid():
        editor.setTextColor(color)

def insert_header(editor, level):
    cursor = editor.textCursor()
    if level == 'h1':
        cursor.insertText('# ')
    elif level == 'h2':
        cursor.insertText('## ')
    elif level == 'h3':
        cursor.insertText('### ')
