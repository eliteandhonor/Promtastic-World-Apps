import os
import sys
from spellchecker import SpellChecker

class SpellCheck:
    def __init__(self):
        # Determine if running in a bundle
        if getattr(sys, 'frozen', False):
            # Running in a bundle
            bundle_dir = sys._MEIPASS
        else:
            # Running in a normal Python environment
            bundle_dir = os.path.abspath(os.path.dirname(__file__))
        
        # Path to the spellchecker dictionary
        resource_path = os.path.join(bundle_dir, 'spellchecker', 'resources', 'en.json.gz')
        
        # Initialize the SpellChecker with the correct path
        self.spell = SpellChecker(language='en', local_dictionary=resource_path)
    
    def check(self, text):
        """Check the given text for misspelled words."""
        return self.spell.unknown(text.split())
