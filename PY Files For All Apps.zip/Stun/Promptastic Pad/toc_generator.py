from PyQt6.QtWidgets import QTextEdit

def generate_toc(editor: QTextEdit):
    text = editor.toPlainText()
    lines = text.split('\n')
    toc = []
    for i, line in enumerate(lines):
        if line.startswith("# "):  # H1
            toc.append(f"1. {line[2:]} (Line {i + 1})")
        elif line.startswith("## "):  # H2
            toc.append(f"  1.1 {line[3:]} (Line {i + 1})")
        elif line.startswith("### "):  # H3
            toc.append(f"    1.1.1 {line[4:]} (Line {i + 1})")

    toc_text = "\n".join(toc)
    editor.append("\n\nTable of Contents\n" + "="*18 + "\n" + toc_text)
