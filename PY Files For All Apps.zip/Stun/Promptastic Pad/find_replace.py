from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLineEdit, QPushButton, QTextEdit, QLabel
from PyQt6.QtGui import QTextCursor
from PyQt6.QtCore import Qt

class FindReplaceDialog(QDialog):
    def __init__(self, editor: QTextEdit):
        super().__init__()
        self.editor = editor
        self.setWindowTitle("Find and Replace")
        self.setGeometry(100, 100, 400, 200)
        layout = QVBoxLayout()
        self.setLayout(layout)

        self.find_input = QLineEdit(self)
        self.find_input.setPlaceholderText("Find")
        layout.addWidget(QLabel("Find:"))
        layout.addWidget(self.find_input)
        self.find_input.setFocus()  # Set focus to the find input field

        self.replace_input = QLineEdit(self)
        self.replace_input.setPlaceholderText("Replace")
        layout.addWidget(QLabel("Replace:"))
        layout.addWidget(self.replace_input)

        self.find_button = QPushButton("Find", self)
        self.find_button.clicked.connect(self.find_text)
        layout.addWidget(self.find_button)
        self.find_button.setShortcut("Ctrl+F")  # Set keyboard shortcut for the find button

        self.replace_button = QPushButton("Replace", self)
        self.replace_button.clicked.connect(self.replace_text)
        layout.addWidget(self.replace_button)
        self.replace_button.setShortcut("Ctrl+R")  # Set keyboard shortcut for the replace button

    def find_text(self):
        find_text = self.find_input.text()
        editor_text = self.editor.toPlainText()
        if find_text in editor_text:
            cursor = self.editor.textCursor()
            pos = editor_text.find(find_text)
            cursor.setPosition(pos)
            cursor.setPosition(pos + len(find_text), QTextCursor.MoveMode.KeepAnchor)
            self.editor.setTextCursor(cursor)
        else:
            print("Text not found")  # Handle the case when the text is not found

    def replace_text(self):
        find_text = self.find_input.text()
        replace_text = self.replace_input.text()
        editor_text = self.editor.toPlainText()
        new_text = editor_text.replace(find_text, replace_text)
        self.editor.setPlainText(new_text)

def find_and_replace(editor: QTextEdit):
    dialog = FindReplaceDialog(editor)
    dialog.exec()
