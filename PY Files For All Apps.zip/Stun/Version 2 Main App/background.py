import customtkinter as ctk

def set_theme(mode):
    """Sets the application's appearance mode (light or dark)."""
    ctk.set_appearance_mode(mode)

def show_theme_window(parent):
    """Displays a popup window for theme settings."""
    theme_window = ctk.CTkToplevel(parent)
    theme_window.title("Theme Settings")
    theme_window.geometry("300x100") 

    # Keep theme window on top and modal
    theme_window.transient(parent)  # Makes it a transient window
    theme_window.grab_set()  # Makes it modal (blocks interaction with main window)

    # Appearance Mode
    appearance_frame = ctk.CTkFrame(theme_window)
    appearance_frame.pack(pady=10)

    appearance_label = ctk.CTkLabel(appearance_frame, text="Appearance Mode:")
    appearance_label.pack(side=ctk.LEFT)

    appearance_var = ctk.StringVar(value=ctk.get_appearance_mode())
    appearance_option_light = ctk.CTkRadioButton(
        appearance_frame, text="Light", variable=appearance_var, value="light"
    )
    appearance_option_light.pack(side=ctk.LEFT)
    appearance_option_dark = ctk.CTkRadioButton(
        appearance_frame, text="Dark", variable=appearance_var, value="dark"
    )
    appearance_option_dark.pack(side=ctk.LEFT)

    # Apply Button
    def apply_theme():
        """Applies the selected theme and updates the main window."""
        set_theme(appearance_var.get())
        parent.update_fonts()  # Update fonts after theme change

        # Release grab after applying
        theme_window.grab_release()
        theme_window.destroy() 

    apply_button = ctk.CTkButton(
        theme_window, text="Apply", command=apply_theme, corner_radius=10
    )
    apply_button.pack(pady=10)