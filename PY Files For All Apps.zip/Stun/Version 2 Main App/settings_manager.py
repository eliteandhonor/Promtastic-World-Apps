# settings_manager.py
import json
import logging
from tkinter import messagebox

def load_settings():
    """Loads application settings from settings.json."""
    try:
        with open("settings.json", "r") as file:
            settings = json.load(file)
            return settings
    except FileNotFoundError:
        logging.info("Settings file not found. Using default settings.")
        return {}  # Return an empty dictionary if the file doesn't exist
    except Exception as e:
        logging.error(f"Failed to load settings: {e}")
        messagebox.showerror("Error", "Failed to load settings.")
        return {}  # Return an empty dictionary in case of error

def save_settings_to_file(settings):
    """Saves application settings to settings.json."""
    try:
        with open("settings.json", "w") as file:
            json.dump(settings, file)
    except Exception as e:
        logging.error(f"Failed to save settings: {e}")
        messagebox.showerror("Error", "Failed to save settings.")