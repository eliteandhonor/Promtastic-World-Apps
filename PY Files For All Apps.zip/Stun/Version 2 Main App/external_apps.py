import customtkinter as ctk
from tkinter import messagebox
import webbrowser  # Import for opening URLs
import subprocess  # Import for launching external programs
import os  # Import for file path handling

class ExternalAppsManager:
    def __init__(self, parent):
        self.parent = parent
        self.create_window()

    def create_window(self):
        self.apps_window = ctk.CTkToplevel(self.parent)
        self.apps_window.title("External Apps")
        self.apps_window.geometry("300x300")  # Increase the window height
        self.apps_window.transient(self.parent)

        # PDF button
        self.pdf_button = ctk.CTkButton(
            self.apps_window,
            text="PDF 📑",
            command=self.open_pdf,
            font=("Futura", 14, "bold"),
            corner_radius=10
        )
        self.pdf_button.pack(pady=10)

        # Example: Open a web page (replace with your desired URL)
        self.web_button = ctk.CTkButton(
            self.apps_window,
            text="Open Website 🌐",
            command=self.open_website,
            font=("Futura", 14, "bold"),
            corner_radius=10
        )
        self.web_button.pack(pady=10)

        # Scraper Zen button
        self.scraper_zen_button = ctk.CTkButton(
            self.apps_window,
            text="Scraper Zen 🕷️",
            command=self.open_scraper_zen,
            font=("Futura", 14, "bold"),
            corner_radius=10
        )
        self.scraper_zen_button.pack(pady=10)

        # Promptastic Pad button
        self.promptastic_pad_button = ctk.CTkButton(
            self.apps_window,
            text="Promptastic Pad 📝",
            command=self.open_promptastic_pad,
            font=("Futura", 14, "bold"),
            corner_radius=10
        )
        self.promptastic_pad_button.pack(pady=10)

        # Music Player button
        self.music_player_button = ctk.CTkButton(
            self.apps_window,
            text="Music Player 🎵",
            command=self.open_music_player,
            font=("Futura", 14, "bold"),
            corner_radius=10
        )
        self.music_player_button.pack(pady=10)

    def open_pdf(self):
        # Launch the PDF application
        subprocess.Popen(["python", "PDF.py"])  # Replace "PDF.py" with the actual file name

    def open_website(self):
        webbrowser.open_new_tab("https://www.google.com")  # Replace with your website

    def open_scraper_zen(self):
        # Get the current script's directory
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Construct the path to the "scraper zen" subfolder
        scraper_zen_path = os.path.join(current_dir, "scraper zen")
        
        # Construct the path to the "main scraper.py" file
        main_scraper_path = os.path.join(scraper_zen_path, "main scraper.py")
        
        # Launch the "main scraper.py" file
        subprocess.Popen(["python", main_scraper_path])

    def open_promptastic_pad(self):
        # Get the current script's directory
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Construct the path to the "Promptastic Pad" subfolder
        promptastic_pad_path = os.path.join(current_dir, "Promptastic Pad")
        
        # Construct the path to the "Promptastic Pad.py" file
        promptastic_pad_file = os.path.join(promptastic_pad_path, "Promptastic Pad.py")
        
        # Launch the "Promptastic Pad.py" file
        subprocess.Popen(["python", promptastic_pad_file])

    def open_music_player(self):
        # Get the current script's directory
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Construct the path to the "Music Player" subfolder
        music_player_path = os.path.join(current_dir, "Music Player")
        
        # Construct the path to the "main Music.py" file
        main_music_path = os.path.join(music_player_path, "main Music.py")
        
        # Launch the "main Music.py" file
        subprocess.Popen(["python", main_music_path])