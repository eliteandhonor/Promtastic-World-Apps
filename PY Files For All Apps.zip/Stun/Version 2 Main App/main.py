import os
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk
from PIL import Image, ImageTk
import json
import logging
import threading
import background
from favorites_manager import FavoritesManager
from history_manager import HistoryManager
from prompt_manager import load_prompts
from settings_manager import load_settings, save_settings_to_file
from buttons import create_buttons
from customtkinter import CTkImage
import external_apps  # Import the new module

class Promptastic(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Promptastic")
        self.geometry("1000x600")

        self.prompt_folder = ""
        self.prompts = []
        self.categories = []
        self.current_prompt_index = 0
        self.loaded_images = []
        self.image_paths = []
        self.last_folder_mtime = None

        self.font_family = "Futura"
        self.font_size = 14
        self.keep_history_session = tk.BooleanVar(value=False) 

        self.favorites_manager = FavoritesManager(self)
        self.favorites_manager.load_prompt.trace("w", self.load_favorite_prompt)
        self.history_manager = HistoryManager(self)

        self.create_widgets()

        settings = load_settings()
        if "font_family" in settings:
            self.font_family = settings["font_family"]
        if "font_size" in settings:
            self.font_size = settings["font_size"]
        if "prompt_folder" in settings:
            self.prompt_folder = settings["prompt_folder"]
            load_prompts(self.prompt_folder, self.prompts, self.categories)
            self.update_category_listbox()
            self.update_subfolder_listbox()
            if self.prompts:
                self.display_prompt(self.current_prompt_index)
        if "keep_history_session" in settings:
            self.keep_history_session.set(settings["keep_history_session"])

        # Set to dark mode using built-in theme
        ctk.set_appearance_mode("dark") 

        self.deiconify()

    def create_widgets(self):
        self.rowconfigure(2, weight=1)
        self.columnconfigure(1, weight=1)

        self.folder_button = ctk.CTkButton(
            self, text="Select Prompt Folder", command=self.select_folder,
            font=(self.font_family, self.font_size), corner_radius=10
        )
        self.folder_button.grid(row=0, column=0, columnspan=2, pady=20, padx=20, sticky="ew")

        self.search_frame = ctk.CTkFrame(self)
        self.search_frame.grid(row=1, column=0, columnspan=2, pady=10, padx=20, sticky="ew")

        self.search_entry = ctk.CTkEntry(
            self.search_frame, placeholder_text="Search Prompts",
            font=(self.font_family, self.font_size), height=40, corner_radius=10
        )
        self.search_entry.pack(side=tk.LEFT, padx=(0, 10), fill=tk.X, expand=True)
        self.search_entry.bind("<Return>", self.search_prompts)

        self.search_button = ctk.CTkButton(
            self.search_frame, text="Search", command=self.search_prompts,
            font=(self.font_family, self.font_size), corner_radius=40
        )
        self.search_button.pack(side=tk.LEFT)

        self.clear_search_button = ctk.CTkButton(
            self.search_frame, text="Clear", command=self.clear_search,
            font=(self.font_family, self.font_size), corner_radius=40
        )
        self.clear_search_button.pack(side=tk.LEFT)

        self.category_frame = ctk.CTkFrame(self, corner_radius=50)
        self.category_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ns")

        self.category_label = ctk.CTkLabel(
            self.category_frame, text="Prompt List", font=(self.font_family, self.font_size, "bold")
        )
        self.category_label.pack(pady=10)

        # Category Listbox
        self.category_listbox = tk.Listbox(
            self.category_frame, font=(self.font_family, self.font_size),
            relief=tk.FLAT, highlightthickness=0, 
            bg="#242424", fg="white"  # Customize background and text color
        )
        self.category_listbox.pack(fill=tk.BOTH, expand=True)
        self.category_listbox.bind("<<ListboxSelect>>", self.filter_prompts)

        self.prompt_frame = ctk.CTkFrame(self, corner_radius=10)
        self.prompt_frame.grid(row=2, column=1, sticky="nsew", padx=20, pady=10)
        self.prompt_frame.columnconfigure(0, weight=1)
        self.prompt_frame.rowconfigure(1, weight=1)

        self.prompt_label = ctk.CTkLabel(
            self.prompt_frame, text="Prompt", font=(self.font_family, self.font_size, "bold")
        )
        self.prompt_label.grid(row=0, column=0, pady=10, sticky="ew")

        # Customize the prompt text box
        self.prompt_text = ctk.CTkTextbox(
            self.prompt_frame, font=(self.font_family, self.font_size), wrap=tk.WORD
        )
        self.prompt_text.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))

        self.image_frame = ctk.CTkFrame(self.prompt_frame)
        self.image_frame.grid(row=2, column=0, pady=10, sticky="ew")

        self.image_label = ctk.CTkLabel(self.image_frame, text="")
        self.image_label.pack(anchor=tk.CENTER)  

        self.button_frame = ctk.CTkFrame(self.prompt_frame)
        self.button_frame.grid(row=3, column=0, pady=10, sticky="ew")

        self.favorite_button, self.copy_button, self.view_favorites_button, \
        self.view_history_button, self.theme_editor_button = create_buttons(
            self.button_frame, self.font_family, self.font_size,
            self.add_to_favorites, self.copy_to_clipboard,
            self.show_favorites_window, self.show_history_window,
            self.show_theme_window
        )

        self.favorite_button.pack(side=ctk.LEFT, padx=5, expand=True)
        self.copy_button.pack(side=ctk.LEFT, padx=5, expand=True)
        self.view_favorites_button.pack(side=ctk.LEFT, padx=5, expand=True)
        self.view_history_button.pack(side=ctk.LEFT, padx=5, expand=True)
        self.theme_editor_button.pack(side=ctk.LEFT, padx=5, expand=True)

        # Add the "External Apps" button
        self.external_apps_button = ctk.CTkButton(
            self.button_frame,
            text="External Apps 🌐",
            command=self.open_external_apps,
            font=(self.font_family, self.font_size, "bold"),
            corner_radius=10
        )
        self.external_apps_button.pack(side=ctk.LEFT, padx=5, expand=True)

        self.bind("<Control-f>", self.search_prompts)
        self.bind("<Control-c>", self.copy_to_clipboard)

        # Create a new frame for the second listbox
        self.subfolder_frame = ctk.CTkFrame(self, corner_radius=50)
        self.subfolder_frame.grid(row=2, column=2, padx=20, pady=10, sticky="ns")

        self.subfolder_label = ctk.CTkLabel(
            self.subfolder_frame, text="Categories", font=(self.font_family, self.font_size, "bold")
        )
        self.subfolder_label.pack(pady=10)

        # Subfolder Listbox
        self.subfolder_listbox = tk.Listbox(
            self.subfolder_frame, font=(self.font_family, self.font_size),
            relief=tk.FLAT, highlightthickness=0, 
            bg="#242424", fg="white"  # Customize background and text color
        )
        self.subfolder_listbox.pack(fill=tk.BOTH, expand=True)
        self.subfolder_listbox.bind("<<ListboxSelect>>", self.filter_subfolders)

    def load_favorites(self):
        self.favorites_manager.load_favorites()

    def save_favorites(self):
        self.favorites_manager.save_favorites()

    def display_prompt(self, prompt_index):
        if 0 <= prompt_index < len(self.prompts):
            prompt_file, category = self.prompts[prompt_index]
            prompt_path = os.path.join(self.prompt_folder, prompt_file)

            try:
                with open(prompt_path, "r", encoding="utf-8") as file:
                    prompt_content = file.read()
            except FileNotFoundError:
                logging.error(f"Prompt file not found: {prompt_path}")
                messagebox.showerror("Error", f"Prompt file not found: {prompt_file}")
                return

            self.prompt_text.delete("1.0", tk.END)
            self.prompt_text.insert(tk.END, prompt_content)

            self.display_images(prompt_file)
            self.update_favorite_button_state(prompt_file)
            self.history_manager.add_to_history(prompt_file, category)
        else:
            self.prompt_text.delete("1.0", tk.END)
            self.image_label.configure(image="")

    def display_images(self, prompt_file):
        # Calculate the image path correctly for both main folder and subfolders
        self.image_paths = self.get_image_paths(prompt_file, self.prompt_folder)
        if self.image_paths:
            self.display_image(0)

    def get_image_paths(self, prompt_file, base_folder):  # Added base_folder
        image_extensions = [".png", ".jpg", ".jpeg", ".gif"]
        image_paths = []
        prompt_basename = os.path.splitext(prompt_file)[0]
        for ext in image_extensions:
            potential_path = os.path.join(base_folder, prompt_basename + ext)
            if os.path.exists(potential_path):
                image_paths.append(potential_path)
        return image_paths

    def display_image(self, image_index):
        if self.image_paths and 0 <= image_index < len(self.image_paths):
            try:
                image_path = self.image_paths[image_index]
                image = Image.open(image_path)
                image.thumbnail((400, 400))
                photo = ImageTk.PhotoImage(image)
                self.image_label.configure(image=photo)
                self.image_label.image = photo
                self.loaded_images.append(photo)  
            except FileNotFoundError:
                logging.error(f"Image file not found: {image_path}")
                messagebox.showerror("Error", "Image not found: {image_path}")
            except Exception as e:
                logging.error(f"Failed to display image: {e}")
                messagebox.showerror("Error", "Failed to display image.")

    def update_category_listbox(self):
        self.category_listbox.delete(0, tk.END)
        for category in self.categories:
            self.category_listbox.insert(tk.END, category)

    def update_fonts(self):
        font_settings = (self.font_family, self.font_size)
        for widget in self.winfo_children():
            if isinstance(widget, (ctk.CTkButton, ctk.CTkLabel, ctk.CTkEntry,
                                    ctk.CTkTextbox, tk.Listbox, ctk.CTkCheckBox)):
                widget.configure(font=font_settings)

    def select_folder(self):
        self.prompt_folder = filedialog.askdirectory()
        if self.prompt_folder:
            settings = {
                "font_family": self.font_family,
                "font_size": self.font_size,
                "prompt_folder": self.prompt_folder,
                "keep_history_session": self.keep_history_session.get()
            }
            save_settings_to_file(settings)
            load_prompts(self.prompt_folder, self.prompts, self.categories)
            self.after(0, self.update_category_listbox)
            self.after(0, self.update_subfolder_listbox)
            if self.prompts:
                self.after(100, lambda: self.display_prompt(self.current_prompt_index))

    def search_prompts(self, event=None):
        search_query = self.search_entry.get().lower()
        matching_prompts = [
            (i, prompt) for i, prompt in enumerate(self.prompts) 
            if search_query in prompt[0].lower() or search_query in prompt[1].lower()
        ]
        if matching_prompts:
            self.current_prompt_index = matching_prompts[0][0]
            self.display_filtered_prompts(matching_prompts)
        else:
            self.prompts = []
            self.categories = []
            self.update_category_listbox()
            self.prompt_text.delete("1.0", tk.END)
            self.image_label.configure(image="")
            messagebox.showinfo("Info", "No matching prompts found.")

    def display_filtered_prompts(self, filtered_prompts):
        self.prompts = [prompt for _, prompt in filtered_prompts]
        self.categories = list(set(prompt[1] for prompt in self.prompts))
        self.update_category_listbox()
        self.display_prompt(self.current_prompt_index)
    def clear_search(self):
        self.search_entry.delete(0, tk.END)
        self.category_listbox.selection_clear(0, tk.END)

        # Reset prompt_folder to the main folder
        settings = load_settings()  
        self.prompt_folder = settings["prompt_folder"]  
        load_prompts(self.prompt_folder, self.prompts, self.categories)
        self.after(0, self.update_category_listbox)
        self.after(0, self.update_subfolder_listbox)  # Update subfolder listbox

        # Clear the displayed image
        self.image_label.configure(image="")

        if self.prompts:
            self.after(100, lambda: self.display_prompt(self.current_prompt_index))
    def filter_prompts(self, event):
        if self.category_listbox.curselection():
            selected_category = self.category_listbox.get(self.category_listbox.curselection())
            filtered_prompts = [
                (i, prompt) for i, prompt in enumerate(self.prompts) 
                if prompt[1] == selected_category
            ]
            if filtered_prompts:
                self.current_prompt_index = filtered_prompts[0][0]
                self.display_prompt(self.current_prompt_index)
            else:
                self.prompt_text.delete("1.0", tk.END)
                self.image_label.configure(image="")
                messagebox.showinfo("Info", f"No prompts in '{selected_category}' category.")

    def add_to_favorites(self):
        if 0 <= self.current_prompt_index < len(self.prompts):
            prompt_file, category = self.prompts[self.current_prompt_index]
            self.favorites_manager.toggle_favorite(prompt_file, category)
            self.update_favorite_button_state(prompt_file)
        else:
            messagebox.showwarning("Error", "No prompt selected.")

    def update_favorite_button_state(self, prompt_file):
        if 0 <= self.current_prompt_index < len(self.prompts):
            _, category = self.prompts[self.current_prompt_index]
            if self.favorites_manager.is_favorite(prompt_file, category):
                self.favorite_button.configure(text="Remove from Favorites ⭐")
            else:
                self.favorite_button.configure(text="Add to Favorites ⭐")
        else:
            messagebox.showwarning("Error", "No prompt selected.")

    def load_favorite_prompt(self, *args):
        prompt_info = self.favorites_manager.load_prompt.get()
        if prompt_info:
            prompt_name, category = prompt_info.split(",")
            matching_prompts = [
                (i, p[0]) for i, p in enumerate(self.prompts)
                if p[0] == prompt_name and p[1] == category
            ]
            if matching_prompts:
                self.current_prompt_index = matching_prompts[0][0]
                self.display_prompt(self.current_prompt_index)
            else:
                messagebox.showwarning(
                    "Prompt Not Found", f"Prompt '{prompt_name}' not found."
                )
                self.favorites_manager.load_prompt.set("")

    def copy_to_clipboard(self, event=None):
        prompt_content = self.prompt_text.get("1.0", tk.END).strip()
        self.clipboard_clear()
        self.clipboard_append(prompt_content)
        messagebox.showinfo("Clipboard", "Prompt copied.")

    def show_favorites_window(self):
        favorites_window = ctk.CTkToplevel(self)
        favorites_window.title("Favorites")
        favorites_window.geometry("400x400")
        favorites_window.transient(self) 

        favorites_label = ctk.CTkLabel(
            favorites_window, text="Favorites", font=(self.font_family, self.font_size)
        )
        favorites_label.pack(pady=10)

        listbox_frame = ctk.CTkFrame(favorites_window)
        listbox_frame.pack(fill=tk.BOTH, expand=True)

        # Favorites Listbox
        self.favorites_listbox = tk.Listbox(
            listbox_frame, font=(self.font_family, self.font_size),
            relief=tk.FLAT, highlightthickness=0, 
            bg="#242424", fg="white"  # Customize background and text color
        )
        self.favorites_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.favorites_listbox.bind(
            "<<ListboxSelect>>", self.select_favorite_in_window
        )

        scrollbar = tk.Scrollbar(
            listbox_frame, orient=tk.VERTICAL, command=self.favorites_listbox.yview
        )
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.favorites_listbox.config(yscrollcommand=scrollbar.set)

        button_frame = ctk.CTkFrame(favorites_window)
        button_frame.pack(pady=5)

        clear_button = ctk.CTkButton(
            button_frame, text="Clear All", command=self.clear_favorites,
            font=(self.font_family, self.font_size), corner_radius=10
        )
        clear_button.pack(side=tk.LEFT, padx=5)

        delete_button = ctk.CTkButton(
            button_frame, text="Delete", command=self.delete_selected_favorite,
            font=(self.font_family, self.font_size), corner_radius=10
        )
        delete_button.pack(side=tk.LEFT, padx=5)

        self.update_favorites_listbox()
        favorites_window.focus_force()  

    def select_favorite_in_window(self, event):
        if self.favorites_listbox.curselection():
            selected_index = self.favorites_listbox.curselection()[0]
            selected_favorite = self.favorites_listbox.get(selected_index)
            try:
                last_open_paren = selected_favorite.rfind("(")
                prompt_name = selected_favorite[:last_open_paren].strip()
                category = selected_favorite[last_open_paren + 1:-1].strip()
                self.favorites_manager.load_prompt.set(
                    f"{prompt_name},{category}"
                )
            except ValueError:
                messagebox.showerror(
                    "Error", "Could not determine prompt name and category."
                )

    def clear_favorites(self):
        if messagebox.askyesno(
            "Confirm Clear", "Are you sure you want to clear all favorites?"
        ):
            self.favorites_manager.clear_favorites()
            self.update_favorites_listbox()
            messagebox.showinfo("Favorites", "Favorites cleared.")

    def delete_selected_favorite(self):
        if self.favorites_listbox.curselection():
            selected_index = self.favorites_listbox.curselection()[0]
            selected_favorite = self.favorites_listbox.get(selected_index)
            try:
                last_open_paren = selected_favorite.rfind("(")
                prompt_name = selected_favorite[:last_open_paren].strip()
                category = selected_favorite[last_open_paren + 1:-1].strip()
                if messagebox.askyesno(
                    "Confirm Delete", f"Delete '{prompt_name}'?"
                ):
                    self.favorites_manager.remove_favorite(prompt_name, category)
                    self.update_favorites_listbox()
                    messagebox.showinfo("Favorites", f"'{prompt_name}' removed.")
            except ValueError:
                messagebox.showerror(
                    "Error", "Could not determine prompt name and category."
                )
        else:
            messagebox.showwarning("No Selection", "Select a favorite to delete.")

    def update_favorites_listbox(self):
        if hasattr(self, "favorites_listbox"):
            self.favorites_listbox.delete(0, tk.END)
            for prompt_name, category in self.favorites_manager.favorites:
                self.favorites_listbox.insert(
                    tk.END, f"{prompt_name} ({category})"
                )

    def show_history_window(self):
        if not hasattr(self, "history_window") or not self.history_window.winfo_exists():
            self.create_history_window()
        self.history_window.deiconify()
        self.history_window.transient(self)
        self.history_window.grab_set()

    def add_to_history(self, prompt_name: str, category: str):
        self.history_manager.add_to_history(prompt_name, category)
        self.update_history_listbox()

    def clear_history(self):
        self.history_manager.clear_history()
        self.update_history_listbox()

    def update_history_listbox(self):
        self.history_listbox.delete(0, tk.END)
        for item in self.history_manager.history:
            self.history_listbox.insert(tk.END, item)

    def show_theme_window(self):
        background.show_theme_window(self)

    def toggle_keep_history(self):
        settings = {
            "font_family": self.font_family,
            "font_size": self.font_size,
            "prompt_folder": self.prompt_folder,
            "keep_history_session": self.keep_history_session.get()
        }
        save_settings_to_file(settings)

    def on_closing(self):
        if not self.keep_history_session.get():
            self.history_manager.clear_history()
        self.destroy()

    def filter_subfolders(self, event):
        if self.subfolder_listbox.curselection():
            selected_subfolder = self.subfolder_listbox.get(self.subfolder_listbox.curselection())
            self.load_prompts_from_subfolder(selected_subfolder)

    def load_prompts_from_subfolder(self, subfolder):
        self.prompt_folder = os.path.join(self.prompt_folder, subfolder)  # Update prompt_folder
        load_prompts(self.prompt_folder, self.prompts, self.categories)
        self.update_category_listbox()
        if self.prompts:
            self.display_prompt(self.current_prompt_index)

    def update_subfolder_listbox(self):
        self.subfolder_listbox.delete(0, tk.END)
        for subfolder in [f for f in os.listdir(self.prompt_folder) if os.path.isdir(os.path.join(self.prompt_folder, f))]:
            self.subfolder_listbox.insert(tk.END, subfolder)

    def create_history_window(self):
        if not hasattr(self, "history_window") or not self.history_window.winfo_exists():
            self.history_window = ctk.CTkToplevel(self)
            self.history_window.title("Prompt History")
            self.history_window.geometry("400x400")

            main_frame = ctk.CTkFrame(self.history_window)
            main_frame.pack(fill=tk.BOTH, expand=True)
            main_frame.rowconfigure(0, weight=1)
            main_frame.columnconfigure(0, weight=1)

            # History Listbox
            self.history_listbox = tk.Listbox(
                main_frame, font=(self.font_family, self.font_size),
                relief=tk.FLAT, highlightthickness=0, 
                bg="#242424", fg="white"  # Customize background and text color
            )
            self.history_listbox.grid(row=0, column=0, sticky="nsew")

            scrollbar = tk.Scrollbar(
                main_frame, orient=tk.VERTICAL, command=self.history_listbox.yview
            )
            scrollbar.grid(row=0, column=1, sticky="ns")
            self.history_listbox.config(yscrollcommand=scrollbar.set)

            button_frame = ctk.CTkFrame(self.history_window)
            button_frame.pack(fill=tk.X, expand=True, pady=5)

            clear_button = ctk.CTkButton(
                button_frame, text="Clear History", command=self.clear_history,
                font=(self.font_family, self.font_size), corner_radius=10
            )
            clear_button.pack(side=tk.LEFT, padx=5)

            self.keep_history_session_checkbox = ctk.CTkCheckBox(
                button_frame, text="Keep History Across Sessions",
                variable=self.keep_history_session, command=self.toggle_keep_history,
                font=(self.font_family, self.font_size)
            )
            self.keep_history_session_checkbox.pack(side=tk.LEFT, padx=5)

            self.update_history_listbox()
            self.history_listbox.bind("<<ListboxSelect>>", self.select_history_item)

    def select_history_item(self, event):
        if self.history_listbox.curselection():
            selected_index = self.history_listbox.curselection()[0]
            selected_item = self.history_listbox.get(selected_index)
            try:
                last_open_paren = selected_item.rfind("(")
                prompt_name = selected_item[:last_open_paren].strip()
                category = selected_item[last_open_paren + 1:-1].strip()

                # Find the matching prompt in the current prompts list
                for i, (file, cat) in enumerate(self.prompts):
                    if file == prompt_name and cat == category:
                        self.current_prompt_index = i
                        self.display_prompt(self.current_prompt_index)
                        break
                else:
                    # If not found in the current prompts, try to load it directly from the prompt folder
                    self.load_prompt_by_name(prompt_name, category)

            except ValueError:
                messagebox.showerror(
                    "Error", "Could not determine prompt name and category."
                )

    def load_prompt_by_name(self, prompt_name, category):
        prompt_path = os.path.join(self.prompt_folder, prompt_name + ".txt")
        if os.path.exists(prompt_path):
            try:
                with open(prompt_path, "r", encoding="utf-8") as file:
                    prompt_content = file.read()
            except FileNotFoundError:
                logging.error(f"Prompt file not found: {prompt_path}")
                messagebox.showerror("Error", f"Prompt file not found: {prompt_name}")
                return

            self.prompt_text.delete("1.0", tk.END)
            self.prompt_text.insert(tk.END, prompt_content)

            self.display_images(prompt_name)
            self.update_favorite_button_state(prompt_name)
            self.history_manager.add_to_history(prompt_name, category)
        else:
            messagebox.showwarning("Prompt Not Found", f"Prompt '{prompt_name}' not found.")

    def open_external_apps(self):
        self.external_apps_manager = external_apps.ExternalAppsManager(self)

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
    )
    app = Promptastic()
    app.mainloop()