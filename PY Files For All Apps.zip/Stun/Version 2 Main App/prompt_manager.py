import os
import logging

def load_prompts(prompt_folder, prompts, categories):
    """Loads prompts from the selected folder."""
    prompts.clear()
    categories.clear()

    if prompt_folder:
        for file in os.listdir(prompt_folder):
            if file.endswith(".txt"):
                try:
                    category = os.path.splitext(file)[0].split("_")[0]
                except IndexError:
                    logging.warning(f"File '{file}' has incorrect naming. Using 'Unknown' category.")
                    category = "Unknown"
                prompts.append((file, category))
                if category not in categories:
                    categories.append(category)