import tkinter as tk
from tkinter import messagebox
import json

class FavoritesManager:
    """Manages the saving, loading, adding, and removing of favorite prompts."""
    def __init__(self, parent):
        self.parent = parent
        self.favorites = []
        self.favorites_file = "favorites.json"
        self.load_prompt = tk.StringVar(self.parent)
        self.load_favorites()

    def add_favorite(self, prompt_name: str, category: str) -> None:
        """Adds a prompt to the favorites list."""
        if (prompt_name, category) not in self.favorites:
            self.favorites.append((prompt_name, category))
            self.save_favorites()
            messagebox.showinfo("Favorites", f"Prompt '{prompt_name}' added to favorites.")

    def remove_favorite(self, prompt_name: str, category: str) -> None:
        """Removes a prompt from the favorites list."""
        if (prompt_name, category) in self.favorites:
            self.favorites.remove((prompt_name, category))
            self.save_favorites()
            messagebox.showinfo("Favorites", f"Prompt '{prompt_name}' removed from favorites.")

    def clear_favorites(self):
        """Clears the entire favorites list."""
        confirm = messagebox.askyesno("Confirm Clear", "Are you sure you want to clear all favorites?")
        if confirm:
            self.favorites = []
            self.save_favorites()

    def load_favorites(self) -> None:
        """Loads favorites from the associated JSON file."""
        try:
            with open(self.favorites_file, "r", encoding="utf-8") as f:
                self.favorites = json.load(f)
        except FileNotFoundError:
            pass  # It's okay if the file doesn't exist yet
        except json.JSONDecodeError:
            messagebox.showerror("Error", "Failed to load favorites. The file might be corrupted.")

    def save_favorites(self) -> None:
        """Saves the current favorites to the JSON file."""
        with open(self.favorites_file, "w", encoding="utf-8") as f:
            json.dump(self.favorites, f, ensure_ascii=False, indent=4)

    def toggle_favorite(self, prompt_name: str, category: str) -> None:
        """Toggles the favorite status of a specific prompt."""
        if (prompt_name, category) in self.favorites:
            self.remove_favorite(prompt_name, category)
        else:
            self.add_favorite(prompt_name, category)

    def is_favorite(self, prompt_name: str, category: str) -> bool:
        """Checks if a prompt is currently a favorite."""
        return (prompt_name, category) in self.favorites