# history_manager.py

import json
import logging
import tkinter as tk
from tkinter import messagebox

class HistoryManager:
    """Manages the saving, loading, clearing, and displaying of prompt history."""

    def __init__(self, parent):
        self.parent = parent
        self.history = []
        self.history_file = "history.json"
        self.load_history()

    def add_to_history(self, prompt_name: str, category: str) -> None:
        """Adds a prompt to the history."""
        self.history.append(f"{prompt_name} ({category})")
        self.save_history()

    def clear_history(self) -> None:
        """Clears the prompt history."""
        if self.parent.keep_history_session.get():
            # If keep_history_session is True, don't clear history
            pass 
        else:
            self.history = []
            self.save_history()

    def load_history(self) -> None:
        """Loads history from the associated JSON file."""
        try:
            with open(self.history_file, "r", encoding="utf-8") as f:
                self.history = json.load(f)
        except FileNotFoundError:
            pass  # It's okay if the file doesn't exist yet
        except json.JSONDecodeError:
            messagebox.showerror("Error", "Failed to load history. The file might be corrupted.")

    def save_history(self) -> None:
        """Saves the current history to the JSON file."""
        with open(self.history_file, "w", encoding="utf-8") as f:
            json.dump(self.history, f, ensure_ascii=False, indent=4)