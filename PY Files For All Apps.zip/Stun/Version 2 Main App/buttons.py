import customtkinter as ctk

def create_buttons(button_frame, font_family, font_size, 
                   add_to_favorites_func, copy_to_clipboard_func, 
                   view_favorites_func, view_history_func, 
                   theme_settings_func):
    favorite_button = ctk.CTkButton(
        button_frame, text="**Add to Favorites ⭐**", command=add_to_favorites_func,
        font=(font_family, font_size, "bold"), corner_radius=10
    )
    copy_button = ctk.CTkButton(
        button_frame, text="**Copy to Clipboard 📋**", command=copy_to_clipboard_func,
        font=(font_family, font_size, "bold"), corner_radius=10
    )
    view_favorites_button = ctk.CTkButton(
        button_frame, text="**View Favorites ❤️**", command=view_favorites_func,
        font=(font_family, font_size, "bold"), corner_radius=10
    )
    view_history_button = ctk.CTkButton(
        button_frame, text="**View History 🕰️**", command=view_history_func,
        font=(font_family, font_size, "bold"), corner_radius=10
    )
    theme_editor_button = ctk.CTkButton(
        button_frame, text="**Theme Settings 🎨**", command=theme_settings_func,
        font=(font_family, font_size, "bold"), corner_radius=10
    )
    return favorite_button, copy_button, view_favorites_button, \
           view_history_button, theme_editor_button