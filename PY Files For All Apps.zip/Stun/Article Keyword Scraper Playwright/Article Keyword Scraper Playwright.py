import os
import re
import time
import logging
from datetime import datetime
from playwright.sync_api import sync_playwright
import tkinter as tk
from tkinter import messagebox, Listbox, Scrollbar, Entry, StringVar, OptionMenu, Text

# Set up logging
logging.basicConfig(filename="app.log", level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

processed_urls = set()  # Global set to keep track of processed URLs

def google_search(keyword, max_results=10, timeout=30000):
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()

            page.goto(f"https://www.google.com/search?q={keyword}", timeout=timeout)
            time.sleep(2)  # Add a delay to allow the page to load

            search_results = page.query_selector_all("#search .g")
            results = []
            for result in search_results:
                link = result.query_selector("a")
                if link:
                    url = link.get_attribute("href")
                    if url and url not in processed_urls:  # Check if the URL has already been processed
                        title = link.inner_text().strip()
                        results.append({"title": title, "url": url})
                        processed_urls.add(url)  # Add the URL to the set of processed URLs
                        if len(results) == max_results:  # Break the loop if we have extracted the desired number of unique results
                            break

            browser.close()
            return results
    except Exception as e:
        logging.error(f"Error during Google search: {str(e)}")
        return []

def extract_article(url, timeout=30000):
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()

            page.goto(url, timeout=timeout)  # Increase the timeout to 30 seconds
            time.sleep(2)  # Add a delay to allow the page to load

            article_element = page.query_selector("article") or page.query_selector("body")
            article = article_element.inner_text().strip()

            # Remove non-alphanumeric characters and extra whitespace from the article text
            article = re.sub(r'[^a-zA-Z0-9\s]', '', article)
            article = re.sub(r'\s+', ' ', article)

            browser.close()
            return article
    except Exception as e:
        logging.error(f"Error extracting article from {url}: {str(e)}")
        return None

def perform_search():
    keyword = search_entry.get()
    if not keyword:
        messagebox.showwarning("Input Error", "Please enter a keyword.")
        return

    try:
        num_articles = int(article_count.get())
        if num_articles < 1 or num_articles > 10:
            raise ValueError("Number of articles must be between 1 and 10.")
    except ValueError:
        messagebox.showwarning("Input Error", "Please enter a valid number of articles (1-10).")
        return

    timeout = int(timeout_var.get())
    status_label.config(text="Searching...")
    root.update()

    results = google_search(keyword, num_articles, timeout)
    if results:
        for result in results:
            display_text = f"{result['title']} ({result['url']})"
            if display_text not in result_listbox.get(0, tk.END):
                result_listbox.insert(tk.END, display_text)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Create directories for links and articles based on the search keyword
        sanitized_keyword = re.sub(r'[^a-zA-Z0-9\s]', '', keyword).replace(' ', '_')
        links_dir = os.path.join("extracted_links", sanitized_keyword, f"search_results_{timestamp}")
        articles_dir = os.path.join("extracted_articles", sanitized_keyword, f"articles_{timestamp}")
        os.makedirs(links_dir, exist_ok=True)
        os.makedirs(articles_dir, exist_ok=True)

        # Save search results
        with open(os.path.join(links_dir, "search_results.txt"), "w", encoding="utf-8") as file:
            for result in results:
                file.write(f"{result['title']}\n{result['url']}\n\n")

        status_label.config(text="Extracting articles...")
        root.update()

        # Extract and save articles
        for i, result in enumerate(results[:num_articles]):  # Extract only the specified number of articles
            article = extract_article(result['url'], timeout)
            if article:
                with open(os.path.join(articles_dir, f"article_{i + 1}.txt"), "w", encoding="utf-8") as file:
                    file.write(article)
            else:
                logging.warning(f"Skipping article {i + 1} due to extraction failure.")

        status_label.config(text="Search and extraction completed.")
    else:
        messagebox.showinfo("No Results", "No search results found.")
        status_label.config(text="No results found.")

# Create main window
root = tk.Tk()
root.title("Matrix-Themed Search App")

# Set Matrix-themed colors
bg_color = "#000000"
fg_color = "#00FF00"
root.configure(bg=bg_color)

# Search input
search_frame = tk.Frame(root, bg=bg_color)
search_frame.pack(pady=10)
search_label = tk.Label(search_frame, text="Enter Keyword:", bg=bg_color, fg=fg_color)
search_label.pack(side=tk.LEFT, padx=5)
search_entry = tk.Entry(search_frame, width=30)
search_entry.pack(side=tk.LEFT, padx=5)
search_button = tk.Button(search_frame, text="Search", command=perform_search, bg=bg_color, fg=fg_color)
search_button.pack(side=tk.LEFT, padx=5)

# Number of articles to extract
article_count_label = tk.Label(root, text="Number of Articles to Extract (1-10):", bg=bg_color, fg=fg_color)
article_count_label.pack(pady=5)
article_count = Entry(root, width=5)
article_count.pack(pady=5)
article_count.insert(0, "5")  # Default value

# Timeout setting
timeout_label = tk.Label(root, text="Timeout (ms):", bg=bg_color, fg=fg_color)
timeout_label.pack(pady=5)
timeout_var = StringVar(value="30000")
timeout_entry = Entry(root, textvariable=timeout_var, width=10)
timeout_entry.pack(pady=5)

# Status label
status_label = tk.Label(root, text="", bg=bg_color, fg=fg_color)
status_label.pack(pady=5)

# Results listbox
result_frame = tk.Frame(root, bg=bg_color)
result_frame.pack(pady=10)
scrollbar = Scrollbar(result_frame)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
result_listbox = Listbox(result_frame, width=80, height=10, bg=bg_color, fg=fg_color, yscrollcommand=scrollbar.set)
result_listbox.pack(side=tk.LEFT, fill=tk.BOTH)
scrollbar.config(command=result_listbox.yview)

root.mainloop()
