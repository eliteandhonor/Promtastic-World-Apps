import requests
from bs4 import BeautifulSoup
from url_validator import validate_url
from data_logger import setup_logger, log_info, log_error
from tag_analyzer import analyze_tags
from pagination_handler import get_next_page_url
from output_manager import save_data
from headers_manager import get_headers
from rate_limiter_strategies import RateLimiter
from image_scraper import scrape_images

class WebScraper:
    def __init__(self, config):
        self.config = config
        self.url = self.config['url']
        self.soup = None
        self.output_file = self.config['output_file']
        self.file_format = self.config['file_format']
        self.image_folder = self.config.get('image_folder', 'images')
        self.next_page_selector = self.config.get('next_page_selector', 'a.next')
        self.image_selector = self.config.get('image_selector', 'img')
        self.headers = self.config['headers']
        self.rate_limit = self.config.get('rate_limit', 1.0)
        self.rate_limiter_strategy = self.config.get('rate_limiter_strategy', 'fixed')
        self.rate_limiter = RateLimiter(self.rate_limit, self.rate_limiter_strategy)
        self.skip_images = self.config.get('skip_images', False)
        setup_logger()

    def fetch_data(self, url):
        if not validate_url(url):
            log_error(f"Invalid URL: {url}")
            print("Invalid URL. Please provide a valid URL.")
            return None
        try:
            self.rate_limiter.wait()
            response = requests.get(url, headers=self.headers, timeout=10)
            response.raise_for_status()
            return BeautifulSoup(response.text, 'html.parser')
        except requests.exceptions.RequestException as e:
            log_error(f"Error fetching data: {e}")
            print(f"Error fetching data: {e}")
            return None

    def scrape(self):
        url = self.url
        all_data = {
            "headers": [],
            "paragraphs": [],
            "links": [],
            "tag_analysis": []
        }
        while url:
            self.soup = self.fetch_data(url)
            if not self.soup:
                break

            data = self.parse_data(self.soup)
            for key in all_data:
                all_data[key].extend(data[key])

            if not self.skip_images:
                scrape_images(self.soup, url, self.image_selector, self.image_folder)
            url = get_next_page_url(self.soup, url, self.next_page_selector)

        self.save_data(all_data)
        print(f"Data saved to {self.output_file}")

    def parse_data(self, soup):
        data = {
            "headers": [header.text for header in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])],
            "paragraphs": [p.text for p in soup.find_all('p')],
            "links": [a['href'] for a in soup.find_all('a', href=True)],
            "tag_analysis": analyze_tags(soup)
        }
        log_info("Data parsing complete")
        return data

    def save_data(self, data):
        if not data:
            log_error("No data to save.")
            print("No data to save.")
            return
        save_data(data, self.output_file, self.file_format)
        log_info(f"Data saved to {self.output_file}")
