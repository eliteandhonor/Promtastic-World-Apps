import os
import requests
from urllib.parse import urlparse

def download_file(url, download_folder):
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()

        parsed_url = urlparse(url)
        file_name = os.path.basename(parsed_url.path)
        file_path = os.path.join(download_folder, file_name)

        os.makedirs(download_folder, exist_ok=True)

        with open(file_path, 'wb') as file:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    file.write(chunk)
        
        print(f"Downloaded {file_name} to {file_path}")
    except Exception as e:
        print(f"Error downloading file: {e}")
        raise
