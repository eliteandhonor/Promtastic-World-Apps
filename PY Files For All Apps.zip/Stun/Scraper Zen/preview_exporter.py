def export_preview_data(data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(data)
