import time

class RateLimiter:
    def __init__(self, rate_limit, strategy):
        self.rate_limit = rate_limit
        self.strategy = strategy

    def limit(self):
        self.strategy(self.rate_limit)
