import matplotlib.pyplot as plt

def visualize_header_distribution(headers, output_path):
    header_count = {}
    for header in headers:
        header_count[header] = header_count.get(header, 0) + 1

    plt.figure(figsize=(10, 6))
    plt.bar(header_count.keys(), header_count.values())
    plt.xlabel('Header Names')
    plt.ylabel('Count')
    plt.title('Header Distribution')
    plt.xticks(rotation=90)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.show()
