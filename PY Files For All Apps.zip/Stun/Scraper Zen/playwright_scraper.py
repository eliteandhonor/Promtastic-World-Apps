import asyncio
from playwright.async_api import async_playwright

class PlaywrightScraper:
    def __init__(self, config):
        self.config = config
        self.url = config['url']
        self.headers = config['headers']
        self.output_file = config['output_file']
        self.file_format = config['file_format']
        self.scraped_content = None

    async def scrape(self):
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            page = await browser.new_page()
            await page.set_extra_http_headers(self.headers)
            await page.goto(self.url)
            self.scraped_content = await page.content()
            await browser.close()

    def parse_data(self, content):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(content, 'html.parser')
        data = {
            "headers": [header.text for header in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])],
            "paragraphs": [p.text for p in soup.find_all('p')],
            "links": [a['href'] for a in soup.find_all('a', href=True)],
            "tag_analysis": self.analyze_tags(soup)
        }
        return data

    def analyze_tags(self, soup):
        from collections import Counter
        tags = [tag.name for tag in soup.find_all()]
        tag_counts = dict(Counter(tags))
        return tag_counts
