def get_next_page_url(soup, current_url, next_page_selector):
    next_page = soup.select_one(next_page_selector)
    if next_page and next_page.get('href'):
        return next_page['href']
    return None
