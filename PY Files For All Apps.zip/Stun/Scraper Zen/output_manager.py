import pandas as pd

def save_data(data, output_file, file_format):
    # Find the maximum length of lists in the data dictionary
    max_length = max(len(v) for v in data.values())
    
    # Pad lists with empty strings to ensure all lists have the same length
    padded_data = {k: v + [''] * (max_length - len(v)) for k, v in data.items()}
    
    # Convert to DataFrame
    df = pd.DataFrame(padded_data)
    
    if file_format == 'csv':
        df.to_csv(output_file, index=False)
    elif file_format == 'json':
        df.to_json(output_file, orient='records', lines=True)
    elif file_format == 'excel':
        df.to_excel(output_file, index=False)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")
