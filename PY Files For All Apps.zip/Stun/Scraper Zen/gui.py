import asyncio
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from tkinter import filedialog, messagebox, Text, StringVar, simpledialog, Scrollbar
import tkinter as tk
from custom_headers import parse_custom_headers
from template_manager import save_template, load_templates, delete_template
from file_format_manager import parse_file_formats
from data_visualizer import visualize_data
from scraper import WebScraper
from playwright_scraper import PlaywrightScraper

class ScraperApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Web Scraper")
        self.style = ttk.Style("solar")

        self.url_label = ttk.Label(root, text="URL:", bootstyle="info")
        self.url_label.grid(row=0, column=0, padx=5, pady=5, sticky="W")
        self.url_entry = ttk.Entry(root, width=50, bootstyle="info")
        self.url_entry.grid(row=0, column=1, padx=5, pady=5, sticky="W")

        self.output_label = ttk.Label(root, text="Output File:", bootstyle="info")
        self.output_label.grid(row=1, column=0, padx=5, pady=5, sticky="W")
        self.output_entry = ttk.Entry(root, width=50, bootstyle="info")
        self.output_entry.grid(row=1, column=1, padx=5, pady=5, sticky="W")
        self.output_button = ttk.Button(root, text="Browse", bootstyle="info", command=self.browse_output_file)
        self.output_button.grid(row=1, column=2, padx=5, pady=5, sticky="W")

        self.output_format_label = ttk.Label(root, text="Output Format:", bootstyle="info")
        self.output_format_label.grid(row=2, column=0, padx=5, pady=5, sticky="W")
        self.output_format_combobox = ttk.Combobox(root, bootstyle="info", values=["csv", "json", "excel"])
        self.output_format_combobox.grid(row=2, column=1, padx=5, pady=5, sticky="W")
        self.output_format_combobox.current(0)

        self.user_agent_label = ttk.Label(root, text="User-Agent:", bootstyle="info")
        self.user_agent_label.grid(row=3, column=0, padx=5, pady=5, sticky="W")
        self.user_agent_combobox = ttk.Combobox(root, bootstyle="info", values=self.get_user_agents())
        self.user_agent_combobox.grid(row=3, column=1, padx=5, pady=5, sticky="W")
        self.user_agent_combobox.current(0)

        self.headers_label = ttk.Label(root, text="Custom Headers (key: value):", bootstyle="info")
        self.headers_label.grid(row=4, column=0, padx=5, pady=5, sticky="NW")
        self.headers_text = Text(root, width=50, height=5)
        self.headers_text.grid(row=4, column=1, padx=5, pady=5, sticky="W")

        self.template_label = ttk.Label(root, text="Header Templates:", bootstyle="info")
        self.template_label.grid(row=5, column=0, padx=5, pady=5, sticky="W")
        self.template_var = StringVar()
        self.template_combobox = ttk.Combobox(root, textvariable=self.template_var, bootstyle="info", values=list(self.get_header_templates().keys()))
        self.template_combobox.grid(row=5, column=1, padx=5, pady=5, sticky="W")
        self.template_combobox.bind("<<ComboboxSelected>>", self.apply_template)

        self.save_template_button = ttk.Button(root, text="Save Template", bootstyle="info", command=self.save_template)
        self.save_template_button.grid(row=6, column=0, padx=5, pady=5, sticky="W")

        self.delete_template_button = ttk.Button(root, text="Delete Template", bootstyle="danger", command=self.delete_template)
        self.delete_template_button.grid(row=6, column=1, padx=5, pady=5, sticky="W")

        self.rate_limit_label = ttk.Label(root, text="Rate Limit (seconds):", bootstyle="info")
        self.rate_limit_label.grid(row=7, column=0, padx=5, pady=5, sticky="W")
        self.rate_limit_entry = ttk.Entry(root, width=50, bootstyle="info")
        self.rate_limit_entry.grid(row=7, column=1, padx=5, pady=5, sticky="W")
        self.rate_limit_entry.insert(0, "1.0")  # Default value

        self.rate_limiter_strategy_label = ttk.Label(root, text="Rate Limiter Strategy:", bootstyle="info")
        self.rate_limiter_strategy_label.grid(row=8, column=0, padx=5, pady=5, sticky="W")
        self.rate_limiter_strategy_combobox = ttk.Combobox(root, bootstyle="info", values=["fixed", "exponential_backoff"])
        self.rate_limiter_strategy_combobox.grid(row=8, column=1, padx=5, pady=5, sticky="W")
        self.rate_limiter_strategy_combobox.current(0)

        self.depth_label = ttk.Label(root, text="Scraping Depth:", bootstyle="info")
        self.depth_label.grid(row=9, column=0, padx=5, pady=5, sticky="W")
        self.depth_entry = ttk.Entry(root, width=50, bootstyle="info")
        self.depth_entry.grid(row=9, column=1, padx=5, pady=5, sticky="W")
        self.depth_entry.insert(0, "0")  # Default value

        self.skip_images_var = tk.IntVar()
        self.skip_images_checkbox = ttk.Checkbutton(root, text="Skip Image Downloads", variable=self.skip_images_var, bootstyle="info")
        self.skip_images_checkbox.grid(row=10, column=0, padx=5, pady=5, sticky="W")

        self.scraper_type_var = tk.StringVar()
        self.scraper_type_label = ttk.Label(root, text="Scraper Type:", bootstyle="info")
        self.scraper_type_label.grid(row=11, column=0, padx=5, pady=5, sticky="W")
        self.scraper_type_combobox = ttk.Combobox(root, textvariable=self.scraper_type_var, bootstyle="info", values=["Web Scraper", "Playwright Scraper"])
        self.scraper_type_combobox.grid(row=11, column=1, padx=5, pady=5, sticky="W")
        self.scraper_type_combobox.current(0)

        self.scrape_button = ttk.Button(root, text="Start Scraping", bootstyle="success", command=self.start_scraping)
        self.scrape_button.grid(row=12, column=0, columnspan=3, padx=5, pady=5)

        self.status_label = ttk.Label(root, text="", bootstyle="info")
        self.status_label.grid(row=13, column=0, columnspan=3, padx=5, pady=5)

        self.preview_text = Text(root, height=10, width=70, wrap="word")
        self.preview_text.grid(row=14, column=0, columnspan=3, padx=5, pady=5)
        self.scrollbar = Scrollbar(root, command=self.preview_text.yview)
        self.preview_text['yscrollcommand'] = self.scrollbar.set

        self.export_preview_button = ttk.Button(root, text="Export Preview", bootstyle="info", command=self.export_preview)
        self.export_preview_button.grid(row=15, column=1, padx=5, pady=5, sticky="E")

        self.show_visualizations_button = ttk.Button(root, text="Show Visualizations", bootstyle="info", command=self.show_visualizations)
        self.show_visualizations_button.grid(row=15, column=0, padx=5, pady=5, sticky="W")

    def get_user_agents(self):
        return [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
            "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36"
        ]

    def get_header_templates(self):
        default_templates = {
            "Basic Authorization": "Authorization: Bearer YOUR_ACCESS_TOKEN",
            "Referer and Language": "Referer: https://example.com/previous-page\nAccept-Language: en-US,en;q=0.5",
            "Cookie Session": "Cookie: session_id=abc123; user_id=789"
        }
        saved_templates = load_templates()
        default_templates.update(saved_templates)
        return default_templates

    def browse_output_file(self):
        file_format = self.output_format_combobox.get()
        if file_format == "csv":
            file_types = [("CSV files", "*.csv"), ("All files", "*.*")]
        elif file_format == "json":
            file_types = [("JSON files", "*.json"), ("All files", "*.*")]
        elif file_format == "excel":
            file_types = [("Excel files", "*.xlsx"), ("All files", "*.*")]
        else:
            file_types = [("All files", "*.*")]
        
        file_path = filedialog.asksaveasfilename(defaultextension=f".{file_format}", filetypes=file_types)
        if file_path:
            self.output_entry.delete(0, tk.END)
            self.output_entry.insert(0, file_path)

    def apply_template(self, event):
        template_name = self.template_var.get()
        templates = self.get_header_templates()
        template = templates.get(template_name, "")
        self.headers_text.delete("1.0", tk.END)
        self.headers_text.insert(tk.END, template)

    def save_template(self):
        template_name = simpledialog.askstring("Save Template", "Enter template name:")
        if template_name:
            headers = self.headers_text.get("1.0", tk.END).strip()
            save_template(template_name, headers)
            self.template_combobox['values'] = list(self.get_header_templates().keys())
            messagebox.showinfo("Success", f"Template '{template_name}' saved successfully!")

    def delete_template(self):
        template_name = self.template_var.get()
        if template_name in load_templates():
            delete_template(template_name)
            self.template_combobox['values'] = list(self.get_header_templates().keys())
            messagebox.showinfo("Success", f"Template '{template_name}' deleted successfully!")
        else:
            messagebox.showerror("Error", f"Template '{template_name}' cannot be deleted or does not exist.")

    def start_scraping(self):
        url = self.url_entry.get()
        output_file = self.output_entry.get()
        file_format = self.output_format_combobox.get()
        user_agent = self.user_agent_combobox.get()
        custom_headers = self.headers_text.get("1.0", tk.END).strip()
        rate_limiter_strategy = self.rate_limiter_strategy_combobox.get()

        try:
            rate_limit = float(self.rate_limit_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number for rate limit.")
            return

        try:
            max_depth = int(self.depth_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number for scraping depth.")
            return

        if not url:
            messagebox.showerror("Error", "Please fill in all fields.")
            return

        headers = parse_custom_headers(custom_headers)
        headers["User-Agent"] = user_agent

        config = {
            "url": url,
            "output_file": output_file,
            "file_format": file_format,
            "headers": headers,
            "rate_limit": rate_limit,
            "rate_limiter_strategy": rate_limiter_strategy,
            "max_depth": max_depth,
            "image_folder": "output/images",
            "next_page_selector": "a.next",
            "image_selector": "img",
            "skip_images": self.skip_images_var.get()
        }

        scraper_type = self.scraper_type_var.get()
        if scraper_type == "Playwright Scraper":
            asyncio.run(self.scrape_with_playwright(config))
        else:
            scraper = WebScraper(config=config)
            scraper.scrape()
            self.status_label.config(text="Scraping completed!")
            self.show_data_preview(scraper)

    async def scrape_with_playwright(self, config):
        scraper = PlaywrightScraper(config=config)
        await scraper.scrape()
        self.status_label.config(text="Scraping completed!")
        self.show_data_preview(scraper)

    def show_data_preview(self, scraper):
        if isinstance(scraper, WebScraper):
            data = scraper.parse_data(scraper.soup)
        else:
            data = scraper.parse_data(scraper.scraped_content)
        preview_text = "\n\n".join([f"Headers:\n{data['headers']}", f"Paragraphs:\n{data['paragraphs']}", f"Links:\n{data['links']}", f"Tag Analysis:\n{data['tag_analysis']}"])
        self.preview_text.delete("1.0", tk.END)
        self.preview_text.insert(tk.END, preview_text)

    def export_preview(self):
        preview_text = self.preview_text.get("1.0", tk.END)
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if file_path:
            with open(file_path, 'w') as file:
                file.write(preview_text)
            messagebox.showinfo("Success", f"Preview exported to {file_path}")

    def show_visualizations(self):
        output_file = self.output_entry.get()
        file_format = self.output_format_combobox.get()
        visualize_data(output_file, file_format)

if __name__ == "__main__":
    root = ttk.Window(themename="solar")
    app = ScraperApp(root)
    root.mainloop()
