def parse_custom_headers(headers_string):
    headers = {}
    if headers_string:
        for line in headers_string.split('\n'):
            if ': ' in line:
                key, value = line.split(': ', 1)
                headers[key] = value
    return headers
