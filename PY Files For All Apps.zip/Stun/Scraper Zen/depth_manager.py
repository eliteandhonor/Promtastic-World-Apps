class DepthManager:
    def __init__(self, max_depth):
        self.max_depth = max_depth

    def should_continue(self, current_depth):
        return current_depth < self.max_depth
