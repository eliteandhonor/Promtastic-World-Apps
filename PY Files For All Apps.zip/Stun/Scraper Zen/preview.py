import json
import csv

def preview_data(file_path, file_format, lines=5):
    if file_format == 'json':
        with open(file_path, 'r') as f:
            data = json.load(f)
            return data[:lines]
    elif file_format == 'csv':
        with open(file_path, mode='r') as file:
            reader = csv.DictReader(file)
            return [row for _, row in zip(range(lines), reader)]
