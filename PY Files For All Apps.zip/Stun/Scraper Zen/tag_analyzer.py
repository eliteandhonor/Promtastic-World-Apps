from collections import Counter

def analyze_tags(soup):
    tags = [tag.name for tag in soup.find_all()]
    tag_counts = Counter(tags)
    return tag_counts
