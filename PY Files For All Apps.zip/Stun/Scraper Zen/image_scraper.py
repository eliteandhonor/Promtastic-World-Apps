import os
import requests
import logging
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

def sanitize_filename(url):
    parsed_url = urlparse(url)
    filename = os.path.basename(parsed_url.path)
    return "".join(c if c.isalnum() or c in ('.', '_') else '_' for c in filename)

def scrape_images(soup, base_url, image_selector, download_folder):
    logging.info(f"Looking for images with selector: {image_selector}")
    images = soup.select(image_selector)
    if not os.path.exists(download_folder):
        os.makedirs(download_folder)
    for img in images:
        img_url = img.get('src')
        if not img_url:
            continue
        full_url = urljoin(base_url, img_url)
        download_image(full_url, download_folder)

def download_image(url, download_folder):
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        filename = os.path.join(download_folder, sanitize_filename(url))
        with open(filename, 'wb') as file:
            for chunk in response.iter_content(1024):
                file.write(chunk)
        logging.info(f"Image downloaded: {filename}")
    except requests.exceptions.RequestException as e:
        logging.error(f"Failed to download image from {url}: {e}")
