import json
import os

TEMPLATE_FILE = "templates.json"

def load_templates():
    if os.path.exists(TEMPLATE_FILE):
        with open(TEMPLATE_FILE, 'r') as file:
            return json.load(file)
    return {}

def save_template(name, headers):
    templates = load_templates()
    templates[name] = headers
    with open(TEMPLATE_FILE, 'w') as file:
        json.dump(templates, file)

def delete_template(name):
    templates = load_templates()
    if name in templates:
        del templates[name]
        with open(TEMPLATE_FILE, 'w') as file:
            json.dump(templates, file)
