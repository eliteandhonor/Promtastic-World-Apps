import csv

def write_to_csv(data, file_path, delimiter=','):
    try:
        with open(file_path, mode='w', newline='') as file:
            writer = csv.writer(file, delimiter=delimiter)
            writer.writerow(data[0].keys())
            for row in data:
                writer.writerow(row.values())
    except IOError as e:
        print(f"Error writing to CSV: {e}")
