from scraper import Scraper
from log_manager import LogManager
from rate_limiter import RateLimiter
from depth_manager import DepthManager

class MultiSiteScraper:
    def __init__(self, logger, rate_limiter, depth_manager):
        self.logger = logger
        self.rate_limiter = rate_limiter
        self.depth_manager = depth_manager

    def scrape(self, sites):
        all_data = []
        for site in sites:
            scraper = Scraper(self.logger, self.rate_limiter, self.depth_manager)
            data = scraper.scrape(site['url'], site['headers'])
            all_data.append(data)
        return all_data
