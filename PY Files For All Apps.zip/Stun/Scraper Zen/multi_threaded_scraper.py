import threading
from queue import Queue
from scraper import Scraper

class MultiThreadedScraper:
    def __init__(self, logger, rate_limiter, depth_manager, max_threads=10):
        self.logger = logger
        self.rate_limiter = rate_limiter
        self.depth_manager = depth_manager
        self.max_threads = max_threads
        self.queue = Queue()

    def worker(self):
        while not self.queue.empty():
            url, headers = self.queue.get()
            scraper = Scraper(self.logger, self.rate_limiter, self.depth_manager)
            scraper.scrape(url, headers)
            self.queue.task_done()

    def scrape(self, urls, headers):
        for url in urls:
            self.queue.put((url, headers))

        threads = []
        for _ in range(self.max_threads):
            thread = threading.Thread(target=self.worker)
            thread.start()
            threads.append(thread)

        self.queue.join()

        for thread in threads:
            thread.join()
