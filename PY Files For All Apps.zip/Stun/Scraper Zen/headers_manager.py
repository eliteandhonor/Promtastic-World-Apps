def get_headers(custom_headers):
    headers = {}
    if custom_headers:
        for line in custom_headers.split('\n'):
            if ': ' in line:
                key, value = line.split(': ', 1)
                headers[key] = value
    return headers
