import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def visualize_data(file_path, file_format):
    if file_format == 'csv':
        df = pd.read_csv(file_path)
    elif file_format == 'json':
        df = pd.read_json(file_path)
    elif file_format == 'excel':
        df = pd.read_excel(file_path)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")

    if 'headers' in df.columns:
        visualize_headers(df['headers'])
    if 'tag_analysis' in df.columns:
        visualize_tags(df['tag_analysis'])

def visualize_headers(headers):
    header_counts = headers.value_counts()
    header_df = pd.DataFrame({'Header': header_counts.index, 'Count': header_counts.values})
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Header', y='Count', data=header_df, palette="viridis", hue='Header', legend=False)
    plt.title('Header Tag Distribution')
    plt.xlabel('Header Tag')
    plt.ylabel('Count')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def visualize_tags(tag_analysis):
    tag_counts = pd.Series(tag_analysis).value_counts()
    tag_df = pd.DataFrame({'Tag': tag_counts.index, 'Count': tag_counts.values})
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Tag', y='Count', data=tag_df, palette="viridis", hue='Tag', legend=False)
    plt.title('Tag Analysis Distribution')
    plt.xlabel('Tag')
    plt.ylabel('Count')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
