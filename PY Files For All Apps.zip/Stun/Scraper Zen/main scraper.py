import ttkbootstrap as ttk
from gui import ScraperApp

def main():
    root = ttk.Window(themename="solar")
    app = ScraperApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
