import time

class RateLimiter:
    def __init__(self, rate_limit, strategy):
        self.rate_limit = rate_limit
        self.strategy = strategy
        self.last_request_time = None

    def wait(self):
        if self.last_request_time is None:
            self.last_request_time = time.time()
            return

        if self.strategy == 'fixed':
            sleep_time = self.rate_limit - (time.time() - self.last_request_time)
            if sleep_time > 0:
                time.sleep(sleep_time)
        elif self.strategy == 'exponential_backoff':
            sleep_time = self.rate_limit * (2 ** (time.time() - self.last_request_time))
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
