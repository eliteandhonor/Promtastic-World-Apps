import json

def parse_file_formats(format_string):
    try:
        return json.loads(format_string)
    except json.JSONDecodeError:
        return None
