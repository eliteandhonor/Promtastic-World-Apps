import os  # Import the os module!
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QListWidget, QListWidgetItem
from PyQt6.QtCore import Qt, pyqtSignal as Signal
from image_utils import create_image_thumbnail

class PromptList(QWidget):
    prompt_selected = Signal(str, str)

    def __init__(self, prompt_manager):
        super().__init__()
        self.prompt_manager = prompt_manager
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        self.list_label = QLabel("Prompts:")
        self.layout.addWidget(self.list_label)

        self.prompt_list = QListWidget()
        self.prompt_list.itemClicked.connect(self.handle_prompt_selected)
        self.layout.addWidget(self.prompt_list)

        self.prompt_manager.prompts_loaded.connect(self.populate_prompt_list)

    def populate_prompt_list(self, prompts):
        self.prompt_list.clear()
        for prompt_name, category in prompts:
            item = QListWidgetItem(f"{prompt_name} ({category})")
            item.setData(Qt.ItemDataRole.UserRole, (prompt_name, category))

            # Add Image Thumbnail
            prompt_data = self.prompt_manager.get_prompt(prompt_name, category)
            if isinstance(prompt_data, dict) and prompt_data.get("image"):  # Type check added
                image_path = os.path.join(self.prompt_manager.prompt_folder_path, prompt_data["image"])
                thumbnail = create_image_thumbnail(image_path)
                if thumbnail:
                    item.setIcon(thumbnail)

            self.prompt_list.addItem(item)

    def handle_prompt_selected(self, item):
        prompt_name, category = item.data(Qt.ItemDataRole.UserRole)
        self.prompt_selected.emit(prompt_name, category)
