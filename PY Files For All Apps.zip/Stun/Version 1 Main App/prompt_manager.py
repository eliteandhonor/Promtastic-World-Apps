# prompt_manager.py
import json
import os
from PyQt6.QtCore import QObject, pyqtSignal as Signal
from tag_manager import TagManager  # Import TagManager

class PromptManager(QObject):
    prompts_loaded = Signal(list)

    def __init__(self):
        super().__init__()
        self.prompts = {}  # {prompt_name: {category: {content: ..., image: ...}}}
        self.tag_manager = TagManager()  # Associate tags with prompts
        self.prompt_folder_path = self.load_folder_path()
        self.load_prompts()

    def set_prompt_folder_path(self, folder_path):
        self.prompt_folder_path = folder_path
        self.save_folder_path(folder_path)
        self.load_prompts()

    def load_folder_path(self):
        try:
            with open("settings.json", "r") as f:
                settings = json.load(f)
                return settings.get("prompt_folder_path", "")
        except FileNotFoundError:
            return ""

    def save_folder_path(self, folder_path):
        try:
            with open("settings.json", "w") as f:
                json.dump({"prompt_folder_path": folder_path}, f)
        except OSError as e:
            print(f"Error saving settings: {e}")

    def load_prompts(self):
        if not self.prompt_folder_path:
            return

        for root, _, files in os.walk(self.prompt_folder_path):
            for file in files:
                if file.endswith(".json"):
                    category = os.path.relpath(root, self.prompt_folder_path)
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            prompt_data = json.load(f)
                            prompt_name = prompt_data.get("name", "Unnamed Prompt")
                            prompt_text = prompt_data.get("text", "")
                            tags = prompt_data.get("tags", [])  # Load tags
                            self.prompts[(prompt_name, category)] = {
                                "text": prompt_text,
                                "image": None,  # We'll handle images later
                                "tags": tags
                            }
                    except (json.JSONDecodeError, UnicodeDecodeError) as e:
                        print(f"Error loading prompt from {file_path}: {e}")

                elif file.endswith(".txt"):
                    category = os.path.relpath(root, self.prompt_folder_path)
                    file_path = os.path.join(root, file)
                    prompt_name = os.path.splitext(file)[0]
                    
                    # Encoding handling for .txt files
                    encodings_to_try = ['utf-8', 'utf-8-sig', 'latin-1', 'windows-1252'] 

                    for encoding in encodings_to_try:
                        try:
                            with open(file_path, "r", encoding=encoding) as f:
                                prompt_text = f.read()
                                break  # Stop trying encodings if successful
                        except UnicodeDecodeError:
                            continue  # Try the next encoding

                    else: # No encoding worked
                        print(f"Error: Could not decode file {file_path} with any of the tried encodings.")
                        prompt_text = f"Error: Could not decode file {file_path}" 

                    # Find a matching image file
                    image_file = None
                    for ext in [".png", ".jpg", ".jpeg", ".gif"]: 
                        image_path = os.path.join(root, prompt_name + ext)
                        if os.path.exists(image_path):
                            image_file = os.path.relpath(image_path, self.prompt_folder_path)
                            break
                        
                    self.prompts[(prompt_name, category)] = {
                        "text": prompt_text,
                        "image": image_file,
                        "tags": []  # Initialize tags as an empty list
                    }
        
        self.prompts_loaded.emit(list(self.prompts.keys()))

    def load_prompts_for_category(self, category):
        prompts_in_category = [(name, cat) for (name, cat) in self.prompts.keys() if cat == category]
        self.prompts_loaded.emit(prompts_in_category)

    def get_prompt(self, prompt_name, category):
        return self.prompts.get((prompt_name, category))

    def search_prompts(self, search_query):
        matching_prompts = [(name, cat)
                          for (name, cat), data in self.prompts.items()
                          if search_query.lower() in name.lower() or 
                          search_query.lower() in data.get("text", "").lower() or 
                          any(search_query.lower() in tag.lower() for tag in data.get("tags", []))] 
        self.prompts_loaded.emit(matching_prompts)

    def add_prompt(self, prompt_name, category, content, image=None, tags=[]):
        self.prompts[(prompt_name, category)] = {
            "text": content,
            "image": image,
            "tags": tags  # Store the tags in the prompt data
        }

        # Add tags to the TagManager after creating the prompt
        for tag in tags:
            self.tag_manager.add_tag(prompt_name, category, tag) 

        self.prompts_loaded.emit(list(self.prompts.keys()))

    def delete_prompt(self, prompt_name, category):
        if (prompt_name, category) in self.prompts:
            del self.prompts[(prompt_name, category)]
            self.prompts_loaded.emit(list(self.prompts.keys()))