from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QColorDialog, QMessageBox, QFontComboBox, QSpinBox, QCheckBox, QFileDialog,
    QComboBox
)
from PyQt6.QtGui import QColor, QFont, QPixmap
from theme_preview import ThemePreview
import json
import os

class ThemeEditor(QDialog):
    def __init__(self, main_window):
        super().__init__()
        self.setWindowTitle("Theme Editor")
        self.main_window = main_window

        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        # Color Pickers
        self.create_color_picker("Background Color", "background_color")
        self.create_color_picker("Text Color", "text_color")
        self.create_color_picker("Button Color", "button_color")
        self.create_color_picker("Button Text Color", "button_text_color")
        self.create_color_picker("Label Text Color", "label_text_color")
        self.create_color_picker("File Menu Color", "file_menu_color")

        # Font Picker
        self.create_font_picker("Font Family", "font_family")

        # Font Size Picker
        self.create_font_size_picker("Font Size", "font_size")

        # Label Font Size Picker
        self.create_font_size_picker("Label Font Size", "label_font_size")

        # Rounded Corners Checkbox
        self.rounded_corners_checkbox = QCheckBox("Rounded Corners")
        self.rounded_corners_checkbox.setChecked(False)
        self.layout.addWidget(self.rounded_corners_checkbox)

        # Padding and Margin Pickers
        self.create_size_picker("Padding", "padding")
        self.create_size_picker("Margin", "margin")

        # Border Style Picker
        self.create_border_style_picker("Border Style", "border_style")

        # Permanent Image Picker
        self.create_image_picker("Permanent Image", "permanent_image")

        # Button Image/Icon Pickers
        self.create_image_picker("Add Category Button Image", "add_category_button_image")
        self.create_image_picker("Delete Category Button Image", "delete_category_button_image")
        self.create_image_picker("New Prompt Button Image", "new_prompt_button_image")
        self.create_image_picker("View History Button Image", "view_history_button_image")
        self.create_image_picker("View Favorites Button Image", "view_favorites_button_image")

        # Theme Preview
        self.theme_preview = ThemePreview()
        self.layout.addWidget(self.theme_preview)

        # Apply, Save, Load, and Cancel Buttons
        self.create_dialog_buttons()

        # Load Existing Theme Settings
        self.load_theme()

    def create_color_picker(self, label_text, color_key):
        color_layout = QHBoxLayout()
        color_label = QLabel(label_text + ":")
        color_layout.addWidget(color_label)

        color_edit = QLineEdit()
        color_edit.setObjectName(color_key + "_edit")
        color_edit.setReadOnly(True)
        color_layout.addWidget(color_edit)

        color_button = QPushButton("Choose")
        color_button.setObjectName(color_key + "_button")
        color_button.clicked.connect(lambda: self.choose_color(color_edit))
        color_layout.addWidget(color_button)

        self.layout.addLayout(color_layout)

    def create_font_picker(self, label_text, font_key):
        font_layout = QHBoxLayout()
        font_label = QLabel(label_text + ":")
        font_layout.addWidget(font_label)

        font_combo = QFontComboBox()
        font_combo.setObjectName(font_key + "_combo")
        font_layout.addWidget(font_combo)

        self.layout.addLayout(font_layout)

    def create_font_size_picker(self, label_text, size_key):
        size_layout = QHBoxLayout()
        size_label = QLabel(label_text + ":")
        size_layout.addWidget(size_label)

        size_spin = QSpinBox()
        size_spin.setObjectName(size_key + "_spin")
        size_spin.setMinimum(8)
        size_spin.setMaximum(24)
        size_layout.addWidget(size_spin)

        self.layout.addLayout(size_layout)

    def create_size_picker(self, label_text, size_key):
        size_layout = QHBoxLayout()
        size_label = QLabel(label_text + ":")
        size_layout.addWidget(size_label)

        size_edit = QLineEdit()
        size_edit.setObjectName(size_key + "_edit")
        size_layout.addWidget(size_edit)

        self.layout.addLayout(size_layout)

    def create_border_style_picker(self, label_text, style_key):
        style_layout = QHBoxLayout()
        style_label = QLabel(label_text + ":")
        style_layout.addWidget(style_label)

        style_combo = QComboBox()
        style_combo.setObjectName(style_key + "_combo")
        style_combo.addItems(["None", "Solid", "Dashed", "Dotted"])
        style_layout.addWidget(style_combo)

        self.layout.addLayout(style_layout)

    def create_image_picker(self, label_text, image_key):
        image_layout = QHBoxLayout()
        image_label = QLabel(label_text + ":")
        image_layout.addWidget(image_label)

        image_edit = QLineEdit()
        image_edit.setObjectName(image_key + "_edit")
        image_edit.setReadOnly(True)
        image_layout.addWidget(image_edit)

        image_button = QPushButton("Choose")
        image_button.setObjectName(image_key + "_button")
        image_button.clicked.connect(lambda: self.choose_image(image_edit))
        image_layout.addWidget(image_button)

        self.layout.addLayout(image_layout)

    def create_dialog_buttons(self):
        button_layout = QHBoxLayout()

        apply_button = QPushButton("Apply")
        apply_button.clicked.connect(self.apply_theme)
        button_layout.addWidget(apply_button)

        save_button = QPushButton("Save")
        save_button.clicked.connect(self.save_theme_as)
        button_layout.addWidget(save_button)

        load_button = QPushButton("Load")
        load_button.clicked.connect(self.load_theme_from_file)
        button_layout.addWidget(load_button)

        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.close)
        button_layout.addWidget(cancel_button)

        self.layout.addLayout(button_layout)

    def choose_color(self, color_edit):
        color = QColorDialog.getColor(QColor(color_edit.text()), self, "Choose Color")
        if color.isValid():
            color_edit.setText(color.name())
            self.update_theme_preview()

    def choose_image(self, image_edit):
        file_path, _ = QFileDialog.getOpenFileName(self, "Choose Image", "", "Images (*.png *.jpg *.jpeg *.bmp *.gif)")
        if file_path:
            image_edit.setText(file_path)
            self.update_theme_preview()

    def apply_theme(self):
        theme_dict = self.get_theme_dict()
        self.main_window.setStyleSheet(self.generate_stylesheet(theme_dict))
        self.main_window.custom_theme = theme_dict

        # Update the permanent image in the main window
        permanent_image = theme_dict.get("permanent_image", "")
        if permanent_image:
            pixmap = QPixmap(permanent_image)
            if not pixmap.isNull():
                self.main_window.permanent_image_label.setPixmap(pixmap)

        QMessageBox.information(self, "Theme Applied", "The theme has been applied successfully.")
        self.close()

    def save_theme_as(self):
        theme_dict = self.get_theme_dict()
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Theme", "", "JSON Files (*.json)")
        if file_path:
            with open(file_path, "w") as file:
                json.dump(theme_dict, file)
            QMessageBox.information(self, "Theme Saved", "The theme has been saved successfully.")


    def get_theme_dict(self):
        theme_dict = {
            "base_color": self.findChild(QLineEdit, "background_color_edit").text(),
            "text_color": self.findChild(QLineEdit, "text_color_edit").text(),
            "button_color": self.findChild(QLineEdit, "button_color_edit").text(),
            "button_text_color": self.findChild(QLineEdit, "button_text_color_edit").text(),
            "label_text_color": self.findChild(QLineEdit, "label_text_color_edit").text(),
            "file_menu_color": self.findChild(QLineEdit, "file_menu_color_edit").text(),
            "font_family": self.findChild(QFontComboBox, "font_family_combo").currentFont().family(),
            "font_size": self.findChild(QSpinBox, "font_size_spin").value(),
            "label_font_size": self.findChild(QSpinBox, "label_font_size_spin").value(),
            "rounded_corners": self.rounded_corners_checkbox.isChecked(),
            "padding": self.findChild(QLineEdit, "padding_edit").text(),
            "margin": self.findChild(QLineEdit, "margin_edit").text(),
            "border_style": self.findChild(QComboBox, "border_style_combo").currentText(),
            "permanent_image": self.findChild(QLineEdit, "permanent_image_edit").text(),
            "add_category_button_image": self.findChild(QLineEdit, "add_category_button_image_edit").text(),
            "delete_category_button_image": self.findChild(QLineEdit, "delete_category_button_image_edit").text(),
            "new_prompt_button_image": self.findChild(QLineEdit, "new_prompt_button_image_edit").text(),
            "view_history_button_image": self.findChild(QLineEdit, "view_history_button_image_edit").text(),
            "view_favorites_button_image": self.findChild(QLineEdit, "view_favorites_button_image_edit").text()
        }
        return theme_dict

    @staticmethod
    def generate_stylesheet(theme_dict):
        style_sheet = f"""
            QMainWindow {{
                background-color: {theme_dict.get("base_color", "#f0f0f0")};
                color: {theme_dict.get("text_color", "#212121")};
                font: {theme_dict.get("font_size", 12)}pt "{theme_dict.get("font_family", "Arial")}";
                padding: {theme_dict.get("padding", "0")};
                margin: {theme_dict.get("margin", "0")};
                {'border-style: ' + theme_dict.get("border_style", "none") + ';' if theme_dict.get("border_style") != "None" else ''}
            }}
            QPushButton {{
                background-color: {theme_dict.get("button_color", "#2980b9")};
                color: {theme_dict.get("button_text_color", "#ffffff")};
                {'border-radius: 5px;' if theme_dict.get("rounded_corners", False) else ''}
                padding: {theme_dict.get("padding", "0")};
                margin: {theme_dict.get("margin", "0")};
                font: {theme_dict.get("font_size", 12)}pt "{theme_dict.get("font_family", "Arial")}";
            }}
            QLabel {{
                color: {theme_dict.get("label_text_color", "#212121")};
                font: {theme_dict.get("label_font_size", 12)}pt "{theme_dict.get("font_family", "Arial")}";
            }}
            QMenuBar {{
                background-color: {theme_dict.get("base_color", "#f0f0f0")};
            }}
            QMenuBar::item {{
                color: {theme_dict.get("file_menu_color", "#212121")};
            }}
            QMenuBar::item:selected {{
                background-color: transparent;
                color: {theme_dict.get("text_color", "#212121")};
            }}
            QMenu {{
                background-color: {theme_dict.get("base_color", "#f0f0f0")};
                color: {theme_dict.get("text_color", "#212121")};
            }}
            QMenu::item {{
                color: {theme_dict.get("file_menu_color", "#212121")};
            }}
            QMenu::item:selected {{
                background-color: transparent;
                color: {theme_dict.get("text_color", "#212121")};
            }}
        """
        return style_sheet

    def load_theme(self):
        try:
            with open("theme_settings.json", "r") as file:
                theme_dict = json.load(file)
                self.findChild(QLineEdit, "background_color_edit").setText(theme_dict.get("base_color", "#f0f0f0"))
                self.findChild(QLineEdit, "text_color_edit").setText(theme_dict.get("text_color", "#212121"))
                self.findChild(QLineEdit, "button_color_edit").setText(theme_dict.get("button_color", "#2980b9"))
                self.findChild(QLineEdit, "button_text_color_edit").setText(theme_dict.get("button_text_color", "#ffffff"))
                self.findChild(QLineEdit, "label_text_color_edit").setText(theme_dict.get("label_text_color", "#212121"))
                self.findChild(QLineEdit, "file_menu_color_edit").setText(theme_dict.get("file_menu_color", "#f0f0f0"))
                font = QFont(theme_dict.get("font_family", "Arial"))
                self.findChild(QFontComboBox, "font_family_combo").setCurrentFont(font)
                self.findChild(QSpinBox, "font_size_spin").setValue(theme_dict.get("font_size", 12))
                self.findChild(QSpinBox, "label_font_size_spin").setValue(theme_dict.get("label_font_size", 12))
                self.rounded_corners_checkbox.setChecked(theme_dict.get("rounded_corners", False))
                self.findChild(QLineEdit, "padding_edit").setText(theme_dict.get("padding", "0"))
                self.findChild(QLineEdit, "margin_edit").setText(theme_dict.get("margin", "0"))
                border_style = theme_dict.get("border_style", "None")
                index = self.findChild(QComboBox, "border_style_combo").findText(border_style)
                if index >= 0:
                    self.findChild(QComboBox, "border_style_combo").setCurrentIndex(index)
                self.findChild(QLineEdit, "permanent_image_edit").setText(theme_dict.get("permanent_image", ""))
                self.findChild(QLineEdit, "add_category_button_image_edit").setText(theme_dict.get("add_category_button_image", ""))
                self.findChild(QLineEdit, "delete_category_button_image_edit").setText(theme_dict.get("delete_category_button_image", ""))
                self.findChild(QLineEdit, "new_prompt_button_image_edit").setText(theme_dict.get("new_prompt_button_image", ""))
                self.findChild(QLineEdit, "view_history_button_image_edit").setText(theme_dict.get("view_history_button_image", ""))
                self.findChild(QLineEdit, "view_favorites_button_image_edit").setText(theme_dict.get("view_favorites_button_image", ""))
                self.update_theme_preview()
        except FileNotFoundError:
            pass

    def load_theme_from_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Load Theme", "", "JSON Files (*.json)")
        if file_path:
            try:
                with open(file_path, "r") as file:
                    theme_dict = json.load(file)
                    self.findChild(QLineEdit, "background_color_edit").setText(theme_dict.get("base_color", "#f0f0f0"))
                    self.findChild(QLineEdit, "text_color_edit").setText(theme_dict.get("text_color", "#212121"))
                    self.findChild(QLineEdit, "button_color_edit").setText(theme_dict.get("button_color", "#2980b9"))
                    self.findChild(QLineEdit, "button_text_color_edit").setText(theme_dict.get("button_text_color", "#ffffff"))
                    self.findChild(QLineEdit, "label_text_color_edit").setText(theme_dict.get("label_text_color", "#212121"))
                    self.findChild(QLineEdit, "file_menu_color_edit").setText(theme_dict.get("file_menu_color", "#f0f0f0"))
                    font = QFont(theme_dict.get("font_family", "Arial"))
                    self.findChild(QFontComboBox, "font_family_combo").setCurrentFont(font)
                    self.findChild(QSpinBox, "font_size_spin").setValue(theme_dict.get("font_size", 12))
                    self.findChild(QSpinBox, "label_font_size_spin").setValue(theme_dict.get("label_font_size", 12))
                    self.rounded_corners_checkbox.setChecked(theme_dict.get("rounded_corners", False))
                    self.findChild(QLineEdit, "padding_edit").setText(theme_dict.get("padding", "0"))
                    self.findChild(QLineEdit, "margin_edit").setText(theme_dict.get("margin", "0"))
                    border_style = theme_dict.get("border_style", "None")
                    index = self.findChild(QComboBox, "border_style_combo").findText(border_style)
                    if index >= 0:
                        self.findChild(QComboBox, "border_style_combo").setCurrentIndex(index)
                    self.findChild(QLineEdit, "permanent_image_edit").setText(theme_dict.get("permanent_image", ""))
                    self.findChild(QLineEdit, "add_category_button_image_edit").setText(theme_dict.get("add_category_button_image", ""))
                    self.findChild(QLineEdit, "delete_category_button_image_edit").setText(theme_dict.get("delete_category_button_image", ""))
                    self.findChild(QLineEdit, "new_prompt_button_image_edit").setText(theme_dict.get("new_prompt_button_image", ""))
                    self.findChild(QLineEdit, "view_history_button_image_edit").setText(theme_dict.get("view_history_button_image", ""))
                    self.findChild(QLineEdit, "view_favorites_button_image_edit").setText(theme_dict.get("view_favorites_button_image", ""))
                    self.update_theme_preview()
            except (json.JSONDecodeError, FileNotFoundError) as e:
                QMessageBox.warning(self, "Error", f"Error loading theme: {e}")

    def update_theme_preview(self):
        theme_dict = self.get_theme_dict()
        theme_dict["font_size"] = self.findChild(QSpinBox, "font_size_spin").value()
        self.theme_preview.set_theme(theme_dict)

        permanent_image = theme_dict.get("permanent_image", "")
        if permanent_image:
            pixmap = QPixmap(permanent_image)
            if not pixmap.isNull():
                self.theme_preview.permanent_image_label.setPixmap(pixmap)
        else:
            self.theme_preview.permanent_image_label.clear()