import json
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QListWidget, QPushButton, QMessageBox, QHBoxLayout
)
from PyQt6.QtCore import Qt, pyqtSignal as Signal

class FavoritesManager(QDialog):
    favorites_changed = Signal()
    load_prompt = Signal(str, str)  

    def __init__(self):  
        super().__init__()
        self.setWindowTitle("Favorite Prompts")
        self.favorites = []
        self.favorites_file = "favorites.json"
        self._load_favorites()

        layout = QVBoxLayout()
        self.setLayout(layout)

        self.favorites_list = QListWidget()
        self.favorites_list.itemDoubleClicked.connect(self.handle_item_double_clicked)
        layout.addWidget(self.favorites_list)

        # Buttons Layout
        button_layout = QHBoxLayout()

        clear_button = QPushButton("Clear Favorites")
        clear_button.clicked.connect(self.clear_favorites)
        button_layout.addWidget(clear_button)

        delete_button = QPushButton("Delete") 
        delete_button.clicked.connect(self.delete_selected_favorite)
        button_layout.addWidget(delete_button)

        layout.addLayout(button_layout) 

        self._populate_favorites_list()

    def add_favorite(self, prompt_name: str, category: str) -> None:
        if (prompt_name, category) not in self.favorites:  
            self.favorites.append((prompt_name, category))
            self._save_favorites()
            self._populate_favorites_list()
            QMessageBox.information(
                self, "Added to Favorites",
                f"Prompt '{prompt_name}' added to favorites."
            )
            self.favorites_changed.emit()

    def remove_favorite(self, prompt_name: str, category: str) -> None:
        if (prompt_name, category) in self.favorites:
            self.favorites.remove((prompt_name, category))
            self._save_favorites()
            self._populate_favorites_list()
            QMessageBox.information(
                self, "Removed from Favorites",
                f"Prompt '{prompt_name}' removed from favorites."
            )
            self.favorites_changed.emit()

    def clear_favorites(self) -> None:
        confirm = QMessageBox.question(
            self, "Confirm Clear",
            "Are you sure you want to clear all favorites?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm == QMessageBox.StandardButton.Yes:
            self.favorites = []
            self._save_favorites()
            self._populate_favorites_list()
            self.favorites_changed.emit()

    def handle_item_double_clicked(self, item: QListWidget.item) -> None:
        prompt_name, category = self.favorites[self.favorites_list.row(item)]
        self.load_prompt.emit(prompt_name, category)  
        self.close()

    def _load_favorites(self) -> None:
        try:
            with open(self.favorites_file, "r", encoding="utf-8") as f:
                self.favorites = json.load(f)
        except FileNotFoundError:
            pass
        except json.JSONDecodeError:
            QMessageBox.warning(self, "Error", "Failed to load favorites. The file might be corrupted.")

    def _save_favorites(self) -> None:
        with open(self.favorites_file, "w", encoding="utf-8") as f:
            json.dump(self.favorites, f, ensure_ascii=False, indent=4)

    def _populate_favorites_list(self) -> None:
        self.favorites_list.clear()
        for prompt_name, category in self.favorites:
            self.favorites_list.addItem(f"{prompt_name} ({category})")

    def toggle_favorite(self, prompt_name: str, category: str) -> None:
        if (prompt_name, category) in self.favorites:
            self.remove_favorite(prompt_name, category)
        else:
            self.add_favorite(prompt_name, category)

    def is_favorite(self, prompt_name: str, category: str) -> bool:
        return (prompt_name, category) in self.favorites

    def delete_selected_favorite(self) -> None:
        selected_item = self.favorites_list.currentItem()
        if selected_item:
            prompt_text = selected_item.text()
            try:
                last_open_paren = prompt_text.rfind("(")
                prompt_name = prompt_text[:last_open_paren].strip()
                category = prompt_text[last_open_paren + 1:-1].strip()
                self.remove_favorite(prompt_name, category)
                self.favorites_list.takeItem(self.favorites_list.row(selected_item))
            except ValueError:
                QMessageBox.warning(self, "Error", "Could not determine prompt name and category.") 
        else:
            QMessageBox.warning(self, "No Selection", "Please select a favorite to delete.")
