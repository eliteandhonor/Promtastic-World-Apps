from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
    QPushButton, QFileDialog, QMessageBox, QTextEdit
)
from PyQt6.QtCore import Qt
import os

class NewPromptDialog(QDialog):
    def __init__(self, prompt_manager, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Create New Prompt")
        self.prompt_manager = prompt_manager
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        # Prompt Name
        name_layout = QHBoxLayout()
        name_label = QLabel("Prompt Name:")
        name_layout.addWidget(name_label)
        self.name_edit = QLineEdit()
        name_layout.addWidget(self.name_edit)
        self.layout.addLayout(name_layout)

        # Category
        category_layout = QHBoxLayout()
        category_label = QLabel("Category:")
        category_layout.addWidget(category_label)
        self.category_edit = QLineEdit()
        category_layout.addWidget(self.category_edit)
        self.layout.addLayout(category_layout)

        # Prompt Text
        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText("Enter your prompt text here...")
        self.layout.addWidget(self.text_edit)

        # Image (Optional)
        image_layout = QHBoxLayout()
        image_label = QLabel("Image (Optional):")
        image_layout.addWidget(image_label)
        self.image_edit = QLineEdit()
        self.image_edit.setReadOnly(True)
        image_layout.addWidget(self.image_edit)
        image_button = QPushButton("Choose Image")
        image_button.clicked.connect(self.choose_image)
        image_layout.addWidget(image_button)
        self.layout.addLayout(image_layout)

        # Tags (Optional)
        tags_layout = QHBoxLayout()
        tags_label = QLabel("Tags (comma-separated, optional):")
        tags_layout.addWidget(tags_label)
        self.tags_edit = QLineEdit()
        tags_layout.addWidget(self.tags_edit)
        self.layout.addLayout(tags_layout)

        # Buttons
        button_layout = QHBoxLayout()
        create_button = QPushButton("Create")
        create_button.clicked.connect(self.create_prompt)
        button_layout.addWidget(create_button)
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.close)
        button_layout.addWidget(cancel_button)
        self.layout.addLayout(button_layout)

    def choose_image(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(self, "Choose Image", "", "Images (*.png *.jpg *.jpeg)")
        if file_path:
            self.image_edit.setText(file_path)

    def create_prompt(self) -> None:
        prompt_name = self.name_edit.text().strip()
        category = self.category_edit.text().strip()
        content = self.text_edit.toPlainText().strip()
        image_path = self.image_edit.text().strip()
        tags = [tag.strip() for tag in self.tags_edit.text().split(",") if tag.strip()]

        if not prompt_name:
            QMessageBox.warning(self, "Error", "Please enter a prompt name.")
            return
        if not category:
            QMessageBox.warning(self, "Error", "Please enter a category.")
            return

        # Validate the image path if one is provided
        if image_path:
            if not os.path.isfile(image_path):
                QMessageBox.warning(self, "Error", "Invalid image path.")
                return

        # Get relative image path if there is an image
        relative_image_path = None 
        if image_path:
            try:
                relative_image_path = os.path.relpath(image_path, self.prompt_manager.prompt_folder_path)
            except ValueError:
                QMessageBox.warning(self, "Error", "Invalid image path relative to the prompt folder.")
                return

        self.prompt_manager.add_prompt(prompt_name, category, content, relative_image_path, tags)
        self.close()
