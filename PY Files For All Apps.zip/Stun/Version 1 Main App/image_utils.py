import os
from PyQt6.QtGui import QPixmap, QIcon
from PyQt6.QtCore import Qt
from typing import Union

def create_image_thumbnail(image_path: str, max_width: int = 64, max_height: int = 64) -> Union[QIcon, None]:
    """Creates a QIcon thumbnail from an image file.

    Args:
        image_path (str): The path to the image file.
        max_width (int): The maximum width of the thumbnail.
        max_height (int): The maximum height of the thumbnail.

    Returns:
        QIcon: The thumbnail as a QIcon, or None if the image cannot be loaded.
    """
    if not image_path or not os.path.exists(image_path):
        return None

    pixmap = QPixmap(image_path)
    if pixmap.isNull():
        return None

    return QIcon(pixmap.scaled(
        max_width, max_height, 
        Qt.AspectRatioMode.KeepAspectRatio, 
        Qt.TransformationMode.SmoothTransformation
    ))
