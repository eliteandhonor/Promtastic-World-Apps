DEFAULT_STYLE = """
/* Base Styles */
QWidget {
    background-color: #f0f0f0;
    color: #212121;
    font-family: Arial, sans-serif;
}

/* Labels */
QLabel {
    font-weight: bold;
}

/* Text Edit */
QTextEdit {
    background-color: white;
    border: 1px solid #ddd;
}

/* Buttons */
QPushButton {
    background-color: #2980b9; /* Blue */
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
}

QPushButton:hover {
    background-color: #3498db; /* Darker Blue */
}

/* Combo Box */
QComboBox {
    border: 1px solid #ddd;
    padding: 4px 8px;
    border-radius: 4px;
}

/* Tree Widget */
QTreeWidget {
    background-color: white;
    border: 1px solid #ddd;
}

QTreeWidget::item:selected {
    background-color: #e9e9e9;
}
"""

DARK_STYLE = """
/* Base Styles */
QWidget {
    background-color: #181818;
    color: #f0f0f0;
    font-family: Arial, sans-serif;
}

/* Labels */
QLabel {
    font-weight: bold;
    color: #f0f0f0;
}

/* Text Edit */
QTextEdit {
    background-color: #212121;
    color: #f0f0f0;
    border: 1px solid #444;
}

/* Buttons */
QPushButton {
    background-color: #344955; /* Dark Gray */
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
}

QPushButton:hover {
    background-color: #415a6d; /* Slightly Lighter Dark Gray */
}

/* Combo Box */
QComboBox {
    background-color: #212121;
    color: #f0f0f0;
    border: 1px solid #444;
    padding: 4px 8px;
    border-radius: 4px;
}

/* Tree Widget */
QTreeWidget {
    background-color: #212121;
    color: #f0f0f0;
    border: 1px solid #444;
}

QTreeWidget::item:selected {
    background-color: #344955;
}
"""

LIGHT_STYLE = """
/* Base Styles */
QWidget {
    background-color: white;
    color: #212121;
    font-family: Arial, sans-serif;
}

/* Labels */
QLabel {
    font-weight: bold;
}

/* Text Edit */
QTextEdit {
    background-color: white;
    border: 1px solid #ddd;
}

/* Buttons */
QPushButton {
    background-color: #27ae60; /* Green */
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
}

QPushButton:hover {
    background-color: #2ecc71; /* Lighter Green */
}

/* Combo Box */
QComboBox {
    border: 1px solid #ddd;
    padding: 4px 8px;
    border-radius: 4px;
}

/* Tree Widget */
QTreeWidget {
    background-color: white;
    border: 1px solid #ddd;
}

QTreeWidget::item:selected {
    background-color: #e9e9e9;
}
"""

CUSTOM_STYLE = ""  # Will be populated from settings.json
