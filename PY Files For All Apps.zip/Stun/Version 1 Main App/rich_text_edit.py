from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QTextEdit, QToolBar, QFontDialog, QColorDialog, QFileDialog
)
from PyQt6.QtGui import (
    QFont, QTextCursor, QTextCharFormat, QIcon, QAction, QKeySequence, QTextBlockFormat,
    QTextDocument, QTextListFormat, QTextImageFormat
)
from PyQt6.QtCore import Qt
from PyQt6.QtPrintSupport import QPrinter, QPrintDialog, QAbstractPrintDialog

class RichTextEdit(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)

        # Create QTextEdit Widget
        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText("Enter your prompt here...")
        self.layout.addWidget(self.text_edit)

        # Create Toolbar
        self.toolbar = QToolBar("Formatting")
        self.layout.addWidget(self.toolbar)
        self.add_toolbar_actions()

    def add_toolbar_actions(self):
        # Bold Action
        bold_action = QAction(QIcon.fromTheme("format-text-bold"), "Bold", self)
        bold_action.setShortcut(QKeySequence("Ctrl+B"))
        bold_action.triggered.connect(self.toggle_bold)
        bold_action.setCheckable(True)
        self.toolbar.addAction(bold_action)

        # Italic Action
        italic_action = QAction(QIcon.fromTheme("format-text-italic"), "Italic", self)
        italic_action.setShortcut(QKeySequence("Ctrl+I"))
        italic_action.triggered.connect(self.toggle_italic)
        italic_action.setCheckable(True)
        self.toolbar.addAction(italic_action)

        # Underline Action
        underline_action = QAction(QIcon.fromTheme("format-text-underline"), "Underline", self)
        underline_action.setShortcut(QKeySequence("Ctrl+U"))
        underline_action.triggered.connect(self.toggle_underline)
        underline_action.setCheckable(True)
        self.toolbar.addAction(underline_action)

        # Font Action
        font_action = QAction(QIcon.fromTheme("font-select"), "Font", self)
        font_action.triggered.connect(self.change_font)
        self.toolbar.addAction(font_action)

        # Text Color Action
        color_action = QAction(QIcon.fromTheme("color-select"), "Text Color", self)
        color_action.triggered.connect(self.change_text_color)
        self.toolbar.addAction(color_action)

        # Text Alignment Actions
        align_left_action = QAction(QIcon.fromTheme("format-justify-left"), "Align Left", self)
        align_left_action.triggered.connect(lambda: self.text_edit.setAlignment(Qt.AlignmentFlag.AlignLeft))
        self.toolbar.addAction(align_left_action)

        align_center_action = QAction(QIcon.fromTheme("format-justify-center"), "Align Center", self)
        align_center_action.triggered.connect(lambda: self.text_edit.setAlignment(Qt.AlignmentFlag.AlignCenter))
        self.toolbar.addAction(align_center_action)

        align_right_action = QAction(QIcon.fromTheme("format-justify-right"), "Align Right", self)
        align_right_action.triggered.connect(lambda: self.text_edit.setAlignment(Qt.AlignmentFlag.AlignRight))
        self.toolbar.addAction(align_right_action)

        align_justify_action = QAction(QIcon.fromTheme("format-justify-fill"), "Justify", self)
        align_justify_action.triggered.connect(lambda: self.text_edit.setAlignment(Qt.AlignmentFlag.AlignJustify))
        self.toolbar.addAction(align_justify_action)

        # Undo and Redo Actions
        undo_action = QAction(QIcon.fromTheme("edit-undo"), "Undo", self)
        undo_action.setShortcut(QKeySequence.StandardKey.Undo)
        undo_action.triggered.connect(self.text_edit.undo)
        self.toolbar.addAction(undo_action)

        redo_action = QAction(QIcon.fromTheme("edit-redo"), "Redo", self)
        redo_action.setShortcut(QKeySequence.StandardKey.Redo)
        redo_action.triggered.connect(self.text_edit.redo)
        self.toolbar.addAction(redo_action)

        # Image Action
        image_action = QAction(QIcon.fromTheme("insert-image"), "Insert Image", self)
        image_action.triggered.connect(self.insert_image)
        self.toolbar.addAction(image_action)

        # Clear Formatting Action
        clear_format_action = QAction(QIcon.fromTheme("edit-clear"), "Clear Formatting", self)
        clear_format_action.triggered.connect(self.clear_formatting)
        self.toolbar.addAction(clear_format_action)

        # Bullet List Action
        bullet_list_action = QAction(QIcon.fromTheme("format-list-bulleted"), "Bullet List", self)
        bullet_list_action.triggered.connect(self.create_bullet_list)
        self.toolbar.addAction(bullet_list_action)

        # Numbered List Action
        numbered_list_action = QAction(QIcon.fromTheme("format-list-numbered"), "Numbered List", self)
        numbered_list_action.triggered.connect(self.create_numbered_list)
        self.toolbar.addAction(numbered_list_action)

        # Print Action
        print_action = QAction(QIcon.fromTheme("document-print"), "Print", self)
        print_action.triggered.connect(self.print_document)
        self.toolbar.addAction(print_action)

        # Save Action
        save_action = QAction(QIcon.fromTheme("document-save"), "Save", self)
        save_action.triggered.connect(self.save_document)
        self.toolbar.addAction(save_action)

    def toggle_bold(self):
        fmt = QTextCharFormat()
        fmt.setFontWeight(QFont.Weight.Bold if self.text_edit.fontWeight() != QFont.Weight.Bold else QFont.Weight.Normal)
        self.merge_format_on_selection(fmt)

    def toggle_italic(self):
        fmt = QTextCharFormat()
        fmt.setFontItalic(not self.text_edit.fontItalic())
        self.merge_format_on_selection(fmt)

    def toggle_underline(self):
        fmt = QTextCharFormat()
        fmt.setFontUnderline(not self.text_edit.fontUnderline())
        self.merge_format_on_selection(fmt)

    def change_font(self):
        current_font = self.text_edit.currentFont()
        font, ok = QFontDialog.getFont(current_font, self, "Select a Font")
        if ok:
            self.text_edit.setCurrentFont(font)

    def change_text_color(self):
        color = QColorDialog.getColor(self.text_edit.textColor(), self, "Select Text Color")
        if color.isValid():
            cursor = self.text_edit.textCursor()
            fmt = cursor.charFormat()
            fmt.setForeground(color)
            cursor.mergeCharFormat(fmt)
            self.text_edit.mergeCurrentCharFormat(fmt)

    def insert_image(self):
        file_dialog = QFileDialog(self)
        file_dialog.setNameFilter("Images (*.png *.jpg *.jpeg *.bmp *.gif)")
        if file_dialog.exec():
            image_file = file_dialog.selectedFiles()[0]
            image_format = QTextImageFormat()
            image_format.setName(image_file)
            cursor = self.text_edit.textCursor()
            cursor.insertImage(image_format)

    def clear_formatting(self):
        cursor = self.text_edit.textCursor()
        if not cursor.hasSelection():
            cursor.select(QTextCursor.SelectionType.WordUnderCursor)
        char_format = QTextCharFormat()
        cursor.setCharFormat(char_format)
        self.text_edit.setCurrentCharFormat(char_format)

    def create_bullet_list(self):
        cursor = self.text_edit.textCursor()
        list_format = QTextListFormat()
        list_format.setStyle(QTextListFormat.Style.ListDisc)
        cursor.insertList(list_format)

    def create_numbered_list(self):
        cursor = self.text_edit.textCursor()
        list_format = QTextListFormat()
        list_format.setStyle(QTextListFormat.Style.ListDecimal)
        cursor.insertList(list_format)

    def print_document(self):
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        dialog = QPrintDialog(printer, self)
        if dialog.exec() == QAbstractPrintDialog.DialogCode.Accepted:
            self.text_edit.print_(printer)

    def save_document(self):
        file_dialog = QFileDialog(self)
        file_dialog.setAcceptMode(QFileDialog.AcceptMode.AcceptSave)
        file_dialog.setNameFilter("Text Files (*.txt);;HTML Files (*.html);;JSON Files (*.json);;CSV Files (*.csv);;XML Files (*.xml);;Microsoft Word Files (*.doc *.docx)")
        if file_dialog.exec():
            file_path = file_dialog.selectedFiles()[0]
            file_format = file_dialog.selectedNameFilter()
            if file_format == "Text Files (*.txt)":
                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(self.text_edit.toPlainText())
            elif file_format == "HTML Files (*.html)":
                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(self.text_edit.toHtml())
            elif file_format == "JSON Files (*.json)":
                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(self.text_edit.toPlainText())
            elif file_format == "CSV Files (*.csv)":
                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(self.text_edit.toPlainText())
            elif file_format == "XML Files (*.xml)":
                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(self.text_edit.toPlainText())
            elif file_format == "Microsoft Word Files (*.doc *.docx)":
                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(self.text_edit.toPlainText())

    def get_text(self) -> str:
        return self.text_edit.toHtml()

    def clear(self) -> None:
        """Clears the text content of the QTextEdit."""
        self.text_edit.clear()

    def merge_format_on_selection(self, format: QTextCharFormat) -> None:
        cursor = self.text_edit.textCursor()
        if not cursor.hasSelection():
            cursor.select(QTextCursor.SelectionType.WordUnderCursor)
        cursor.mergeCharFormat(format)
        self.text_edit.mergeCurrentCharFormat(format)
