# main_window.py
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFileDialog, QMessageBox,
                             QPushButton, QLabel)
from PyQt6.QtGui import QAction, QKeySequence, QPixmap, QIcon, QCursor
from PyQt6.QtCore import Qt
from category_tree import CategoryTree
from search_bar import SearchBar
from prompt_display import PromptDisplay
from prompt_history import PromptHistory
from favorites_manager import FavoritesManager
from theme_manager import ThemeManager
from prompt_manager import PromptManager
from resources import DEFAULT_STYLE, DARK_STYLE, LIGHT_STYLE
from prompt_list import PromptList
from tag_manager import TagManager
from shortcuts_manager import ShortcutsManager
from theme_editor import ThemeEditor
from new_prompt_dialog import NewPromptDialog
import json
import os

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Promptastic")
        self.setGeometry(100, 100, 1000, 600)

        # Core Modules
        self.prompt_manager = PromptManager()

        # Create category_tree after prompt_manager
        self.category_tree = CategoryTree(self.prompt_manager)
        self.search_bar = SearchBar(self.prompt_manager)
        self.prompt_history = PromptHistory()
        self.favorites_manager = FavoritesManager()
        self.prompt_display = PromptDisplay(self.prompt_manager, self.favorites_manager)
        self.theme_manager = ThemeManager()
        self.prompt_list = PromptList(self.prompt_manager)

        # Initialize TagManager
        self.tag_manager = TagManager()
        # Connect PromptManager to TagManager
        self.prompt_manager.tag_manager = self.tag_manager

        # Central Widget and Layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)

        # Left Side (Category Tree, Search Bar, Prompt List)
        left_layout = QVBoxLayout()
        left_layout.addWidget(self.category_tree)
        left_layout.addWidget(self.search_bar)
        left_layout.addWidget(self.prompt_list)

        # Add New Prompt Image/Icon
        self.new_prompt_image = QLabel()
        self.new_prompt_image.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.new_prompt_image.mouseReleaseEvent = self.create_new_prompt
        left_layout.addWidget(self.new_prompt_image)

        # View History Image/Icon
        self.view_history_image = QLabel()
        self.view_history_image.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.view_history_image.mouseReleaseEvent = self.prompt_history.show
        left_layout.addWidget(self.view_history_image)

        # View Favorites Image/Icon
        self.view_favorites_image = QLabel()
        self.view_favorites_image.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.view_favorites_image.mouseReleaseEvent = self.favorites_manager.show
        left_layout.addWidget(self.view_favorites_image)

        main_layout.addLayout(left_layout)

        # Right Side (Prompt Display)
        right_layout = QVBoxLayout()
        right_layout.addWidget(self.prompt_display)

        # Permanent Background Image
        self.permanent_image_label = QLabel()
        self.permanent_image_label.setScaledContents(False)
        self.permanent_image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        right_layout.addWidget(self.permanent_image_label)

        main_layout.addLayout(right_layout)

        # Menu Bar
        self._create_menu_bar()

        # Connect Signals and Slots
        self._connect_signals_slots()

        # Initialize custom_theme as an empty dictionary
        self.custom_theme = {}

        # Apply Default Style
        self.load_settings()

        # Store the currently selected category
        self.current_category = ""

        # Initialize Shortcuts Manager
        self.shortcuts_manager = ShortcutsManager(self)

    def showEvent(self, event):
        super().showEvent(event)
        # Load categories from the JSON file after the main window is shown
        self.category_tree.load_categories()

    def _create_menu_bar(self):
        menubar = self.menuBar()

        # File Menu
        file_menu = menubar.addMenu("File")
        set_folder_action = QAction("Set Prompt Folder", self)
        set_folder_action.triggered.connect(self.set_prompt_folder)
        file_menu.addAction(set_folder_action)

        import_action = QAction("Import Prompts", self)
        import_action.triggered.connect(self.import_prompts)
        file_menu.addAction(import_action)

        export_action = QAction("Export Prompts", self)
        export_action.triggered.connect(self.export_prompts)
        file_menu.addAction(export_action)

        # Options Menu
        options_menu = menubar.addMenu("Options")
        change_theme_action = QAction("Change Theme", self)
        change_theme_action.triggered.connect(self.theme_manager.show)
        options_menu.addAction(change_theme_action)

        # Add Theme Editor Action
        theme_editor_action = QAction("Theme Editor", self)
        theme_editor_action.triggered.connect(self.open_theme_editor)
        options_menu.addAction(theme_editor_action)

        # View Menu
        view_menu = menubar.addMenu("View")
        view_history_action = QAction("View History", self)
        view_history_action.triggered.connect(self.prompt_history.show)
        view_menu.addAction(view_history_action)
        view_favorites_action = QAction("View Favorites", self)
        view_favorites_action.triggered.connect(self.favorites_manager.show)
        view_menu.addAction(view_favorites_action)

    def _connect_signals_slots(self):
        self.category_tree.category_selected.connect(self.update_current_category)
        self.search_bar.search_triggered.connect(self.prompt_manager.search_prompts)
        self.prompt_manager.prompts_loaded.connect(self.prompt_list.populate_prompt_list)
        self.prompt_list.prompt_selected.connect(self.prompt_display.display_prompt)
        self.prompt_list.prompt_selected.connect(self.prompt_history.add_prompt)
        self.prompt_list.prompt_selected.connect(self.update_background_image)
        self.prompt_display.favorite_clicked.connect(self.favorites_manager.toggle_favorite)
        self.prompt_display.prompt_selected.connect(self.handle_tag_selected)
        self.prompt_history.load_prompt.connect(self.prompt_display.display_prompt)
        self.favorites_manager.load_prompt.connect(self.prompt_display.display_prompt)
        self.theme_manager.theme_changed.connect(self.apply_theme)
        self.prompt_display.delete_tag_requested.connect(self.delete_tag)

    def update_background_image(self, prompt_name, category):
        prompt_data = self.prompt_manager.get_prompt(prompt_name, category)
        if prompt_data:
            image_file = prompt_data.get("image")
            if image_file:
                image_path = os.path.join(self.prompt_manager.prompt_folder_path, image_file)
                pixmap = QPixmap(image_path)
                if not pixmap.isNull():
                    # Scale the image while maintaining the aspect ratio
                    scaled_pixmap = pixmap.scaled(self.permanent_image_label.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                    self.permanent_image_label.setPixmap(scaled_pixmap)
                    self.permanent_image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                    return

        # If no prompt image or invalid image, set the permanent image from the custom theme
        permanent_image = self.custom_theme.get("permanent_image", "")
        if permanent_image:
            pixmap = QPixmap(permanent_image)
            if not pixmap.isNull():
                # Scale the image while maintaining the aspect ratio
                scaled_pixmap = pixmap.scaled(self.permanent_image_label.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                self.permanent_image_label.setPixmap(scaled_pixmap)
                self.permanent_image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        else:
            self.permanent_image_label.clear()

    def apply_theme(self, theme_name):
        if theme_name == "default":
            self.setStyleSheet(DEFAULT_STYLE)
            self.custom_theme = {}  # Clear the custom theme when switching to a predefined theme
        elif theme_name == "dark":
            self.setStyleSheet(DARK_STYLE)
            self.custom_theme = {}  # Clear the custom theme when switching to a predefined theme
        elif theme_name == "light":
            self.setStyleSheet(LIGHT_STYLE)
            self.custom_theme = {}  # Clear the custom theme when switching to a predefined theme
        elif theme_name == "custom":
            # Call the generate_stylesheet function from the ThemeEditor class
            self.setStyleSheet(ThemeEditor.generate_stylesheet(self.custom_theme))
        self.save_settings()

        # Update image/icon labels based on the custom theme
        if self.custom_theme:
            add_category_image_path = self.custom_theme.get("add_category_button_image", "")
            if add_category_image_path:
                pixmap = QPixmap(add_category_image_path)
                self.category_tree.add_image.setPixmap(pixmap.scaled(32, 32, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                self.category_tree.add_image.setVisible(True)
                self.category_tree.add_button.setVisible(False)
            else:
                self.category_tree.add_image.setVisible(False)
                self.category_tree.add_button.setVisible(True)

            delete_category_image_path = self.custom_theme.get("delete_category_button_image", "")
            if delete_category_image_path:
                pixmap = QPixmap(delete_category_image_path)
                self.category_tree.delete_image.setPixmap(pixmap.scaled(32, 32, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                self.category_tree.delete_image.setVisible(True)
                self.category_tree.delete_button.setVisible(False)
            else:
                self.category_tree.delete_image.setVisible(False)
                self.category_tree.delete_button.setVisible(True)

            new_prompt_image_path = self.custom_theme.get("new_prompt_button_image", "")
            if new_prompt_image_path:
                pixmap = QPixmap(new_prompt_image_path)
                self.new_prompt_image.setPixmap(pixmap.scaled(32, 32, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                self.new_prompt_image.setVisible(True)
            else:
                self.new_prompt_image.setVisible(False)

            view_history_image_path = self.custom_theme.get("view_history_button_image", "")
            if view_history_image_path:
                pixmap = QPixmap(view_history_image_path)
                self.view_history_image.setPixmap(pixmap.scaled(32, 32, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                self.view_history_image.setVisible(True)
            else:
                self.view_history_image.setVisible(False)

            view_favorites_image_path = self.custom_theme.get("view_favorites_button_image", "")
            if view_favorites_image_path:
                pixmap = QPixmap(view_favorites_image_path)
                self.view_favorites_image.setPixmap(pixmap.scaled(32, 32, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                self.view_favorites_image.setVisible(True)
            else:
                self.view_favorites_image.setVisible(False)
        else:
            # If no custom theme is set, hide the image labels and show the buttons
            self.category_tree.add_image.setVisible(False)
            self.category_tree.add_button.setVisible(True)
            self.category_tree.delete_image.setVisible(False)
            self.category_tree.delete_button.setVisible(True)
            self.new_prompt_image.setVisible(False)
            self.view_history_image.setVisible(False)
            self.view_favorites_image.setVisible(False)
    def set_prompt_folder(self):
        folder_path = QFileDialog.getExistingDirectory(self, "Select Prompt Folder")
        if folder_path:
            self.prompt_manager.set_prompt_folder_path(folder_path)
            self.prompt_manager.load_prompts()
            self.category_tree.populate_tree(self.prompt_manager.prompts)

    def import_prompts(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Import Prompts", "", "JSON Files (*.json)")
        if file_path:
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.prompt_manager.prompts.update(data)
                self.prompt_manager.prompts_loaded.emit(list(self.prompt_manager.prompts.keys()))
                QMessageBox.information(self, "Import Successful", "Prompts imported successfully.")
            except (json.JSONDecodeError, UnicodeDecodeError, OSError) as e:
                QMessageBox.warning(self, "Import Error", f"Error importing prompts: {e}")

    def export_prompts(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Export Prompts", "", "JSON Files (*.json)")
        if file_path:
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(self.prompt_manager.prompts, f, indent=4)
                QMessageBox.information(self, "Export Successful", "Prompts exported successfully.")
            except (TypeError, OSError) as e:
                QMessageBox.warning(self, "Export Error", f"Error exporting prompts: {e}")

    def load_settings(self):
        try:
            with open("settings.json", "r") as f:
                settings = json.load(f)
                theme = settings.get("theme", "default")
                self.custom_theme = settings.get("custom_theme", {})
                self.apply_theme(theme)
                prompt_folder_path = settings.get("prompt_folder_path", "")
                if prompt_folder_path:
                    self.prompt_manager.set_prompt_folder_path(prompt_folder_path)
                    self.prompt_manager.load_prompts()
                    self.category_tree.populate_tree(self.prompt_manager.prompts)
                # Load the permanent image from the custom theme
                permanent_image = self.custom_theme.get("permanent_image", "")
                if permanent_image:
                    pixmap = QPixmap(permanent_image)
                    if not pixmap.isNull():
                        # Scale the image while maintaining the aspect ratio
                        scaled_pixmap = pixmap.scaled(self.permanent_image_label.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                        self.permanent_image_label.setPixmap(scaled_pixmap)
                        self.permanent_image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        except FileNotFoundError:
            pass

    def save_settings(self):
        settings = {
            "theme": self.theme_manager.theme_combo.currentText().lower(),
            "prompt_folder_path": self.prompt_manager.prompt_folder_path,
            "custom_theme": self.custom_theme
        }
        try:
            with open("settings.json", "w") as f:
                json.dump(settings, f)
        except OSError as e:
            print(f"Error saving settings: {e}")

    def update_current_category(self, category):
        self.current_category = category
        self.update_prompt_list()

    def update_prompt_list(self):
        if self.current_category == "":
            matching_prompts = list(self.prompt_manager.prompts.keys())
        else:
            matching_prompts = [(name, cat)
                               for (name, cat) in self.prompt_manager.prompts.keys()
                               if cat == self.current_category]
        self.prompt_list.populate_prompt_list(matching_prompts)

    def handle_tag_selected(self, prompts):
        self.prompt_list.populate_prompt_list(prompts)

    def delete_tag(self, prompt_name, category, tag):
        self.prompt_manager.tag_manager.remove_tag(prompt_name, category, tag)
        self.prompt_display.display_prompt(prompt_name, category)

    def create_new_prompt(self, event):
        dialog = NewPromptDialog(self.prompt_manager, self)
        dialog.exec()

    def closeEvent(self, event):
        self.save_settings()
        try:
            self.category_tree.save_categories()
        except Exception as e:
            print(f"Error saving categories: {e}")
        super().closeEvent(event)

    def open_theme_editor(self):
        theme_editor = ThemeEditor(self)
        theme_editor.exec()