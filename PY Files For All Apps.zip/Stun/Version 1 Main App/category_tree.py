# category_tree.py
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QTreeWidget, QTreeWidgetItem, QInputDialog, QMessageBox, QPushButton, QHBoxLayout, QLabel
from PyQt6.QtCore import pyqtSignal as Signal
from PyQt6.QtGui import QPixmap, QCursor
from PyQt6.QtCore import Qt
import os
import shutil
import json

class CategoryTree(QWidget):
    category_selected = Signal(str)

    def __init__(self, prompt_manager):
        super().__init__()
        self.prompt_manager = prompt_manager
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        self.tree_widget = QTreeWidget()
        self.tree_widget.setHeaderLabel("Categories")
        self.tree_widget.itemClicked.connect(self.handle_item_clicked)
        self.layout.addWidget(self.tree_widget)

        button_layout = QHBoxLayout()

        self.add_button = QPushButton("Add Category")
        self.add_button.clicked.connect(self.add_category)
        button_layout.addWidget(self.add_button)

        self.delete_button = QPushButton("Delete Category")
        self.delete_button.clicked.connect(self.delete_category)
        button_layout.addWidget(self.delete_button)

        self.add_image = QLabel()
        self.add_image.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.add_image.mouseReleaseEvent = lambda event: self.add_category()
        button_layout.addWidget(self.add_image)

        self.delete_image = QLabel()
        self.delete_image.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.delete_image.mouseReleaseEvent = lambda event: self.delete_category()
        button_layout.addWidget(self.delete_image)

        # Add a "Main Categories" button
        main_categories_button = QPushButton("Main Categories")
        main_categories_button.clicked.connect(self.go_to_main_categories)
        button_layout.addWidget(main_categories_button)

        self.layout.addLayout(button_layout)

        self.prompt_manager.prompts_loaded.connect(self.populate_tree)

    def populate_tree(self, prompts):
        """Populates the tree widget with categories based on the loaded prompts."""
        self.tree_widget.clear()
        categories = sorted(set(category for _, category in prompts))
        for category in categories:
            self._add_category_to_tree(category, self.tree_widget)

    def _add_category_to_tree(self, category, parent_item):
        """Adds a category (and its subcategories) to the tree widget."""
        parts = category.split("/")
        current_level = parent_item

        for i, part in enumerate(parts):
            if i == 0:  # Special case for the root level
                existing_item = self._find_child_item(self.tree_widget, part)
                if existing_item:
                    current_level = existing_item
                else:
                    new_item = QTreeWidgetItem(self.tree_widget, [part])
                    current_level = new_item
            else:
                existing_item = self._find_child_item(current_level, part)
                if existing_item:
                    current_level = existing_item
                else:
                    new_item = QTreeWidgetItem(current_level, [part])
                    current_level = new_item

    def _find_child_item(self, parent_item, text):
        """Finds a child item with the given text within a parent item."""
        if isinstance(parent_item, QTreeWidget):  # If it's the QTreeWidget
            for i in range(parent_item.topLevelItemCount()):
                child = parent_item.topLevelItem(i)
                if child.text(0) == text:
                    return child
        else:  # If it's a QTreeWidgetItem
            for i in range(parent_item.childCount()):
                child = parent_item.child(i)
                if child.text(0) == text:
                    return child
        return None

    def handle_item_clicked(self, item, column):
        """Handles clicks on category items in the tree widget."""
        category = self.get_category_path(item)
        self.category_selected.emit(category)

    def get_category_path(self, item):
        """Gets the full path of a category from a tree widget item."""
        path = [item.text(0)]
        parent = item.parent()
        while parent is not None:
            path.insert(0, parent.text(0))
            parent = parent.parent()
        return "/".join(path)

    def add_category(self):
        """Adds a new category."""
        category_name, ok = QInputDialog.getText(self, "Add Category", "Enter category name:")
        if ok and category_name:
            selected_item = self.tree_widget.currentItem()
            if selected_item:
                parent_category = self.get_category_path(selected_item)
                new_category = os.path.join(parent_category, category_name)
            else:
                new_category = category_name

            # Create the directory for the new category
            new_category_path = os.path.join(self.prompt_manager.prompt_folder_path, new_category)
            try:
                os.makedirs(new_category_path)
            except OSError as e:
                QMessageBox.warning(self, "Error", f"Error creating directory {new_category_path}: {e}")
                return # Stop if directory creation fails

            # Update the prompt_manager's list of prompts
            self.prompt_manager.add_prompt("New Prompt", new_category, "This is a new prompt in the new category.")

            # Update the tree widget
            self.populate_tree(self.prompt_manager.prompts)

            # Select the newly added category in the tree
            self._select_category_in_tree(new_category)

    def _select_category_in_tree(self, category_path):
        """Selects a specific category in the tree widget by its path."""
        parts = category_path.split("/")
        current_item = self.tree_widget.invisibleRootItem()
        for part in parts:
            for i in range(current_item.childCount()):
                child = current_item.child(i)
                if child.text(0) == part:
                    current_item = child
                    self.tree_widget.setCurrentItem(child)
                    break

    def delete_category(self):
        """Deletes a selected category."""
        selected_item = self.tree_widget.currentItem()
        if selected_item:
            category = self.get_category_path(selected_item)
            confirm = QMessageBox.question(self, "Confirm Delete",
                                            f"Are you sure you want to delete '{category}'?",
                                            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if confirm == QMessageBox.StandardButton.Yes:
                # Remove prompts associated with the category
                prompts_to_remove = [(name, cat) for (name, cat) in self.prompt_manager.prompts.keys() 
                                    if cat == category or cat.startswith(category + "/")]
                for prompt_name, prompt_category in prompts_to_remove:
                    del self.prompt_manager.prompts[(prompt_name, prompt_category)]

                # Delete the category folder
                category_folder_path = os.path.join(self.prompt_manager.prompt_folder_path, category)
                try:
                    shutil.rmtree(category_folder_path) 
                except OSError as e:
                    QMessageBox.warning(self, "Error", f"Error deleting folder {category_folder_path}: {e}")

                # Update the prompt_manager's list of prompts
                self.prompt_manager.prompts_loaded.emit(list(self.prompt_manager.prompts.keys()))

                # Update the tree widget
                self.populate_tree(self.prompt_manager.prompts)

    def go_to_main_categories(self):
        """Navigates back to the main categories."""
        self.tree_widget.clearSelection()
        self.category_selected.emit("")  # Emit an empty string to signal the main folder 

    def save_categories(self, file_path="categories.json"):
        """Saves the current category structure to a JSON file."""
        data = self._get_tree_data(self.tree_widget)
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=4)

    def _get_tree_data(self, item):
        """Recursively gets category data from the tree widget."""
        data = []
        if isinstance(item, QTreeWidget):  # If it's the main tree widget
            for i in range(item.topLevelItemCount()):
                child = item.topLevelItem(i)
                category_data = {"name": child.text(0)}
                if child.childCount() > 0:
                    category_data["children"] = self._get_tree_data(child)
                data.append(category_data)
        else: # If it's a QTreeWidgetItem
            for i in range(item.childCount()):
                child = item.child(i)
                category_data = {"name": child.text(0)}
                if child.childCount() > 0:
                    category_data["children"] = self._get_tree_data(child)
                data.append(category_data)
        return data

    def load_categories(self, file_path="categories.json"):
        """Loads the category structure from a JSON file."""
        try:
            with open(file_path, 'r') as f:
                data = f.read().strip()  # Read the file content and remove leading/trailing whitespace
                if data:  # Check if the file is not empty
                    data = json.loads(data)
                    self.tree_widget.clear()  # Clear the existing categories
                    self._populate_tree_from_data(data, self.tree_widget)
        except FileNotFoundError:
            pass  # If the file doesn't exist, don't load anything
        except json.JSONDecodeError as e:
            print(f"Error loading categories: {e}")  # Handle JSON decode error gracefully

    def _populate_tree_from_data(self, data, parent_item):
        """Recursively populates the tree widget from category data."""
        for category_data in data:
            item = QTreeWidgetItem(parent_item, [category_data["name"]])
            if "children" in category_data:
                self._populate_tree_from_data(category_data["children"], item)