from PyQt6.QtGui import QKeySequence, QShortcut

class ShortcutsManager:
    def __init__(self, main_window):
        self.main_window = main_window

        # File Menu
        self.create_shortcut("Ctrl+O", self.main_window.set_prompt_folder, "Set Prompt Folder")
        self.create_shortcut("Ctrl+I", self.main_window.import_prompts, "Import Prompts")
        self.create_shortcut("Ctrl+E", self.main_window.export_prompts, "Export Prompts")

        # Options Menu
        self.create_shortcut("Ctrl+T", self.main_window.theme_manager.show, "Change Theme")

        # View Menu
        self.create_shortcut("Ctrl+H", self.main_window.prompt_history.show, "View History")
        self.create_shortcut("Ctrl+B", self.main_window.favorites_manager.show, "View Favorites")

        # Category Tree Actions
        self.create_shortcut("Ctrl+N", self.main_window.category_tree.add_category, "Add Category")
        self.create_shortcut("Delete", self.main_window.category_tree.delete_category, "Delete Category")

        # Search Bar
        self.create_shortcut("Ctrl+F", self.main_window.search_bar.search_input.setFocus, "Focus Search Bar")

        # Prompt Display Actions
        self.create_shortcut("Ctrl+C", self.main_window.prompt_display.copy_to_clipboard, "Copy Prompt")
        self.create_shortcut("Ctrl+Shift+F", self.main_window.prompt_display.toggle_favorite, "Toggle Favorite")
        self.create_shortcut("Ctrl+S", self.main_window.prompt_display.save_tags, "Save Tags")

    def create_shortcut(self, key_sequence, action, description):
        shortcut = QShortcut(QKeySequence(key_sequence), self.main_window)
        shortcut.activated.connect(action)
        self.main_window.statusBar().showMessage(description, 3000)  # Show message for 3 seconds
