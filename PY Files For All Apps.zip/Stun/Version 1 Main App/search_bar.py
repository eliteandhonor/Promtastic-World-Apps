from PyQt6.QtWidgets import QWidget, QHBoxLayout, QLineEdit, QPushButton
from PyQt6.QtCore import pyqtSignal as Signal

class SearchBar(QWidget):
    search_triggered = Signal(str)

    def __init__(self, prompt_manager):
        super().__init__()
        self.prompt_manager = prompt_manager
        self.layout = QHBoxLayout()
        self.setLayout(self.layout)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search Prompts...")
        self.search_input.returnPressed.connect(self.trigger_search)
        self.layout.addWidget(self.search_input)

        self.search_button = QPushButton("Search")
        self.search_button.clicked.connect(self.trigger_search)
        self.layout.addWidget(self.search_button)

    def trigger_search(self):
        search_query = self.search_input.text().strip()
        if search_query:
            self.search_triggered.emit(search_query)
