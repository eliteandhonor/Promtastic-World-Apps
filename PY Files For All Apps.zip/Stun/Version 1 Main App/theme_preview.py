# theme_preview.py
from PyQt6.QtWidgets import QWidget, QLabel, QPushButton, QVBoxLayout, QGraphicsView, QGraphicsScene, QGraphicsPixmapItem
from PyQt6.QtGui import QFont, QPixmap, QCursor
from PyQt6.QtCore import Qt

class ThemePreview(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumSize(200, 200)
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        # Create a graphics view for the background image
        self.background_view = QGraphicsView()
        self.background_scene = QGraphicsScene()
        self.background_view.setScene(self.background_scene)
        self.background_view.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.layout.addWidget(self.background_view)

        # Create a label for the permanent image preview
        self.permanent_image_label = QLabel()
        self.permanent_image_label.setScaledContents(True)
        self.layout.addWidget(self.permanent_image_label)

        # Create the widgets for the preview
        self.title_label = QLabel("Theme Preview")
        self.title_label.setFont(QFont("Arial", 16))
        self.layout.addWidget(self.title_label)

        self.text_label = QLabel("This is a sample text.")
        self.layout.addWidget(self.text_label)

        self.button = QPushButton("Sample Button")
        self.layout.addWidget(self.button)

    def set_theme(self, theme_dict):
        # Set the background image
        background_image = theme_dict.get("background_image", "")
        if background_image:
            pixmap = QPixmap(background_image)
            if not pixmap.isNull():
                self.background_scene.clear()
                pixmap_item = QGraphicsPixmapItem(pixmap)
                self.background_scene.addItem(pixmap_item)

                # Correctly fit the pixmap_item within the view:
                rect = pixmap_item.sceneBoundingRect()
                self.background_view.fitInView(
                    rect,  # Pass the bounding rectangle of the pixmap_item
                    Qt.AspectRatioMode.KeepAspectRatio
                )
        else:
            self.background_scene.clear()

        # Set the permanent image preview
        permanent_image = theme_dict.get("permanent_image", "")
        if permanent_image:
            pixmap = QPixmap(permanent_image)
            if not pixmap.isNull():
                self.permanent_image_label.setPixmap(pixmap)
        else:
            self.permanent_image_label.clear()

        # Apply the theme styles to the preview widgets
        stylesheet = self.generate_stylesheet(theme_dict)
        self.setStyleSheet(stylesheet)

    @staticmethod
    def generate_stylesheet(theme_dict):
        style_sheet = f"""
            QWidget {{
                color: {theme_dict.get("text_color", "#212121")};
                font-family: {theme_dict.get("font_family", "Arial")};
                font-size: {theme_dict.get("font_size", 12)}pt;
                padding: {theme_dict.get("padding", "0")};
                margin: {theme_dict.get("margin", "0")};
                {'border-style: ' + theme_dict.get("border_style", "none") + ';' if theme_dict.get("border_style") != "None" else ''}
            }}
            QPushButton {{
                background-color: {theme_dict.get("button_color", "#2980b9")};
                color: {theme_dict.get("button_text_color", "#ffffff")};
                {'border-radius: 5px;' if theme_dict.get("rounded_corners", False) else ''}
            }}
        """
        return style_sheet