# tag_manager.py
import json

class TagManager:
    def __init__(self):
        self.tags = {}  # {tag: set((prompt_name, category))}
        self.tags_file = "tags.json"
        self._load_tags()

    def add_tag(self, prompt_name: str, category: str, tag: str) -> None:
        if tag not in self.tags:
            self.tags[tag] = set()
        self.tags[tag].add((prompt_name, category))
        self._save_tags()

    def remove_tag(self, prompt_name: str, category: str, tag: str) -> None:
        if tag in self.tags:
            self.tags[tag].discard((prompt_name, category))
            if not self.tags[tag]:
                del self.tags[tag]
            self._save_tags()

    def get_prompts_by_tag(self, tag: str) -> list:
        return list(self.tags.get(tag, set()))

    def get_tags_for_prompt(self, prompt_name: str, category: str) -> list:
        tags = []
        for tag, prompts in self.tags.items():
            if (prompt_name, category) in prompts:
                tags.append(tag)
        return tags

    def _load_tags(self) -> None:
        try:
            with open(self.tags_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.tags = {tag: set(tuple(prompt) for prompt in prompts) for tag, prompts in data.items()}
        except FileNotFoundError:
            print(f"Tags file not found: {self.tags_file}. A new file will be created.")
        except json.JSONDecodeError:
            print(f"Error reading tags file: {self.tags_file}. The file might be corrupted.")

    def _save_tags(self) -> None:
        try:
            with open(self.tags_file, "w", encoding="utf-8") as f:
                json.dump({tag: [list(prompt) for prompt in prompts] for tag, prompts in self.tags.items()}, f, indent=4)
        except OSError as e:
            print(f"Error saving tags: {e}")