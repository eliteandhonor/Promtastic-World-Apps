from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton
from PyQt6.QtCore import pyqtSignal as Signal, QSettings, Qt

class ThemeManager(QDialog):
    theme_changed = Signal(str)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Theme Manager")
        
        layout = QVBoxLayout()
        self.setLayout(layout)

        layout.addWidget(QLabel("Select a Theme:"))

        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Default", "Dark", "Light", "Custom"])  # Added "Custom" option
        self.theme_combo.currentIndexChanged.connect(self.emit_theme_changed)
        layout.addWidget(self.theme_combo)

        button_layout = QHBoxLayout()
        apply_button = QPushButton("Apply")
        apply_button.clicked.connect(self.apply_theme)
        button_layout.addWidget(apply_button)

        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.close)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)

    def emit_theme_changed(self):
        theme = self.theme_combo.currentText().lower()
        self.theme_changed.emit(theme)

    def apply_theme(self):
        self.emit_theme_changed()
        self.save_theme()
        self.close()

    def showEvent(self, event):
        super().showEvent(event)
        self.load_saved_theme()

    def load_saved_theme(self):
        settings = QSettings("MyCompany", "MyApp")
        saved_theme = settings.value("theme", "default")
        index = self.theme_combo.findText(saved_theme, Qt.MatchFlag.MatchFixedString | Qt.MatchFlag.MatchCaseSensitive)
        if index == -1:
            # Fallback to case-insensitive search if case-sensitive search fails
            index = self.theme_combo.findText(saved_theme, Qt.MatchFlag.MatchFixedString)
        if index >= 0:
            self.theme_combo.setCurrentIndex(index)

    def save_theme(self):
        settings = QSettings("MyCompany", "MyApp")
        settings.setValue("theme", self.theme_combo.currentText())
