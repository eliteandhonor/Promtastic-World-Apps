import json
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QListWidget, QPushButton
from PyQt6.QtCore import Qt, pyqtSignal as Signal

class PromptHistory(QDialog):
    load_prompt = Signal(str, str)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Prompt History")
        self.history = []
        self.history_file = "prompt_history.json"
        self._load_history()

        layout = QVBoxLayout()
        self.setLayout(layout)

        self.history_list = QListWidget()
        self.history_list.itemDoubleClicked.connect(self.handle_item_double_clicked)
        layout.addWidget(self.history_list)

        clear_button = QPushButton("Clear History")
        clear_button.clicked.connect(self.clear_history)
        layout.addWidget(clear_button)

        self._populate_history_list()

    def add_prompt(self, prompt_name: str, category: str) -> None:
        self.history.insert(0, {"name": prompt_name, "category": category})
        self.history = self.history[:10]  # Keep only the last 10 items
        self._save_history()
        self._populate_history_list()

    def clear_history(self) -> None:
        self.history = []
        self._save_history()
        self._populate_history_list()

    def handle_item_double_clicked(self, item) -> None:
        prompt_data = self.history[self.history_list.row(item)]
        self.load_prompt.emit(prompt_data["name"], prompt_data["category"])
        self.close()

    def _load_history(self) -> None:
        try:
            with open(self.history_file, "r", encoding="utf-8") as f:
                self.history = json.load(f)
        except FileNotFoundError:
            print(f"History file not found: {self.history_file}. A new file will be created.")
        except json.JSONDecodeError:
            print(f"Error reading history file: {self.history_file}. The file might be corrupted.")
            self.history = []

    def _save_history(self) -> None:
        try:
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump(self.history, f, indent=4)
        except OSError as e:
            print(f"Error saving history: {e}")

    def _populate_history_list(self) -> None:
        self.history_list.clear()
        for item in self.history:
            self.history_list.addItem(f"{item['name']} ({item['category']})")
