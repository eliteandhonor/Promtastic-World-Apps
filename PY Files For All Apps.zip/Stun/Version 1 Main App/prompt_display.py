# prompt_display.py
import os
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, QApplication, QMessageBox,
    QGraphicsView, QGraphicsScene, QGraphicsPixmapItem, QLineEdit, QGridLayout
)
from PyQt6.QtGui import QPixmap, QCursor
from PyQt6.QtCore import pyqtSignal as Signal, Qt
from rich_text_edit import RichTextEdit

class PromptDisplay(QWidget):
    prompt_selected = Signal(list)
    favorite_clicked = Signal(str, str)
    delete_tag_requested = Signal(str, str, str)

    def __init__(self, prompt_manager, favorites_manager):
        super().__init__()
        self.prompt_manager = prompt_manager
        self.favorites_manager = favorites_manager
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        self.prompt_label = QLabel("Prompt:")
        self.layout.addWidget(self.prompt_label)

        self.prompt_text = RichTextEdit()
        self.layout.addWidget(self.prompt_text)

        self.image_viewer = QGraphicsView()
        self.image_scene = QGraphicsScene()
        self.image_viewer.setScene(self.image_scene)
        self.layout.addWidget(self.image_viewer)

        # Tag Label and Edit
        self.tag_label = QLabel("Tags:")
        self.layout.addWidget(self.tag_label)
        self.tag_edit = QLineEdit()
        self.layout.addWidget(self.tag_edit)

        # Tags Layout (Change to QGridLayout)
        self.tags_layout = QGridLayout()
        self.layout.addLayout(self.tags_layout)

        # Buttons
        button_layout = QHBoxLayout()
        self.favorite_button = QPushButton("Favorite")
        self.favorite_button.clicked.connect(self.toggle_favorite)
        button_layout.addWidget(self.favorite_button)

        self.copy_button = QPushButton("Copy to Clipboard")
        self.copy_button.clicked.connect(self.copy_to_clipboard)
        button_layout.addWidget(self.copy_button)

        save_tag_button = QPushButton("Save Tags")
        save_tag_button.clicked.connect(self.save_tags)
        button_layout.addWidget(save_tag_button)

        self.layout.addLayout(button_layout)

        self.prompt_manager.prompts_loaded.connect(self.clear_display)
        self.favorites_manager.favorites_changed.connect(self.update_favorite_button)

    def display_prompt(self, prompt_name: str, category: str) -> None:
        prompt_data = self.prompt_manager.get_prompt(prompt_name, category)
        if prompt_data:
            self.prompt_text.text_edit.setPlainText(f"{prompt_name} ({category})\n\n{prompt_data['text']}")

            image_file = prompt_data.get("image")
            if image_file:
                image_path = os.path.join(self.prompt_manager.prompt_folder_path, image_file)
                pixmap = QPixmap(image_path)
                if not pixmap.isNull():
                    pixmap_item = QGraphicsPixmapItem(pixmap)
                    self.image_scene.clear()
                    self.image_scene.addItem(pixmap_item)
                    self.image_viewer.fitInView(pixmap_item, Qt.AspectRatioMode.KeepAspectRatio)
                else:
                    error_label = QLabel(f"Error loading image: {image_path}")
                    self.image_scene.clear()
                    self.image_scene.addWidget(error_label)
            else:
                self.image_scene.clear()

        self._display_tags(prompt_name, category)
        self.update_favorite_button(prompt_name, category)

    def clear_display(self) -> None:
        self.prompt_text.text_edit.clear()
        self.update_favorite_button(None, None)
        self.image_scene.clear()
        self._clear_tags_layout()

    def toggle_favorite(self) -> None:
        prompt_name, category = self.get_selected_prompt()
        if prompt_name:
            self.favorite_clicked.emit(prompt_name, category)

    def get_selected_prompt(self) -> tuple:
        prompt_text = self.prompt_text.text_edit.toPlainText()
        if prompt_text:
            try:
                lines = prompt_text.splitlines()
                if len(lines) > 0:
                    first_line = lines[0]
                    open_paren_index = first_line.rfind("(")
                    close_paren_index = first_line.rfind(")")
                    if open_paren_index != -1 and close_paren_index != -1:
                        prompt_name = first_line[:open_paren_index].strip()
                        category = first_line[open_paren_index + 1:close_paren_index].strip()
                        return prompt_name, category
            except ValueError:
                return None, None
        return None, None

    def copy_to_clipboard(self) -> None:
        clipboard = QApplication.clipboard()
        clipboard.setText(self.prompt_text.text_edit.toPlainText())
        QMessageBox.information(self, "Copied!", "Prompt copied to clipboard.")

    def update_favorite_button(self, prompt_name: str = None, category: str = None) -> None:
        if prompt_name and category and self.favorites_manager.is_favorite(prompt_name, category):
            self.favorite_button.setText("Unfavorite")
        else:
            self.favorite_button.setText("Favorite")

    def save_tags(self) -> None:
        prompt_name, category = self.get_selected_prompt()
        if prompt_name:
            new_tags = [tag.strip() for tag in self.tag_edit.text().split(",") if tag.strip()]

            # Remove old tags
            old_tags = self.prompt_manager.tag_manager.get_tags_for_prompt(prompt_name, category)
            for tag in old_tags:
                self.prompt_manager.tag_manager.remove_tag(prompt_name, category, tag)

            # Add new tags
            for tag in new_tags:
                self.prompt_manager.tag_manager.add_tag(prompt_name, category, tag)

            self._display_tags(prompt_name, category)

    def _display_tags(self, prompt_name: str, category: str) -> None:
        self._clear_tags_layout()

        tags = self.prompt_manager.tag_manager.get_tags_for_prompt(prompt_name, category)
        if tags:
            row = 0
            col = 0
            for tag in tags:
                tag_label = QLabel(f'<a href="{tag}">{tag}</a>')
                tag_label.linkActivated.connect(self.tag_clicked)
                self.tags_layout.addWidget(tag_label, row, col)  # Add to QGridLayout

                # Create a delete button for the tag
                delete_button = QPushButton("x")
                delete_button.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
                delete_button.setStyleSheet("QPushButton { font-size: 8pt; margin: 2px; }")
                delete_button.clicked.connect(lambda _, t=tag: self.delete_tag_requested.emit(prompt_name, category, t))
                self.tags_layout.addWidget(delete_button, row, col + 1)  # Add to QGridLayout

                col += 2  # Move to the next column
                if col >= 4:  # Wrap to the next row if we reach the end
                    col = 0
                    row += 1

    def _clear_tags_layout(self) -> None:
        for i in reversed(range(self.tags_layout.count())):
            widget = self.tags_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

    def tag_clicked(self, tag: str) -> None:
        prompts = self.prompt_manager.tag_manager.get_prompts_by_tag(tag)
        self.prompt_selected.emit(prompts)