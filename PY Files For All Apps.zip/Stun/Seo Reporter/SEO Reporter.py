import wx
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin
import re
from collections import Counter
from urllib.error import HTTPError
import time
from threading import Thread
import socket
import textstat
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.probability import FreqDist
from nltk.tokenize import sent_tokenize
import spacy
import en_core_web_sm
import json
import language_tool_python

# Download nltk data (only needs to be done once)
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Load spaCy model (only needs to be done once)
nlp = en_core_web_sm.load()

# Load LanguageTool for grammar and spelling checks
tool = language_tool_python.LanguageTool('en-US')

USER_AGENT = 'Mozilla/5.0'

class SEOAnalyzer(wx.Frame):
    def __init__(self, parent, title):
        super(SEOAnalyzer, self).__init__(parent, title=title)

        self.panel = wx.Panel(self)
        self.init_ui()
        self.Centre()
        self.Show()

    def init_ui(self):
        # Set the frame icon
        self.SetIcon(wx.Icon(wx.ArtProvider.GetBitmap(wx.ART_INFORMATION)))

        # URL input
        self.url_label = wx.StaticText(self.panel, label="Enter URL:")
        self.url_text = wx.TextCtrl(self.panel)

        # Analyze button
        self.analyze_button = wx.Button(self.panel, label="Analyze")
        self.analyze_button.Bind(wx.EVT_BUTTON, self.on_analyze)

        # Progress bar
        self.progress_bar = wx.Gauge(self.panel, -1, 100, size=(300, 20))
        self.progress_bar.SetValue(0)

        # Results output
        self.results_text = wx.TextCtrl(self.panel, style=wx.TE_MULTILINE | wx.TE_READONLY, size=(600, 400))

        # Add a theme color to the background
        self.panel.SetBackgroundColour(wx.Colour(240, 240, 240))
        self.url_label.SetForegroundColour(wx.Colour(0, 102, 204))
        self.analyze_button.SetBackgroundColour(wx.Colour(0, 102, 204))
        self.analyze_button.SetForegroundColour(wx.Colour(255, 255, 255))

        # Layout
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.url_label, 0, wx.ALL, 5)
        sizer.Add(self.url_text, 0, wx.ALL | wx.EXPAND, 5)
        sizer.Add(self.analyze_button, 0, wx.ALL | wx.CENTER, 5)
        sizer.Add(self.progress_bar, 0, wx.ALL | wx.CENTER, 5)
        sizer.Add(self.results_text, 1, wx.EXPAND | wx.ALL, 5)

        self.panel.SetSizer(sizer)

    def on_analyze(self, event):
        url = self.url_text.GetValue()

        # Basic validation
        if not url:
            self.results_text.SetValue("Please enter a URL.")
            return

        # Disable button and enable progress bar
        self.analyze_button.Disable()
        self.progress_bar.SetValue(0)

        # Clear previous results
        self.results_text.SetValue("")

        # Start analysis in a separate thread
        self.analysis_thread = Thread(target=self.analyze_url, args=(url,))
        self.analysis_thread.start()

    def analyze_url(self, url):
        try:
            # Fetch HTML content
            response = requests.get(url, headers={'User-Agent': USER_AGENT})
            response.raise_for_status()

            # Analyze
            soup = BeautifulSoup(response.content, 'html.parser')
            results = self.analyze_page(soup, url)

            # Display results
            wx.CallAfter(self.results_text.SetValue, results)

        except requests.exceptions.RequestException as e:
            self.handle_error(f"Error: {e}")
        except HTTPError as e:
            self.handle_error(f"Error: {e}")
        except Exception as e:
            self.handle_error(f"Error: An unexpected error occurred. {e}")  # Show the exception
        finally:
            # Re-enable button and disable progress bar
            wx.CallAfter(self.analyze_button.Enable)

    def handle_error(self, message):
        wx.CallAfter(self.results_text.SetValue, message)

    def analyze_page(self, soup, url):
        steps = [
            self.analyze_title,
            self.analyze_meta_description,
            self.analyze_headings,
            self.analyze_keyword_density,
            self.analyze_images,
            self.analyze_url_structure,
            self.analyze_mobile_friendliness,
            self.analyze_page_speed,
            self.analyze_links,
            self.analyze_social_meta_tags,
            self.analyze_content,
            self.analyze_structured_data,
            self.analyze_html_structure,
            self.analyze_user_experience,
            self.seo_audit_summary,
        ]

        results = ""
        for i, step in enumerate(steps):
            results += step(soup, url)
            progress = int(((i + 1) / len(steps)) * 100)
            wx.CallAfter(self.progress_bar.SetValue, progress)

        return results

    def analyze_title(self, soup, url):
        title = soup.title.string.strip() if soup.title else "Title not found"
        results = f"**Title:** {title}\n"
        if len(title) > 60:
            results += "  *  **Suggestion:** Keep title length under 60 characters for better visibility.\n"
        return results

    def analyze_meta_description(self, soup, url):
        meta_description = soup.find('meta', attrs={'name': 'description'})
        results = ""
        if meta_description:
            results += f"**Meta Description:** {meta_description['content']}\n"
            if len(meta_description['content']) > 160:
                results += "  *  **Suggestion:** Keep meta description under 160 characters for full display in search results.\n"
        else:
            results += "**Meta Description:** Not found\n"
            results += "  *  **Suggestion:** Add a meta description tag for better search engine visibility.\n"
        return results

    def analyze_headings(self, soup, url):
        headings = soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
        results = "**Headings:**\n"
        if len(headings) == 0:
            results += "  *  **Suggestion:** Use headings (H1-H6) to structure content.\n"
        else:
            for heading in headings:
                results += f"- {heading.name.upper()} - {heading.text.strip()}\n"
        return results

    def analyze_keyword_density(self, soup, url):
        keywords = re.findall(r'\b[a-zA-Z0-9]+\b', soup.get_text().lower())
        keyword_counts = Counter(keywords)
        results = "\n**Keyword Density:**\n"
        for keyword, count in keyword_counts.most_common(10):
            results += f"- {keyword}: {count} ({(count / len(keywords)) * 100:.2f}%) \n"
        results += "  *  **Suggestion:** Use relevant keywords throughout the page, but avoid keyword stuffing.\n"
        return results

    def analyze_images(self, soup, url):
        images = soup.find_all('img')
        results = "\n**Image Optimization & Broken Images:**\n"
        for image in images:
            alt_text = image.get('alt')
            if alt_text:
                results += f"- {image['src']} (alt: {alt_text})\n"
            else:
                results += f"- {image['src']} (alt: missing)\n"
                results += "  *  **Suggestion:** Add descriptive alt text to all images.\n"

            try:
                image_url = urljoin(url, image['src'])
                response = requests.head(image_url, timeout=5)
                if response.status_code == 200:
                    results += f"  *  {image['src']} (Status: OK, Internal)\n"
                else:
                    results += f"  *  {image['src']} (Status: Broken - {response.status_code})\n"
                    results += "  *  **Suggestion:** Fix broken image links.\n"
            except requests.exceptions.RequestException as e:
                results += f"  *  {image['src']} (Status: Could not check - {e})\n"
            except socket.timeout:
                results += f"  *  {image['src']} (Status: Timeout)\n"
            except Exception as e:
                results += f"  *  {image['src']} (Status: Error - {e})\n"
        return results

    def analyze_url_structure(self, soup, url):
        parsed_url = urlparse(url)
        results = f"\n**URL Structure:**\n"
        results += f"- Domain: {parsed_url.netloc}\n"
        results += f"- Path: {parsed_url.path}\n"
        results += f"- Query Parameters: {parsed_url.query}\n"
        results += "  *  **Suggestion:** Use short, descriptive URLs and avoid unnecessary query parameters.\n"
        return results

    def analyze_mobile_friendliness(self, soup, url):
        results = "\n**Mobile Friendliness:**\n"
        try:
            response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0 (Linux; Android 7.0; SM-G930F Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.116 Mobile Safari/537.36'})
            soup_mobile = BeautifulSoup(response.content, 'html.parser')
            if soup_mobile.find('meta', attrs={'name': 'viewport'}) is not None:
                results += "  *  **Status:**  Mobile friendly.\n"
            else:
                results += "  *  **Status:**  Not mobile friendly.\n"
                results += "  *  **Suggestion:** Add a viewport meta tag to ensure proper rendering on mobile devices.\n"
        except Exception as e:
            results += f"  *  **Status:**  Could not check mobile friendliness. Error: {e}\n"
        return results

    def analyze_page_speed(self, soup, url):
        results = "\n**Page Speed (Basic Analysis):**\n"
        try:
            start_time = time.time()
            response = requests.get(url)
            end_time = time.time()
            loading_time = end_time - start_time
            results += f"  *  **Loading Time:** {loading_time:.2f} seconds\n"
            if loading_time > 3:
                results += "  *  **Suggestion:** Optimize page speed for a better user experience. Consider compressing images, minifying code, and using a content delivery network (CDN).\n"
        except Exception as e:
            results += f"  *  **Status:**  Could not check page speed. Error: {e}\n"
        return results

    def analyze_links(self, soup, url):
        results = "\n**Link Analysis:**\n"
        links = soup.find_all('a', href=True)
        internal_links = 0
        external_links = 0
        anchor_text_counts = Counter()

        # Simplified Link Weighting
        for link in links:
            href = link['href']
            absolute_url = urljoin(url, href)
            try:
                hostname = urlparse(absolute_url).hostname
                if hostname:
                    # Check if link is broken
                    response = requests.head(absolute_url, timeout=5)
                    if response.status_code == 200:
                        results += f"  *  {href} (Status: OK"
                        if hostname == urlparse(url).hostname:
                            results += ", Internal)\n"
                            internal_links += 1
                        else:
                            results += ", External)\n"
                            external_links += 1
                        anchor_text = link.text.strip()
                        if anchor_text:
                            anchor_text_counts[anchor_text.lower()] += 1
                    else:
                        results += f"  *  {href} (Status: Broken - {response.status_code})\n"
                        results += "  *  **Suggestion:** Fix broken links for a better user experience and SEO.\n"
                else:
                    results += f"  *  {href} (Status: Invalid)\n"
            except requests.exceptions.RequestException as e:
                results += f"  *  {href} (Status: Could not check - {e})\n"
            except socket.timeout:
                results += f"  *  {href} (Status: Timeout)\n"
            except Exception as e:
                results += f"  *  {href} (Status: Error - {e})\n"

        results += f"\n- **Total Internal Links:** {internal_links}\n"
        results += f"- **Total External Links:** {external_links}\n"

        # Basic Link Weighting
        results += "\n**Anchor Text Analysis (with Basic Weighting):**\n"
        for anchor_text, count in anchor_text_counts.most_common():
            weight = count / len(links)  # Simple weighting based on frequency
            results += f"- '{anchor_text}': {count} times (Weight: {weight:.2f})\n"

        return results

    def analyze_social_meta_tags(self, soup, url):
        results = "\n**Social Media Meta Tags:**\n"

        # Open Graph
        og_tags = soup.find_all('meta', attrs={'property': lambda x: x and x.startswith('og:')})
        if og_tags:
            results += "  *  **Open Graph:**\n"
            for tag in og_tags:
                results += f"      - {tag['property']}: {tag.get('content', 'N/A')}\n"
        else:
            results += "  *  **Open Graph:** Not found\n"

        # Twitter Cards
        twitter_tags = soup.find_all('meta', attrs={'name': lambda x: x and x.startswith('twitter:')})
        if twitter_tags:
            results += "  *  **Twitter Cards:**\n"
            for tag in twitter_tags:
                results += f"      - {tag['name']}: {tag.get('content', 'N/A')}\n"
        else:
            results += "  *  **Twitter Cards:** Not found\n"

        return results

    def analyze_content(self, soup, url):
        results = "\n**Content Analysis:**\n"

        text = soup.get_text().strip()

        # Word Count
        word_count = len(text.split())
        results += f"  *  **Word Count:** {word_count}\n"

        # Readability (using textstat)
        results += f"  *  **Readability (Flesch-Kincaid):** {textstat.flesch_reading_ease(text):.2f}\n"
        results += f"  *  **Readability (Automated Readability Index):** {textstat.automated_readability_index(text):.2f}\n"
        results += f"  *  **Readability (SMOG Index):** {textstat.smog_index(text):.2f}\n"
        results += f"  *  **Readability (Coleman-Liau Index):** {textstat.coleman_liau_index(text):.2f}\n"
        results += f"  *  **Readability (Linsear Write Formula):** {textstat.linsear_write_formula(text):.2f}\n"

        # Keyword Analysis (using nltk)
        results += "\n**Keyword Analysis:**\n"
        tokens = nltk.word_tokenize(text.lower())
        stop_words = set(stopwords.words('english'))
        lemmatizer = WordNetLemmatizer()
        keywords = [lemmatizer.lemmatize(token) for token in tokens if token not in stop_words and token.isalnum()]
        keyword_counts = Counter(keywords)
        for keyword, count in keyword_counts.most_common(10):
            results += f"- {keyword}: {count} ({(count / len(keywords)) * 100:.2f}%) \n"

        # Sentence Length Analysis
        results += "\n**Sentence Length Analysis:**\n"
        sentences = sent_tokenize(text)
        sentence_lengths = [len(sentence.split()) for sentence in sentences]
        sentence_length_distribution = FreqDist(sentence_lengths)
        results += f"  *  **Average Sentence Length:** {sum(sentence_lengths) / len(sentence_lengths):.2f}\n"
        results += f"  *  **Sentence Length Distribution:**\n"
        for length, count in sentence_length_distribution.most_common():
            results += f"      - {length} words: {count} ({(count / len(sentence_lengths)) * 100:.2f}%) \n"
        results += "  *  **Suggestion:**  Aim for a variety of sentence lengths to keep content engaging.\n"

        # Topic Analysis (using spaCy)
        results += "\n**Topic Analysis (spaCy):**\n"
        doc = nlp(text)
        topics = []
        for token in doc:
            if token.pos_ == "NOUN" or token.pos_ == "PROPN":
                topics.append(token.text)
        topic_counts = Counter(topics)
        for topic, count in topic_counts.most_common(5):
            results += f"- {topic}: {count}\n"

        # Check for empty content
        if len(text) == 0:
            results += "  *  **Warning:**  Page appears to have no content.\n"

        # Grammar and Spelling Check (using LanguageTool)
        results += "\n**Grammar and Spelling Check:**\n"
        matches = tool.check(text)
        if matches:
            for match in matches:
                results += f"- {match.message} (at position: {match.offset}) \n"
        else:
            results += "  *  No grammar or spelling errors found.\n"

        return results

    def analyze_structured_data(self, soup, url):
        results = "\n**Structured Data Analysis:**\n"

        # Look for schema.org markup
        schema_items = soup.find_all('script', attrs={'type': 'application/ld+json'})

        if schema_items:
            results += "  *  **Schema.org Markup Found:**\n"
            for item in schema_items:
                try:
                    data = json.loads(item.text)
                    results += f"      - {data.get('@type', 'N/A')}\n"
                except json.JSONDecodeError:
                    results += f"      -  (Invalid JSON format)\n"
        else:
            results += "  *  **Schema.org Markup Not Found:**\n"
            results += "  *  **Suggestion:** Consider adding Schema.org markup to your page to improve search engine visibility and provide rich snippets in search results.\n"

        return results

    def analyze_html_structure(self, soup, url):
        results = "\n**HTML Structure Analysis:**\n"

        # Check for <html>, <head>, and <body>
        if soup.html and soup.head and soup.body:
            results += "  *  **Basic HTML Structure:** Found\n"
        else:
            results += "  *  **Basic HTML Structure:** Missing or Invalid. Please check your HTML.\n"
            results += "  *  **Suggestion:**  Ensure your page has a valid <html>, <head>, and <body> tag.\n"

        # Check for <title>
        if soup.title:
            results += "  *  **Title Tag:** Found\n"
        else:
            results += "  *  **Title Tag:** Missing. Please add a <title> tag.\n"

        # Check for <meta name='description'>
        if soup.find('meta', attrs={'name': 'description'}):
            results += "  *  **Meta Description Tag:** Found\n"
        else:
            results += "  *  **Meta Description Tag:** Missing. Add a <meta name='description'> tag.\n"

        # Check for <meta name='keywords'> (Though it's not recommended nowadays)
        if soup.find('meta', attrs={'name': 'keywords'}):
            results += "  *  **Meta Keywords Tag:** Found\n"
            results += "  *  **Suggestion:** While meta keywords are not a ranking factor anymore, using relevant keywords for better search engine understanding.\n"
        else:
            results += "  *  **Meta Keywords Tag:** Missing.  Consider adding a <meta name='keywords'> tag.\n"

        # Check for <meta name='robots'>
        if soup.find('meta', attrs={'name': 'robots'}):
            results += "  *  **Robots Meta Tag:** Found\n"
        else:
            results += "  *  **Robots Meta Tag:** Missing. Please add a <meta name='robots'> tag.\n"

        # Check for Heading Structure (basic)
        h1_count = len(soup.find_all('h1'))
        h2_count = len(soup.find_all('h2'))
        if h1_count > 0 and h2_count == 0:
            results += "  *  **Heading Structure:**  Consider adding more H2 headings for better content organization.\n"

        return results

    def analyze_user_experience(self, soup, url):
        results = "\n**User Experience (Basic Observations):**\n"

        # Navigation (Basic)
        navigation_links = soup.find_all('a', href=True)
        if len(navigation_links) > 5:
            results += "  *  **Navigation:**  The website appears to have a reasonable number of navigation links.\n"
        else:
            results += "  *  **Navigation:**  Consider adding more navigation links for better site exploration.\n"

        # Page Layout (Basic)
        results += "  *  **Page Layout:**  Visually check the page layout for readability and clear organization.\n"

        # Content Length (Basic)
        text = soup.get_text().strip()
        word_count = len(text.split())
        if word_count > 300:
            results += "  *  **Content Length:** The page appears to have a reasonable amount of content.\n"
        else:
            results += "  *  **Content Length:** Consider adding more content to improve engagement.\n"

        return results

    def seo_audit_summary(self, soup, url):
        results = "\n**SEO Audit Summary:**\n"
        results += "Key findings and suggestions:\n"

        if soup.title and len(soup.title.string.strip()) > 60:
            results += "  *  **Title:** Keep title length under 60 characters for better visibility.\n"

        meta_description = soup.find('meta', attrs={'name': 'description'})
        if meta_description:
            if len(meta_description['content']) > 160:
                results += "  *  **Meta Description:** Keep meta description under 160 characters for full display in search results.\n"
        else:
            results += "  *  **Meta Description:** Add a meta description tag for better search engine visibility.\n"

        if not soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']):
            results += "  *  **Headings:** Use headings (H1-H6) to structure content.\n"

        images = soup.find_all('img')
        for image in images:
            if not image.get('alt'):
                results += "  *  **Image Optimization:** Add descriptive alt text to all images.\n"
                break

        if not soup.find('meta', attrs={'name': 'viewport'}):
            results += "  *  **Mobile Friendliness:** Add a viewport meta tag to ensure proper rendering on mobile devices.\n"

        try:
            start_time = time.time()
            response = requests.get(url)
            end_time = time.time()
            loading_time = end_time - start_time
            if loading_time > 3:
                results += "  *  **Page Speed:** Optimize page speed for a better user experience. Consider compressing images, minifying code, and using a content delivery network (CDN).\n"
        except Exception as e:
            results += f"  *  **Page Speed:** Could not check page speed. Error: {e}\n"

        if not soup.find_all('meta', attrs={'property': lambda x: x and x.startswith('og:')}):
            results += "  *  **Social Media:** Add Open Graph meta tags for better social media integration.\n"

        return results

if __name__ == '__main__':
    app = wx.App()
    SEOAnalyzer(None, title="SEO Analyzer")
    app.MainLoop()
