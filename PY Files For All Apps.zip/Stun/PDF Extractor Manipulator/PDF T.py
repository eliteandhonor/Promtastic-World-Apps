import os
import io
import fitz  # PyMuPDF
import customtkinter as ctk
from tkinter import filedialog, messagebox, PhotoImage
from PyPDF2 import PdfReader, PdfWriter
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas as rl_canvas
import tempfile

class PDFHandler:
    def __init__(self):
        self.pdf_reader = None
        self.pdf_writer = None
        self.pdf_document = None

    def load_pdf(self, file_path):
        try:
            self.pdf_reader = PdfReader(file_path)
            self.pdf_document = fitz.open(file_path)
            self.pdf_writer = PdfWriter()
            for page_num in range(len(self.pdf_reader.pages)):
                self.pdf_writer.add_page(self.pdf_reader.pages[page_num])
        except Exception as e:
            messagebox.showerror("Error", f"Error loading PDF: {e}")

    def extract_text(self, page_num):
        page = self.pdf_reader.pages[page_num]
        return page.extract_text()

    def save_pdf(self, save_path, text, current_page):
        page = self.pdf_writer.pages[current_page]
        page.merge_page(PdfReader(io.BytesIO(self.text_to_pdf(text))).pages[0])
        with open(save_path, 'wb') as f:
            self.pdf_writer.write(f)

    @staticmethod
    def text_to_pdf(text):
        packet = io.BytesIO()
        can = rl_canvas.Canvas(packet, pagesize=letter)
        can.drawString(72, 720, text)
        can.save()
        packet.seek(0)
        return packet.read()

class PDFApp:
    def __init__(self, root):
        self.root = root
        self.root.title('PDF Editor/Viewer')
        self.root.geometry('1200x900')
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.pdf_handler = PDFHandler()
        self.zoom_level = 1.2

        # Main layout
        self.main_frame = ctk.CTkFrame(self.root)
        self.main_frame.pack(fill='both', expand=True)

        # Toolbar setup
        self.setup_toolbar()

        # Scroll view for both text and image
        self.text_input = ctk.CTkTextbox(self.main_frame, state='normal')
        self.text_input.pack(fill='both', expand=1)

        self.canvas_frame = ctk.CTkFrame(self.main_frame)
        self.canvas_frame.pack(fill='both', expand=1)
        self.canvas_frame.pack_forget()  # Start with the canvas view hidden

        self.canvas = ctk.CTkCanvas(self.canvas_frame, bg='gray')
        self.canvas.pack(side='left', fill='both', expand=1)

        self.scroll_x = ctk.CTkScrollbar(self.canvas_frame, orientation='horizontal', command=self.canvas.xview)
        self.scroll_x.pack(side='bottom', fill='x')
        self.scroll_y = ctk.CTkScrollbar(self.canvas_frame, orientation='vertical', command=self.canvas.yview)
        self.scroll_y.pack(side='right', fill='y')
        self.canvas.configure(xscrollcommand=self.scroll_x.set, yscrollcommand=self.scroll_y.set)

        self.current_page = 0
        self.view_mode = 'text'  # Initial view mode

    def setup_toolbar(self):
        toolbar = ctk.CTkFrame(self.main_frame)
        toolbar.pack(side='top', fill='x', pady=5)

        sections = [
            ('File Operations', [
                ('Open PDF', self.open_pdf),
                ('Save PDF', self.save_pdf)
            ]),
            ('Navigation', [
                ('Previous Page', self.prev_page),
                ('Next Page', self.next_page),
                ('Go to Page', self.go_to_page_input)
            ]),
            ('Zoom', [
                ('Zoom In', self.zoom_in),
                ('Zoom Out', self.zoom_out)
            ]),
            ('Text Operations', [
                ('Extract Page Text', self.extract_page_text),
                ('Extract All Text', self.extract_all_text)
            ]),
            ('Image Operations', [
                ('Extract Images', self.extract_images)
            ]),
            ('PDF Operations', [
                ('Split PDF', self.split_pdf),
                ('Merge PDFs', self.merge_pdfs)
            ]),
            ('Search', [
                ('Search', self.search_pdf)
            ]),
            ('View', [
                ('Toggle View', self.toggle_view)
            ])
        ]

        for section_name, buttons in sections:
            section_frame = ctk.CTkFrame(toolbar)
            section_frame.pack(side='left', padx=10, pady=5, fill='y')
            ctk.CTkLabel(section_frame, text=section_name).pack(anchor='w', pady=5)
            for button_text, button_command in buttons:
                button = ctk.CTkButton(section_frame, text=button_text, command=button_command)
                button.pack(anchor='w', pady=2)

            if section_name == 'Navigation':
                self.page_input = ctk.CTkEntry(section_frame, placeholder_text="Page Number")
                self.page_input.pack(anchor='w', pady=2)
                self.page_input.bind('<Return>', self.go_to_page_input)

            if section_name == 'Search':
                self.search_bar = ctk.CTkEntry(section_frame, placeholder_text="Search Text")
                self.search_bar.pack(anchor='w', pady=2)
                self.search_bar.bind('<Return>', self.search_pdf)

    def open_pdf(self):
        file_path = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
        if file_path:
            self.pdf_handler.load_pdf(file_path)
            self.current_page = 0
            self.update_view()

    def update_view(self):
        if self.view_mode == 'text':
            self.text_input.pack(fill='both', expand=1)
            self.canvas_frame.pack_forget()
            self.display_text(self.current_page)
        else:
            self.canvas_frame.pack(fill='both', expand=1)
            self.text_input.pack_forget()
            self.display_page(self.current_page)

    def display_text(self, page_num):
        text = self.pdf_handler.extract_text(page_num)
        self.text_input.delete(1.0, 'end')
        self.text_input.insert('end', text)

    def display_page(self, page_num):
        try:
            page = self.pdf_handler.pdf_document.load_page(page_num)
            mat = fitz.Matrix(self.zoom_level, self.zoom_level)
            pix = page.get_pixmap(matrix=mat)
            img_data = pix.tobytes("png")
            image_path = tempfile.mktemp(suffix=".png")
            pix.save(image_path)
            self.image = PhotoImage(file=image_path)

            self.canvas.delete("all")
            self.root.update_idletasks()  # Update the GUI to get correct canvas dimensions
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            image_width, image_height = self.image.width(), self.image.height()

            x = max((canvas_width - image_width) // 2, 0)
            y = max((canvas_height - image_height) // 2, 0)

            self.canvas.create_image(x, y, image=self.image, anchor='nw')
            self.canvas.config(scrollregion=self.canvas.bbox('all'))
        except Exception as e:
            messagebox.showerror("Error", f"Error displaying page {page_num}: {e}")

    def zoom_in(self):
        self.zoom_level += 0.2
        self.update_view()

    def zoom_out(self):
        self.zoom_level = max(0.2, self.zoom_level - 0.2)
        self.update_view()

    def prev_page(self):
        if self.pdf_handler.pdf_reader and self.current_page > 0:
            self.current_page -= 1
            self.update_view()

    def next_page(self):
        if self.pdf_handler.pdf_reader and self.current_page < len(self.pdf_handler.pdf_reader.pages) - 1:
            self.current_page += 1
            self.update_view()

    def extract_page_text(self):
        if self.pdf_handler.pdf_reader:
            text = self.pdf_handler.extract_text(self.current_page)
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            messagebox.showinfo("Page Text Copied", "The text of the current page has been copied to the clipboard.")

    def extract_all_text(self):
        if self.pdf_handler.pdf_reader:
            text = ""
            for page in self.pdf_handler.pdf_reader.pages:
                text += page.extract_text() + "\n"
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            messagebox.showinfo("All Text Copied", "The text of the entire PDF has been copied to the clipboard.")

    def save_pdf(self):
        if self.pdf_handler.pdf_reader:
            save_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
            if save_path:
                try:
                    edited_text = self.text_input.get("1.0", "end-1c")
                    self.pdf_handler.save_pdf(save_path, edited_text, self.current_page)
                    messagebox.showinfo("PDF Saved", f"PDF saved to {save_path}")
                except Exception as e:
                    messagebox.showerror("Error", f"Error saving PDF: {e}")

    def toggle_view(self):
        if self.view_mode == 'text':
            self.view_mode = 'pdf'
            self.text_input.pack_forget()
            self.canvas_frame.pack(fill='both', expand=1)
            self.display_page(self.current_page)
            self.toggle_view_button.config(text='Switch to Text View')
        else:
            self.view_mode = 'text'
            self.canvas_frame.pack_forget()
            self.text_input.pack(fill='both', expand=1)
            self.display_text(self.current_page)
            self.toggle_view_button.config(text='Switch to PDF View')

    def extract_images(self):
        if self.pdf_handler.pdf_document:
            save_directory = filedialog.askdirectory(title="Select Directory to Save Images")
            if save_directory:
                for page_num in range(len(self.pdf_handler.pdf_document)):
                    page = self.pdf_handler.pdf_document.load_page(page_num)
                    image_list = page.get_images(full=True)
                    for img_index, img in enumerate(image_list, start=1):
                        xref = img[0]
                        base_image = self.pdf_handler.pdf_document.extract_image(xref)
                        image_bytes = base_image["image"]
                        image_ext = base_image["ext"]
                        image_path = os.path.join(save_directory, f"extracted_image_page{page_num+1}_img{img_index}.{image_ext}")
                        with open(image_path, "wb") as image_file:
                            image_file.write(image_bytes)
                messagebox.showinfo("Images Extracted", "All images have been extracted and saved.")

    def split_pdf(self):
        if self.pdf_handler.pdf_reader:
            save_directory = filedialog.askdirectory(title="Select Directory to Save Split PDFs")
            if save_directory:
                for page_num in range(len(self.pdf_handler.pdf_reader.pages)):
                    pdf_writer = PdfWriter()
                    pdf_writer.add_page(self.pdf_handler.pdf_reader.pages[page_num])
                    output_filename = os.path.join(save_directory, f"split_page_{page_num+1}.pdf")
                    with open(output_filename, 'wb') as output_file:
                        pdf_writer.write(output_file)
                messagebox.showinfo("PDF Split", "The PDF has been split into individual pages.")

    def merge_pdfs(self):
        pdf_files = filedialog.askopenfilenames(filetypes=[("PDF files", "*.pdf")])
        if pdf_files:
            merger = PdfWriter()
            for pdf_file in pdf_files:
                pdf_reader = PdfReader(pdf_file)
                for page in range(len(pdf_reader.pages)):
                    merger.add_page(pdf_reader.pages[page])

            save_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
            if save_path:
                try:
                    with open(save_path, 'wb') as f:
                        merger.write(f)
                    messagebox.showinfo("PDFs Merged", f"PDFs merged and saved to {save_path}")
                except Exception as e:
                    messagebox.showerror("Error", f"Error merging PDFs: {e}")

    def go_to_page_input(self, event=None):
        page_text = self.page_input.get().strip()
        if page_text:
            try:
                page_num = int(page_text) - 1
                if 0 <= page_num < len(self.pdf_handler.pdf_reader.pages):
                    self.current_page = page_num
                    self.update_view()
            except ValueError:
                messagebox.showerror("Invalid Page Number", "Please enter a valid page number.")
        else:
            messagebox.showerror("Empty Input", "Please enter a page number.")

    def search_pdf(self, event=None):
        search_term = self.search_bar.get().strip()
        if search_term:
            match_pages = []
            for page_num in range(len(self.pdf_handler.pdf_reader.pages)):
                page = self.pdf_handler.pdf_reader.pages[page_num]
                text = page.extract_text()
                if search_term.lower() in text.lower():
                    match_pages.append(page_num)

            if match_pages:
                result_message = f"Search results for '{search_term}':\n" + "\n".join([f"Page {p+1}" for p in match_pages])
                messagebox.showinfo("Search Results", result_message)
            else:
                messagebox.showinfo("No Results", f"No matches found for '{search_term}'.")


if __name__ == '__main__':
    root = ctk.CTk()
    app = PDFApp(root)
    root.mainloop()
