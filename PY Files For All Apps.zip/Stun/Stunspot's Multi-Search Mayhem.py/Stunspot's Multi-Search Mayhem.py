import sys
import os
import json
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QSpinBox, QPushButton, QListWidget, QTabWidget, QMessageBox, QProgressBar, QMenu, QInputDialog, QFileDialog, QDialog, QDialogButtonBox, QTreeWidget, QTreeWidgetItem, QFontDialog)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtCore import QUrl, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QKeySequence, QShortcut, QAction, QPixmap, QFont
from googlesearch import search as google_search
from duckduckgo_search import DDGS
import requests
from bs4 import BeautifulSoup
import qdarkstyle

# Set QT_API environment variable to use PyQt6
os.environ["QT_API"] = "pyqt6"

# Get the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
PROFILE_PIC_PATH = os.path.join(script_dir, "stunspot.jpg")

BOOKMARKS_FILE = os.path.join(script_dir, "bookmarks.json")
TABS_FILE = os.path.join(script_dir, "tabs.json")
CONFIG_FILE = os.path.join(script_dir, "config.json")


class SearchEngine:
    @staticmethod
    def search_ddg(query, num_results):
        try:
            results = DDGS().text(query, max_results=num_results)
            return [{'title': result['title'], 'url': result['href']} for result in results]
        except Exception as e:
            print(f"Error during DuckDuckGo search: {e}")
            return []

    @staticmethod
    def search_bing(query, num_results):
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
            }
            response = requests.get(f"https://www.bing.com/search?q={query}&count={num_results}", headers=headers)
            soup = BeautifulSoup(response.text, 'html.parser')
            results = soup.find_all('li', {'class': 'b_algo'})
            return [{'title': result.find('h2').text, 'url': result.find('a')['href']} for result in results[:num_results]]
        except Exception as e:
            print(f"Error during Bing search: {e}")
            return []

    @staticmethod
    def search_google(query, num_results):
        try:
            raw_results = google_search(query, num_results=num_results)
            seen_urls = set()
            unique_results = []
            for result in raw_results:
                if result not in seen_urls:
                    seen_urls.add(result)
                    unique_results.append({'title': result, 'url': result})
            return unique_results
        except Exception as e:
            print(f"Error during Google search: {e}")
            return []


class SearchThread(QThread):
    results_ready = pyqtSignal(list)

    def __init__(self, search_func, query, num_results):
        super().__init__()
        self.search_func = search_func
        self.query = query
        self.num_results = num_results

    def run(self):
        results = self.search_func(self.query, self.num_results)
        self.results_ready.emit(results)


class AboutDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("About")
        self.setGeometry(300, 300, 300, 200)

        layout = QVBoxLayout()
        about_text = QLabel("Stunspot's Multi-Search Mayhem\nVersion 1.0\n\nAn application to search the web using multiple search engines and manage bookmarks.")
        about_text.setWordWrap(True)
        layout.addWidget(about_text)

        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok)
        button_box.accepted.connect(self.accept)
        layout.addWidget(button_box)

        self.setLayout(layout)


class SearchApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.bookmarks = self.load_bookmarks()
        self.filtered_bookmarks = self.bookmarks.copy()
        self.font = self.load_font()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Stunspot's Multi-Search Mayhem")
        self.setGeometry(100, 100, 1200, 800)
        widget = QWidget()
        self.setCentralWidget(widget)
        self.layout = QVBoxLayout(widget)

        self.add_profile_picture()  # Add profile picture to the layout

        self.address_bar = QLineEdit(self)
        self.address_bar.returnPressed.connect(self.load_url_from_address_bar)
        self.layout.addWidget(self.address_bar)

        self.tab_widget = QTabWidget()
        self.browser_tab_widget = QTabWidget()
        self.browser_tab_widget.setTabsClosable(True)
        self.browser_tab_widget.tabCloseRequested.connect(self.close_tab)
        self.browser_tab_widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.browser_tab_widget.customContextMenuRequested.connect(self.show_browser_context_menu)
        self.browser_tab_widget.currentChanged.connect(self.update_address_bar)

        self.ddg_panel = self.create_search_panel("DuckDuckGo")
        self.bing_panel = self.create_search_panel("Bing")
        self.google_panel = self.create_search_panel("Google")
        self.multi_panel = self.create_multi_search_panel()
        self.bookmarks_panel = self.create_bookmarks_panel()

        self.tab_widget.addTab(self.ddg_panel, "DuckDuckGo")
        self.tab_widget.addTab(self.bing_panel, "Bing")
        self.tab_widget.addTab(self.google_panel, "Google")
        self.tab_widget.insertTab(3, self.multi_panel, "Multi-Search")
        self.tab_widget.addTab(self.bookmarks_panel, "Bookmarks")

        self.layout.addWidget(self.tab_widget)
        self.layout.addWidget(self.browser_tab_widget)

        QShortcut(QKeySequence("Ctrl+Tab"), self).activated.connect(self.next_tab)
        QShortcut(QKeySequence("Ctrl+Shift+Tab"), self).activated.connect(self.previous_tab)

        self.restore_tabs()
        self.create_menu_bar()
        self.fullscreen = False

        self.apply_font(self.font)

    def add_profile_picture(self):
        hbox = QHBoxLayout()
        profile_pic_label = QLabel()
        pixmap = QPixmap(PROFILE_PIC_PATH)
        profile_pic_label.setPixmap(pixmap.scaled(100, 100, Qt.AspectRatioMode.KeepAspectRatio))
        hbox.addWidget(profile_pic_label)
        title_label = QLabel("Stunspot's Multi-Search Mayhem")
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #39FF14;")  # Ninja Turtles green
        hbox.addWidget(title_label)
        hbox.addStretch()
        self.layout.addLayout(hbox)

    def create_menu_bar(self):
        menu_bar = self.menuBar()
        help_menu = menu_bar.addMenu("Help")
        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about_dialog)
        help_menu.addAction(about_action)

        settings_menu = menu_bar.addMenu("Settings")
        change_font_action = QAction("Change Font", self)
        change_font_action.triggered.connect(self.change_font)
        settings_menu.addAction(change_font_action)

    def show_about_dialog(self):
        about_dialog = AboutDialog()
        about_dialog.exec()

    def change_font(self):
        font, ok = QFontDialog.getFont(self.font, self, "Select Font")
        if ok:
            self.font = font
            self.apply_font(font)
            self.save_font(font)

    def apply_font(self, font):
        QApplication.instance().setFont(font)
        self.setStyleSheet(f"* {{ font-family: {font.family()}; font-size: {font.pointSize()}pt; }}")

    def save_font(self, font):
        font_data = {
            'family': font.family(),
            'pointSize': font.pointSize(),
            'weight': font.weight(),
            'italic': font.italic()
        }
        with open(CONFIG_FILE, 'w') as file:
            json.dump({'font': font_data}, file, indent=4)

    def load_font(self):
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as file:
                config = json.load(file)
                font_data = config.get('font', {})
                font = QFont()
                font.setFamily(font_data.get('family', ''))
                font.setPointSize(font_data.get('pointSize', 10))
                font.setWeight(font_data.get('weight', QFont.Weight.Normal))
                font.setItalic(font_data.get('italic', False))
                return font
        return QApplication.font()

    def next_tab(self):
        current_index = self.tab_widget.currentIndex()
        next_index = (current_index + 1) % self.tab_widget.count()
        self.tab_widget.setCurrentIndex(next_index)

    def previous_tab(self):
        current_index = self.tab_widget.currentIndex()
        previous_index = (current_index - 1) % self.tab_widget.count()
        self.tab_widget.setCurrentIndex(previous_index)

    def create_search_panel(self, engine):
        panel = QWidget()
        vbox = QVBoxLayout(panel)
        hbox1 = QHBoxLayout()
        lbl_query = QLabel("Search Query:")
        hbox1.addWidget(lbl_query)
        search_ctrl = QLineEdit()
        hbox1.addWidget(search_ctrl)
        vbox.addLayout(hbox1)
        hbox2 = QHBoxLayout()
        lbl_results = QLabel("Number of Results:")
        hbox2.addWidget(lbl_results)
        results_spin = QSpinBox()
        results_spin.setRange(1, 100)
        results_spin.setValue(10)
        hbox2.addWidget(results_spin)
        search_btn = QPushButton("Search")
        hbox2.addWidget(search_btn)
        vbox.addLayout(hbox2)
        loading_indicator = QProgressBar()
        loading_indicator.setRange(0, 0)
        loading_indicator.setTextVisible(False)
        loading_indicator.setVisible(False)
        vbox.addWidget(loading_indicator)
        results_list = QListWidget()
        results_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        results_list.customContextMenuRequested.connect(lambda pos: self.show_context_menu(pos, results_list, engine))
        vbox.addWidget(results_list)

        search_methods = {
            "DuckDuckGo": self.on_search_ddg,
            "Bing": self.on_search_bing,
            "Google": self.on_search_google
        }
        search_btn.clicked.connect(lambda: search_methods[engine](search_ctrl, results_spin, results_list, loading_indicator))
        return panel

    def create_multi_search_panel(self):
        panel = QWidget()
        vbox = QVBoxLayout(panel)
        hbox1 = QHBoxLayout()
        lbl_query = QLabel("Search Query:")
        hbox1.addWidget(lbl_query)
        search_ctrl = QLineEdit()
        hbox1.addWidget(search_ctrl)
        vbox.addLayout(hbox1)
        hbox2 = QHBoxLayout()
        lbl_results = QLabel("Number of Results:")
        hbox2.addWidget(lbl_results)
        results_spin = QSpinBox()
        results_spin.setRange(1, 100)
        results_spin.setValue(10)
        hbox2.addWidget(results_spin)
        search_btn = QPushButton("Search")
        hbox2.addWidget(search_btn)
        vbox.addLayout(hbox2)
        loading_indicator = QProgressBar()
        loading_indicator.setRange(0, 0)
        loading_indicator.setTextVisible(False)
        loading_indicator.setVisible(False)
        vbox.addWidget(loading_indicator)
        results_list = QListWidget()
        results_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        results_list.customContextMenuRequested.connect(lambda pos: self.show_context_menu(pos, results_list, "Multi-Search"))
        vbox.addWidget(results_list)
        search_btn.clicked.connect(lambda: self.on_multi_search(search_ctrl, results_spin, results_list, loading_indicator))
        return panel

    def create_bookmarks_panel(self):
        panel = QWidget()
        vbox = QVBoxLayout(panel)
        hbox = QHBoxLayout()
        lbl_search = QLabel("Search Bookmarks:")
        hbox.addWidget(lbl_search)
        self.bookmark_search_ctrl = QLineEdit()
        self.bookmark_search_ctrl.textChanged.connect(self.filter_bookmarks)
        hbox.addWidget(self.bookmark_search_ctrl)
        vbox.addLayout(hbox)
        self.bookmarks_tree = QTreeWidget()
        self.bookmarks_tree.setHeaderHidden(True)
        self.bookmarks_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.bookmarks_tree.customContextMenuRequested.connect(self.show_bookmark_context_menu)
        self.bookmarks_tree.itemDoubleClicked.connect(self.on_select_bookmark)
        self.bookmarks_tree.setDragEnabled(True)
        self.bookmarks_tree.viewport().setAcceptDrops(True)
        self.bookmarks_tree.setDropIndicatorShown(True)
        self.bookmarks_tree.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.bookmarks_tree.setDragDropMode(QTreeWidget.DragDropMode.InternalMove)
        self.bookmarks_tree.setAcceptDrops(True)
        self.bookmarks_tree.setDragDropMode(QTreeWidget.DragDropMode.DragDrop)
        self.bookmarks_tree.expandAll()
        vbox.addWidget(self.bookmarks_tree)
        self.update_bookmarks_tree()
        hbox = QHBoxLayout()
        export_btn = QPushButton("Export Bookmarks")
        export_btn.clicked.connect(self.export_bookmarks)
        hbox.addWidget(export_btn)
        import_btn = QPushButton("Import Bookmarks")
        import_btn.clicked.connect(self.import_bookmarks)
        hbox.addWidget(import_btn)
        vbox.addLayout(hbox)
        return panel

    def filter_bookmarks(self):
        query = self.bookmark_search_ctrl.text().lower()
        self.filtered_bookmarks = [bm for bm in self.bookmarks if query in bm['title'].lower()]
        self.update_bookmarks_tree()

    def on_search_ddg(self, search_ctrl, results_spin, results_list, loading_indicator):
        query = search_ctrl.text()
        num_results = results_spin.value()
        results_list.clear()
        self.ddg_results = []
        if query:
            loading_indicator.setVisible(True)
            self.search_thread = SearchThread(SearchEngine.search_ddg, query, num_results)
            self.search_thread.results_ready.connect(lambda results: self.handle_search_results(results, results_list, loading_indicator, "DuckDuckGo"))
            self.search_thread.start()

    def on_search_bing(self, search_ctrl, results_spin, results_list, loading_indicator):
        query = search_ctrl.text()
        num_results = results_spin.value()
        results_list.clear()
        self.bing_results = []
        if query:
            loading_indicator.setVisible(True)
            self.search_thread = SearchThread(SearchEngine.search_bing, query, num_results)
            self.search_thread.results_ready.connect(lambda results: self.handle_search_results(results, results_list, loading_indicator, "Bing"))
            self.search_thread.start()

    def on_search_google(self, search_ctrl, results_spin, results_list, loading_indicator):
        query = search_ctrl.text()
        num_results = results_spin.value()
        results_list.clear()
        self.google_results = []
        if query:
            loading_indicator.setVisible(True)
            self.search_thread = SearchThread(SearchEngine.search_google, query, num_results)
            self.search_thread.results_ready.connect(lambda results: self.handle_search_results(results, results_list, loading_indicator, "Google"))
            self.search_thread.start()

    def on_multi_search(self, search_ctrl, results_spin, results_list, loading_indicator):
        query = search_ctrl.text()
        num_results = results_spin.value()
        results_list.clear()
        self.multi_results = []
        if query:
            loading_indicator.setVisible(True)
            self.multi_results = []
            self.pending_searches = 3

            def collect_results(results):
                self.multi_results.extend(results)
                self.pending_searches -= 1
                if self.pending_searches == 0:
                    loading_indicator.setVisible(False)
                    self.multi_results = self.filter_unique_results(self.multi_results)
                    self.multi_results.sort(key=lambda x: x['title'])
                    for result in self.multi_results:
                        title = result.get('title', 'No Title')
                        results_list.addItem(f"{title}\n{result['url']}")

            self.ddg_search_thread = SearchThread(SearchEngine.search_ddg, query, num_results)
            self.ddg_search_thread.results_ready.connect(collect_results)
            self.ddg_search_thread.start()

            self.bing_search_thread = SearchThread(SearchEngine.search_bing, query, num_results)
            self.bing_search_thread.results_ready.connect(collect_results)
            self.bing_search_thread.start()

            self.google_search_thread = SearchThread(SearchEngine.search_google, query, num_results)
            self.google_search_thread.results_ready.connect(collect_results)
            self.google_search_thread.start()

    def filter_unique_results(self, results):
        seen_urls = set()
        unique_results = []
        for result in results:
            if result['url'] not in seen_urls:
                seen_urls.add(result['url'])
                unique_results.append(result)
        return unique_results

    def handle_search_results(self, results, results_list, loading_indicator, engine):
        loading_indicator.setVisible(False)
        if results:
            if engine == "DuckDuckGo":
                self.ddg_results.extend(results)
            elif engine == "Bing":
                self.bing_results.extend(results)
            else:
                self.google_results.extend(results)
            for result in results:
                title = result.get('title', 'No Title')
                results_list.addItem(f"{title}\n{result['url']}")
        else:
            self.show_error_message(engine, "No results found. Please try a different query or check your internet connection.")

    def show_error_message(self, engine, message):
        QMessageBox.warning(self, f"{engine} Search Error", message)

    def show_context_menu(self, pos, results_list, engine):
        context_menu = QMenu(self)
        open_in_new_tab_action = context_menu.addAction("Open in New Tab")
        bookmark_action = context_menu.addAction("Bookmark")
        action = context_menu.exec(results_list.mapToGlobal(pos))
        if action == open_in_new_tab_action:
            self.on_select_result(results_list, engine)
        elif action == bookmark_action:
            self.on_bookmark_result(results_list, engine)

    def show_bookmark_context_menu(self, pos):
        context_menu = QMenu(self)
        open_in_new_tab_action = context_menu.addAction("Open in New Tab")
        rename_action = context_menu.addAction("Rename Bookmark")
        delete_action = context_menu.addAction("Delete Bookmark")
        delete_category_action = context_menu.addAction("Delete Category")
        move_to_category_action = context_menu.addAction("Move to Category")
        add_category_action = context_menu.addAction("Add Category")
        action = context_menu.exec(self.bookmarks_tree.mapToGlobal(pos))
        if action == open_in_new_tab_action:
            self.on_select_bookmark()
        elif action == rename_action:
            self.rename_bookmark()
        elif action == delete_action:
            self.delete_bookmark()
        elif action == delete_category_action:
            self.delete_category()
        elif action == move_to_category_action:
            self.move_bookmark_to_category()
        elif action == add_category_action:
            self.add_category()

    def show_browser_context_menu(self, pos):
        context_menu = QMenu(self)
        toggle_fullscreen_action = context_menu.addAction("Toggle Fullscreen")
        action = context_menu.exec(self.browser_tab_widget.mapToGlobal(pos))
        if action == toggle_fullscreen_action:
            self.toggle_fullscreen()

    def on_select_result(self, results_list, engine):
        selection = results_list.currentRow()
        url = None
        title = None
        if engine == "DuckDuckGo":
            url = self.ddg_results[selection].get('url') if selection >= 0 else None
            title = self.ddg_results[selection].get('title') if selection >= 0 else None
        elif engine == "Bing":
            url = self.bing_results[selection]['url'] if selection >= 0 else None
            title = self.bing_results[selection]['title'] if selection >= 0 else None
        elif engine == "Google":
            url = self.google_results[selection]['url'] if selection >= 0 else None
            title = self.google_results[selection]['title'] if selection >= 0 else None
        elif engine == "Multi-Search":
            url = self.multi_results[selection]['url'] if selection >= 0 else None
            title = self.multi_results[selection]['title'] if selection >= 0 else None
        if url:
            self.open_new_tab(url, title)
        else:
            self.show_error_message(engine, "No valid URL found for the selected result.")

    def on_bookmark_result(self, results_list, engine):
        selection = results_list.currentRow()
        if engine == "DuckDuckGo":
            result = self.ddg_results[selection] if selection >= 0 else None
        elif engine == "Bing":
            result = self.bing_results[selection] if selection >= 0 else None
        elif engine == "Google":
            result = self.google_results[selection] if selection >= 0 else None
        elif engine == "Multi-Search":
            result = self.multi_results[selection] if selection >= 0 else None
        if result:
            name, ok = QInputDialog.getText(self, "Bookmark Name", "Enter a name for the bookmark:")
            if ok and name:
                result['title'] = name
                category, ok = QInputDialog.getText(self, "Bookmark Category", "Enter a category for the bookmark:")
                if ok and category:
                    result['category'] = category
                else:
                    result['category'] = 'Uncategorized'
                if not self.is_duplicate_bookmark(result['url']):
                    self.bookmarks.append(result)
                    self.filtered_bookmarks.append(result)
                    self.update_bookmarks_tree()
                    self.save_bookmarks()
                else:
                    QMessageBox.warning(self, "Duplicate Bookmark", "This bookmark already exists.")

    def is_duplicate_bookmark(self, url):
        return any(bookmark['url'] == url for bookmark in self.bookmarks)

    def update_bookmarks_tree(self):
        self.bookmarks_tree.clear()
        categories = {}
        for bookmark in self.filtered_bookmarks:
            category = bookmark.get('category', 'Uncategorized')
            if category not in categories:
                categories[category] = QTreeWidgetItem(self.bookmarks_tree, [category])
            QTreeWidgetItem(categories[category], [bookmark['title'], bookmark['url']])
        self.bookmarks_tree.expandAll()

    def on_select_bookmark(self):
        item = self.bookmarks_tree.currentItem()
        if item and item.parent():
            url = item.text(1)
            title = item.text(0)
            self.open_new_tab(url, title)
        else:
            self.show_error_message("Bookmark", "No valid URL found for the selected bookmark.")

    def rename_bookmark(self):
        item = self.bookmarks_tree.currentItem()
        if item and item.parent():
            old_title = item.text(0)
            name, ok = QInputDialog.getText(self, "Rename Bookmark", "Enter a new name for the bookmark:", text=old_title)
            if ok and name:
                for bookmark in self.filtered_bookmarks:
                    if bookmark['title'] == old_title:
                        bookmark['title'] = name
                        self.update_bookmarks_tree()
                        self.save_bookmarks()
                        break

    def delete_bookmark(self):
        item = self.bookmarks_tree.currentItem()
        if item and item.parent():
            title = item.text(0)
            self.bookmarks = [bookmark for bookmark in self.bookmarks if bookmark['title'] != title]
            self.filtered_bookmarks = self.bookmarks.copy()
            self.update_bookmarks_tree()
            self.save_bookmarks()

    def delete_category(self):
        item = self.bookmarks_tree.currentItem()
        if item and not item.parent():
            category = item.text(0)
            self.bookmarks = [bookmark for bookmark in self.bookmarks if bookmark.get('category') != category]
            self.filtered_bookmarks = self.bookmarks.copy()
            self.update_bookmarks_tree()
            self.save_bookmarks()

    def move_bookmark_to_category(self):
        item = self.bookmarks_tree.currentItem()
        if item and item.parent():
            title = item.text(0)
            category, ok = QInputDialog.getText(self, "Move Bookmark to Category", "Enter the name of the category:")
            if ok and category:
                for bookmark in self.filtered_bookmarks:
                    if bookmark['title'] == title:
                        bookmark['category'] = category
                        self.update_bookmarks_tree()
                        self.save_bookmarks()
                        break

    def add_category(self):
        category, ok = QInputDialog.getText(self, "Add Category", "Enter the name of the new category:")
        if ok and category:
            if category not in [self.bookmarks_tree.topLevelItem(i).text(0) for i in range(self.bookmarks_tree.topLevelItemCount())]:
                QTreeWidgetItem(self.bookmarks_tree, [category])

    def open_new_tab(self, url, title):
        new_browser = QWebEngineView()
        new_browser.setUrl(QUrl(url))
        self.browser_tab_widget.addTab(new_browser, title)
        self.browser_tab_widget.setCurrentWidget(new_browser)
        self.save_tabs()

    def load_url_from_address_bar(self):
        url = self.address_bar.text()
        if not url.startswith("http"):
            url = "http://" + url
        self.open_new_tab(url, url)

    def update_address_bar(self, index):
        current_browser = self.browser_tab_widget.widget(index)
        if current_browser:
            self.address_bar.setText(current_browser.url().toString())

    def close_tab(self, index):
        self.browser_tab_widget.removeTab(index)
        self.save_tabs()

    def load_bookmarks(self):
        if os.path.exists(BOOKMARKS_FILE):
            with open(BOOKMARKS_FILE, 'r') as file:
                return json.load(file)
        return []

    def save_bookmarks(self):
        with open(BOOKMARKS_FILE, 'w') as file:
            json.dump(self.bookmarks, file, indent=4)

    def export_bookmarks(self):
        file_name, _ = QFileDialog.getSaveFileName(self, "Export Bookmarks", "", "JSON Files (*.json);;All Files (*)")
        if file_name:
            with open(file_name, 'w') as file:
                json.dump(self.bookmarks, file, indent=4)
            QMessageBox.information(self, "Export Bookmarks", "Bookmarks exported successfully.")

    def import_bookmarks(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Import Bookmarks", "", "JSON Files (*.json);;All Files (*)")
        if file_name:
            with open(file_name, 'r') as file:
                imported_bookmarks = json.load(file)
                for bm in imported_bookmarks:
                    if isinstance(bm, dict) and 'title' in bm and 'url' in bm:
                        if not self.is_duplicate_bookmark(bm['url']):
                            self.bookmarks.append(bm)
                self.filtered_bookmarks = self.bookmarks.copy()
                self.update_bookmarks_tree()
                self.save_bookmarks()
            QMessageBox.information(self, "Import Bookmarks", "Bookmarks imported successfully.")

    def save_tabs(self):
        tabs = []
        for index in range(self.browser_tab_widget.count()):
            browser = self.browser_tab_widget.widget(index)
            url = browser.url().toString()
            title = self.browser_tab_widget.tabText(index)
            tabs.append({'url': url, 'title': title})
        with open(TABS_FILE, 'w') as file:
            json.dump(tabs, file, indent=4)

    def restore_tabs(self):
        if os.path.exists(TABS_FILE):
            with open(TABS_FILE, 'r') as file:
                tabs = json.load(file)
                for tab in tabs:
                    self.open_new_tab(tab['url'], tab['title'])

    def toggle_fullscreen(self):
        if self.fullscreen:
            self.layout.insertWidget(0, self.tab_widget)
            self.fullscreen = False
        else:
            self.layout.removeWidget(self.tab_widget)
            self.fullscreen = True


def main():
    app = QApplication(sys.argv)

    # Load and apply saved font settings
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as file:
            config = json.load(file)
            font_data = config.get('font', {})
            font = QFont()
            font.setFamily(font_data.get('family', ''))
            font.setPointSize(font_data.get('pointSize', 10))
            font.setWeight(font_data.get('weight', QFont.Weight.Normal))
            font.setItalic(font_data.get('italic', False))
            app.setFont(font)

    app.setStyleSheet(qdarkstyle.load_stylesheet())
    ex = SearchApp()
    ex.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
