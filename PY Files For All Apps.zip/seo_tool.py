import tkinter as tk
from tkinter import ttk, scrolledtext
from transformers import pipeline
import requests
from bs4 import BeautifulSoup
import warnings
import torch
from pyseoanalyzer import analyze

# Suppress specific FutureWarning
warnings.filterwarnings("ignore", category=FutureWarning, module="huggingface_hub.file_download")

# Define functions for NLP tasks
def fetch_website_content(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        text = ' '.join(p.get_text() for p in soup.find_all('p'))
        return text
    except requests.RequestException as e:
        return f"Error fetching content: {e}"

def extract_keywords(text):
    nlp = pipeline("ner", model="dbmdz/bert-large-cased-finetuned-conll03-english", aggregation_strategy="simple")
    ner_results = nlp(text)
    keywords = set()
    for entity in ner_results:
        keywords.add(entity['word'])
    return list(keywords)

def split_text(text, max_length):
    # Splits text into chunks of max_length, ensuring not to cut off words
    words = text.split()
    chunks = []
    chunk = []
    for word in words:
        if len(" ".join(chunk + [word])) <= max_length:
            chunk.append(word)
        else:
            chunks.append(" ".join(chunk))
            chunk = [word]
    if chunk:
        chunks.append(" ".join(chunk))
    return chunks

def summarize_content(text):
    summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")
    max_input_length = 1024  # Maximum length the model can handle
    chunks = split_text(text, max_input_length)
    
    summaries = []
    for chunk in chunks:
        summary = summarizer(chunk, max_length=50, min_length=25, do_sample=False)
        summaries.append(summary[0]['summary_text'])
    
    return " ".join(summaries)

def analyze_sentiment(text):
    sentiment_analyzer = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")
    max_input_length = 512  # Maximum length the model can handle
    chunks = split_text(text, max_input_length)
    
    sentiments = []
    for chunk in chunks:
        sentiment = sentiment_analyzer(chunk)
        sentiments.append(sentiment[0])
    
    return sentiments

def check_grammar_spelling(text):
    corrector = pipeline("text2text-generation", model="facebook/bart-large-cnn")
    max_input_length = 512  # Adjust based on the model's capacity
    chunks = split_text(text, max_input_length)
    
    corrected_texts = []
    for chunk in chunks:
        corrected_chunk = corrector(chunk)[0]['generated_text']
        corrected_texts.append(corrected_chunk)
    
    return " ".join(corrected_texts)

def named_entity_recognition(text):
    ner = pipeline("ner", model="dbmdz/bert-large-cased-finetuned-conll03-english", aggregation_strategy="simple")
    entities = ner(text)
    return entities

def perform_seo_analysis(url):
    result = analyze(url, depth=1)
    return result

# Define the main application
class SEOToolApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Zen SEO Tool")
        self.root.geometry("1600x1000")

        self.tabControl = ttk.Notebook(root)
        self.create_tabs()
        self.apply_styles()

    def create_tabs(self):
        self.seoReportTab = ttk.Frame(self.tabControl)
        self.keywordTab = ttk.Frame(self.tabControl)
        self.summaryTab = ttk.Frame(self.tabControl)
        self.sentimentTab = ttk.Frame(self.tabControl)
        self.grammarTab = ttk.Frame(self.tabControl)
        self.nerTab = ttk.Frame(self.tabControl)
        self.textGenTab = ttk.Frame(self.tabControl)

        self.tabControl.add(self.seoReportTab, text='SEO Report')
        self.tabControl.add(self.keywordTab, text='Keyword Extraction')
        self.tabControl.add(self.summaryTab, text='Summarization')
        self.tabControl.add(self.sentimentTab, text='Sentiment Analysis')
        self.tabControl.add(self.grammarTab, text='Grammar Check')
        self.tabControl.add(self.nerTab, text='NER')
        self.tabControl.add(self.textGenTab, text='Text Generation')

        self.tabControl.pack(expand=1, fill="both")

        self.create_seo_report_tab()
        self.create_keyword_tab()
        self.create_summary_tab()
        self.create_sentiment_tab()
        self.create_grammar_tab()
        self.create_ner_tab()
        self.create_text_gen_tab()

    def apply_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TNotebook", background="white", foreground="black")
        style.configure("TNotebook.Tab", background="white", foreground="black", lightcolor="black", borderwidth=0)
        style.map("TNotebook.Tab", background=[("selected", "black")], foreground=[("selected", "white")])
        style.configure("TFrame", background="white")

    def create_seo_report_tab(self):
        self.seoReportLabel = ttk.Label(self.seoReportTab, text='Enter URL:', background='white', foreground='black', font=('Helvetica', 16))
        self.seoReportLabel.pack(pady=10)
        self.seoReportEntry = ttk.Entry(self.seoReportTab, font=('Helvetica', 14), width=60)
        self.seoReportEntry.pack(pady=5)
        self.seoReportButton = ttk.Button(self.seoReportTab, text='Generate SEO Report', command=self.generate_seo_report, style='TButton', padding=10)
        self.seoReportButton.pack(pady=5)
        self.seoReportResult = scrolledtext.ScrolledText(self.seoReportTab, wrap=tk.WORD, height=30, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.seoReportResult.pack(pady=10)
        self.seoReportExplanation = ttk.Label(self.seoReportTab, text='This tool generates a comprehensive SEO report for the entered URL.', background='white', foreground='black', wraplength=400, font=('Helvetica', 14))
        self.seoReportExplanation.pack(pady=10)

    def create_keyword_tab(self):
        self.keywordLabel = ttk.Label(self.keywordTab, text='Enter Content:', background='white', foreground='black', font=('Helvetica', 16))
        self.keywordLabel.pack(pady=10)
        self.keywordEntry = scrolledtext.ScrolledText(self.keywordTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.keywordEntry.pack(pady=5)
        self.keywordButton = ttk.Button(self.keywordTab, text='Extract Keywords', command=self.extract_keywords, style='TButton', padding=10)
        self.keywordButton.pack(pady=5)
        self.keywordResult = scrolledtext.ScrolledText(self.keywordTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.keywordResult.pack(pady=10)
        self.keywordExplanation = ttk.Label(self.keywordTab, text='This tool extracts keywords from the entered content.', background='white', foreground='black', wraplength=400, font=('Helvetica', 14))
        self.keywordExplanation.pack(pady=10)

    def create_summary_tab(self):
        self.summaryLabel = ttk.Label(self.summaryTab, text='Enter Content:', background='white', foreground='black', font=('Helvetica', 16))
        self.summaryLabel.pack(pady=10)
        self.summaryEntry = scrolledtext.ScrolledText(self.summaryTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.summaryEntry.pack(pady=5)
        self.summaryButton = ttk.Button(self.summaryTab, text='Summarize Content', command=self.summarize_content, style='TButton', padding=10)
        self.summaryButton.pack(pady=5)
        self.summaryResult = scrolledtext.ScrolledText(self.summaryTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.summaryResult.pack(pady=10)
        self.summaryExplanation = ttk.Label(self.summaryTab, text='This tool summarizes the entered content.', background='white', foreground='black', wraplength=400, font=('Helvetica', 14))
        self.summaryExplanation.pack(pady=10)

    def create_sentiment_tab(self):
        self.sentimentLabel = ttk.Label(self.sentimentTab, text='Enter Content:', background='white', foreground='black', font=('Helvetica', 16))
        self.sentimentLabel.pack(pady=10)
        self.sentimentEntry = scrolledtext.ScrolledText(self.sentimentTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.sentimentEntry.pack(pady=5)
        self.sentimentButton = ttk.Button(self.sentimentTab, text='Analyze Sentiment', command=self.analyze_sentiment, style='TButton', padding=10)
        self.sentimentButton.pack(pady=5)
        self.sentimentResult = scrolledtext.ScrolledText(self.sentimentTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.sentimentResult.pack(pady=10)
        self.sentimentExplanation = ttk.Label(self.sentimentTab, text='This tool analyzes the sentiment of the entered content.', background='white', foreground='black', wraplength=400, font=('Helvetica', 14))
        self.sentimentExplanation.pack(pady=10)

    def create_grammar_tab(self):
        self.grammarLabel = ttk.Label(self.grammarTab, text='Enter Content:', background='white', foreground='black', font=('Helvetica', 16))
        self.grammarLabel.pack(pady=10)
        self.grammarEntry = scrolledtext.ScrolledText(self.grammarTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.grammarEntry.pack(pady=5)
        self.grammarButton = ttk.Button(self.grammarTab, text='Check Grammar', command=self.check_grammar, style='TButton', padding=10)
        self.grammarButton.pack(pady=5)
        self.grammarResult = scrolledtext.ScrolledText(self.grammarTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.grammarResult.pack(pady=10)
        self.grammarExplanation = ttk.Label(self.grammarTab, text='This tool checks the grammar and spelling of the entered content.', background='white', foreground='black', wraplength=400, font=('Helvetica', 14))
        self.grammarExplanation.pack(pady=10)

    def create_ner_tab(self):
        self.nerLabel = ttk.Label(self.nerTab, text='Enter Content:', background='white', foreground='black', font=('Helvetica', 16))
        self.nerLabel.pack(pady=10)
        self.nerEntry = scrolledtext.ScrolledText(self.nerTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.nerEntry.pack(pady=5)
        self.nerButton = ttk.Button(self.nerTab, text='Analyze NER', command=self.analyze_ner, style='TButton', padding=10)
        self.nerButton.pack(pady=5)
        self.nerResult = scrolledtext.ScrolledText(self.nerTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.nerResult.pack(pady=10)
        self.nerExplanation = ttk.Label(self.nerTab, text='This tool analyzes Named Entities in the entered content.', background='white', foreground='black', wraplength=400, font=('Helvetica', 14))
        self.nerExplanation.pack(pady=10)

    def create_text_gen_tab(self):
        self.textGenLabel = ttk.Label(self.textGenTab, text='Enter Prompt:', background='white', foreground='black', font=('Helvetica', 16))
        self.textGenLabel.pack(pady=10)
        self.textGenEntry = scrolledtext.ScrolledText(self.textGenTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.textGenEntry.pack(pady=5)
        self.textGenButton = ttk.Button(self.textGenTab, text='Generate Text', command=self.generate_text, style='TButton', padding=10)
        self.textGenButton.pack(pady=5)
        self.textGenResult = scrolledtext.ScrolledText(self.textGenTab, wrap=tk.WORD, height=15, width=100, background='white', foreground='black', font=('Helvetica', 14))
        self.textGenResult.pack(pady=10)
        self.textGenExplanation = ttk.Label(self.textGenTab, text='This tool generates text.', background='white', foreground='black', wraplength=400, font=('Helvetica', 14))
        self.textGenExplanation.pack(pady=10)

    def generate_seo_report(self):
        url = self.seoReportEntry.get()
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "http://" + url
        if url:
            report = []

            content = fetch_website_content(url)

            if "Error" in content:
                self.seoReportResult.delete(1.0, tk.END)
                self.seoReportResult.insert(tk.END, content)
                return

            # Keyword Extraction
            keywords = extract_keywords(content)
            report.append("Extracted Keywords:\n" + ', '.join(keywords))
            
            # Content Summarization
            summary = summarize_content(content)
            report.append("Content Summary:\n" + summary)
            
            # Sentiment Analysis
            sentiment = analyze_sentiment(content)
            report.append("Sentiment Analysis:\n" + str(sentiment))
            
            # SEO Analysis using pyseoanalyzer
            seo_analysis = perform_seo_analysis(url)
            report.append("SEO Analysis:\n" + str(seo_analysis))

            # Display the report
            self.seoReportResult.delete(1.0, tk.END)
            self.seoReportResult.insert(tk.END, "\n\n".join(report))
        else:
            self.seoReportResult.delete(1.0, tk.END)
            self.seoReportResult.insert(tk.END, "Please enter a URL.")

    def extract_keywords(self):
        content = self.keywordEntry.get("1.0", tk.END)
        keywords = extract_keywords(content)
        self.keywordResult.delete(1.0, tk.END)
        self.keywordResult.insert(tk.END, ', '.join(keywords))

    def summarize_content(self):
        content = self.summaryEntry.get("1.0", tk.END)
        summary = summarize_content(content)
        self.summaryResult.delete(1.0, tk.END)
        self.summaryResult.insert(tk.END, summary)

    def analyze_sentiment(self):
        content = self.sentimentEntry.get("1.0", tk.END)
        sentiment = analyze_sentiment(content)
        self.sentimentResult.delete(1.0, tk.END)
        self.sentimentResult.insert(tk.END, str(sentiment))

    def check_grammar(self):
        content = self.grammarEntry.get("1.0", tk.END)
        result = check_grammar_spelling(content)
        self.grammarResult.delete(1.0, tk.END)
        self.grammarResult.insert(tk.END, result)

    def analyze_ner(self):
        content = self.nerEntry.get("1.0", tk.END)
        entities = named_entity_recognition(content)
        self.nerResult.delete(1.0, tk.END)
        self.nerResult.insert(tk.END, str(entities))

    def generate_text(self):
        prompt = self.textGenEntry.get("1.0", tk.END)
        generator = pipeline("text-generation")
        response = generator(prompt, max_new_tokens=50, do_sample=True)
        generated_text = response[0]['generated_text']
        self.textGenResult.delete(1.0, tk.END)
        self.textGenResult.insert(tk.END, generated_text)

if __name__ == "__main__":
    root = tk.Tk()
    app = SEOToolApp(root)
    root.mainloop()
